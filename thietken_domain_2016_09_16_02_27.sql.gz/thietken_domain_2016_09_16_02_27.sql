-- Status:2:106:MP_0:thietken_domain:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|domain|3|32768||InnoDB
-- TABLE|ga|103|32768||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:27

--
-- Create Table `domain`
--

DROP TABLE IF EXISTS `domain`;
CREATE TABLE `domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `created_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`link`)
) ENGINE=InnoDB AUTO_INCREMENT=3404 DEFAULT CHARSET=latin1;

--
-- Data for Table `domain`
--

/*!40000 ALTER TABLE `domain` DISABLE KEYS */;
INSERT INTO `domain` (`id`,`link`,`created_date`) VALUES ('1','http://creditfinanceeucity.com/ads-vi.php','2016-07-14');
INSERT INTO `domain` (`id`,`link`,`created_date`) VALUES ('2','http://www.usasupremefinance.com/ads-vi.php','2016-07-17');
INSERT INTO `domain` (`id`,`link`,`created_date`) VALUES ('3403','http://nghemayusb.cf/ads-vi.php','2016-07-26');
/*!40000 ALTER TABLE `domain` ENABLE KEYS */;


--
-- Create Table `ga`
--

DROP TABLE IF EXISTS `ga`;
CREATE TABLE `ga` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `domain_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`,`domain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

--
-- Data for Table `ga`
--

/*!40000 ALTER TABLE `ga` DISABLE KEYS */;
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('1','partner-pub-3103728071724412:4107393681','1','2016-07-14');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('2','partner-pub-8179206694305597:6622439068','2','2016-07-17');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('13','','3403','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('14','','13','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('15','','14','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('16','','15','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('17','','16','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('18','','17','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('19','','18','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('20','','19','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('21','','20','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('22','','21','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('23','','22','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('24','','23','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('25','','24','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('26','','25','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('27','','26','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('28','','27','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('29','','28','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('30','','29','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('31','','30','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('32','','31','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('33','','32','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('34','','33','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('35','','34','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('36','','35','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('37','','36','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('38','','37','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('39','','38','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('40','','39','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('41','','40','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('42','','41','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('43','','42','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('44','','43','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('45','','44','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('46','','45','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('47','','46','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('48','','47','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('49','','48','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('50','','49','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('51','','50','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('52','','51','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('53','','52','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('54','','53','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('55','','54','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('56','','55','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('57','','56','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('58','','57','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('59','','58','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('60','','59','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('61','','60','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('62','','61','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('63','','62','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('64','','63','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('65','','64','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('66','','65','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('67','','66','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('68','','67','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('69','','68','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('70','','69','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('71','','70','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('72','','71','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('73','','72','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('74','','73','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('75','','74','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('76','','75','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('77','','76','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('78','','77','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('79','','78','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('80','','79','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('81','','80','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('82','','81','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('83','','82','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('84','','83','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('85','','84','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('86','','85','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('87','','86','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('88','','87','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('89','','88','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('90','','89','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('91','','90','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('92','','91','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('93','','92','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('94','','93','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('95','','94','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('96','','95','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('97','','96','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('98','','97','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('99','','98','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('100','','99','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('101','','100','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('102','','101','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('103','','102','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('104','','103','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('105','','104','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('106','','105','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('107','','106','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('108','','107','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('109','','108','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('110','','109','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('111','','110','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('112','','111','2016-07-26');
INSERT INTO `ga` (`id`,`code`,`domain_id`,`created_date`) VALUES ('113','','112','2016-07-26');
/*!40000 ALTER TABLE `ga` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

