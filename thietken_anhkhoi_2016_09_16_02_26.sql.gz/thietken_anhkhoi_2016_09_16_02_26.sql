-- Status:33:777:MP_0:thietken_anhkhoi:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|age_range|8|16384||InnoDB
-- TABLE|article_cate|0|1024|2015-11-25 12:21:30|MyISAM
-- TABLE|articles|2|29124|2015-11-25 12:21:30|MyISAM
-- TABLE|articles_tag|2|2068|2015-11-25 12:21:30|MyISAM
-- TABLE|banner|0|1024|2015-11-25 12:21:30|MyISAM
-- TABLE|block|4|16384||InnoDB
-- TABLE|cate|18|16384||InnoDB
-- TABLE|cate_type|7|16384||InnoDB
-- TABLE|city|3|2152|2015-11-25 12:21:30|MyISAM
-- TABLE|customer|9|16384||InnoDB
-- TABLE|email_code|0|1024|2015-11-25 12:21:30|MyISAM
-- TABLE|feedback|0|16384||InnoDB
-- TABLE|images|512|81920||InnoDB
-- TABLE|link|19|16384||InnoDB
-- TABLE|manu|0|16384||InnoDB
-- TABLE|manu_catetype|0|16384||InnoDB
-- TABLE|method|3|16384||InnoDB
-- TABLE|order_detail|0|1024|2015-11-25 12:21:30|MyISAM
-- TABLE|order_info|25|16384||InnoDB
-- TABLE|orders|0|16384||InnoDB
-- TABLE|pages|1|16384||InnoDB
-- TABLE|privilege|43|16384||InnoDB
-- TABLE|product|9|147456||InnoDB
-- TABLE|product_cate|2|16384||InnoDB
-- TABLE|promotion_code|0|1024|2015-11-25 12:21:30|MyISAM
-- TABLE|sendcontent|0|1024|2015-11-25 12:21:30|MyISAM
-- TABLE|seo|4|16384||InnoDB
-- TABLE|state|10|16384||InnoDB
-- TABLE|tag|39|3964|2015-11-25 12:21:30|MyISAM
-- TABLE|text|13|2920|2015-11-25 12:21:30|MyISAM
-- TABLE|url|22|16384||InnoDB
-- TABLE|user_privilege|17|16384||InnoDB
-- TABLE|users|5|2620|2015-11-25 12:21:30|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:26

--
-- Create Table `age_range`
--

DROP TABLE IF EXISTS `age_range`;
CREATE TABLE `age_range` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range` varchar(100) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Data for Table `age_range`
--

/*!40000 ALTER TABLE `age_range` DISABLE KEYS */;
INSERT INTO `age_range` (`id`,`range`) VALUES ('1','0 tháng - 3 tháng');
INSERT INTO `age_range` (`id`,`range`) VALUES ('2','3 tháng - 6 tháng');
INSERT INTO `age_range` (`id`,`range`) VALUES ('3','6 tháng - 12 tháng');
INSERT INTO `age_range` (`id`,`range`) VALUES ('4','1 tuổi - 3 tuổi');
INSERT INTO `age_range` (`id`,`range`) VALUES ('5','3 tuổi - 6 tuổi');
INSERT INTO `age_range` (`id`,`range`) VALUES ('6','6 tuổi - 7 tuổi');
INSERT INTO `age_range` (`id`,`range`) VALUES ('7','7 tuổi - 10 tuổi');
INSERT INTO `age_range` (`id`,`range`) VALUES ('8','Trên 10 tuổi');
/*!40000 ALTER TABLE `age_range` ENABLE KEYS */;


--
-- Create Table `article_cate`
--

DROP TABLE IF EXISTS `article_cate`;
CREATE TABLE `article_cate` (
  `cate_id` int(4) NOT NULL AUTO_INCREMENT COMMENT 'So thu tu danh muc bai viet',
  `cate_name` varchar(255) NOT NULL COMMENT 'Ten danh muc bai viet',
  `cate_alias` varchar(255) NOT NULL,
  `image_url` varchar(100) DEFAULT NULL COMMENT 'Hinh anh tren menu',
  `description` varchar(255) NOT NULL,
  `display_order` int(2) DEFAULT NULL COMMENT 'Thu tu hien thi',
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'SEO Title',
  `meta_description` varchar(255) DEFAULT NULL COMMENT 'SEO Description',
  `meta_keyword` varchar(255) DEFAULT NULL COMMENT 'SEO Keyword',
  `seo_title` varchar(255) NOT NULL,
  `seo_text` text NOT NULL,
  `is_hot` tinyint(1) NOT NULL,
  `hidden` tinyint(1) DEFAULT '0' COMMENT 'On - Off',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `article_cate`
--

/*!40000 ALTER TABLE `article_cate` DISABLE KEYS */;
/*!40000 ALTER TABLE `article_cate` ENABLE KEYS */;


--
-- Create Table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `article_id` int(8) NOT NULL AUTO_INCREMENT COMMENT 'So thu tu',
  `article_title` varchar(255) DEFAULT NULL COMMENT 'Tieu de',
  `title_en` varchar(255) NOT NULL,
  `article_alias` varchar(255) DEFAULT NULL COMMENT 'Tieu de khong dau',
  `image_url` varchar(150) DEFAULT NULL COMMENT 'Duong dan hinh anh nho',
  `description` varchar(500) DEFAULT NULL COMMENT 'Loi gioi thieu',
  `content` text COMMENT 'Noi dung chi tiet cua bai viet',
  `source` varchar(150) DEFAULT NULL COMMENT 'Nguon tin',
  `hidden` tinyint(1) DEFAULT '0' COMMENT 'Bat - Tat',
  `cate_id` int(8) DEFAULT NULL COMMENT 'ID Nhom bai viet',
  `is_hot` tinyint(1) DEFAULT NULL COMMENT 'Danh sach bai viet dang chu y (Sticky)',
  `view` int(6) DEFAULT NULL COMMENT 'So lan xem',
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_text` text NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` tinyint(4) NOT NULL,
  `updated_by` tinyint(4) NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Data for Table `articles`
--

/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` (`article_id`,`article_title`,`title_en`,`article_alias`,`image_url`,`description`,`content`,`source`,`hidden`,`cate_id`,`is_hot`,`view`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('1','Gãy cần cẩu ở Sài Gòn, nhiều công nhân bị mắc kẹt','Gay can cau o Sai Gon nhieu cong nhan bi mac ket','test','upload/images/2015/11/23/hydrangeas-1.jpg','Một chiếc cần cẩu đang bốc dỡ hàng bất ngờ gãy đôi, đổ sập đè lên hầm tàu hàng khiến nhiều công nhân bị mắc kẹt. Hàng chục cảnh sát PCCC đến hiện trường cứu hộ.','\r\n	<table align=\"center\" class=\"picture\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px 0px 14px; padding: 0px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 560px; float: none; color: rgb(85, 85, 85); line-height: 20px; -webkit-font-smoothing: antialiased; background: transparent;\">\r\n		<tbody style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pic\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; cursor: pointer; background: transparent;\">\r\n					<img alt=\"a\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/jokvth/2015_11_24/nga.jpg\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; width: 560px; height: auto; background: transparent;\" /></td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pCaption caption\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 5px 0px 8px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; background: transparent;\">\r\n					Chiến đấu cơ Su-24 của Nga. Ảnh:&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">CTV News.</em></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		C&aacute;c h&igrave;nh ảnh quay được từ k&ecirc;nh truyền h&igrave;nh quốc gia&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">Anadolu</em>&nbsp;cho thấy hai phi c&ocirc;ng đ&atilde; nhảy d&ugrave; sau khi phi cơ tr&uacute;ng t&ecirc;n lửa ng&agrave;y 24/11. Tuy nhi&ecirc;n, t&igrave;nh trạng của hai người n&agrave;y chưa được l&agrave;m r&otilde;.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Tổ chức Theo d&otilde;i Nh&acirc;n quyền Syria c&oacute; trụ sở tại London cho biết, m&aacute;y bay bốc ch&aacute;y v&agrave; tạo quả cầu lửa khi rơi xuống khu vực đồi n&uacute;i ph&iacute;a bắc tỉnh Latakia, gần bi&ecirc;n giới Thổ Nhĩ Kỳ v&agrave; Syria. C&aacute;c nh&acirc;n chứng cho biết họ nh&igrave;n thấy kh&oacute;i đen bốc l&ecirc;n từ vị tr&iacute; m&aacute;y bay lao xuống.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Giới chức qu&acirc;n đội Thổ Nhĩ Kỳ khẳng định đ&atilde; cảnh b&aacute;o phi h&agrave;nh đo&agrave;n tr&ecirc;n chiếc m&aacute;y bay Nga trước khi bắn hạ.&nbsp;</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Tổng thống Thổ Nhĩ Kỳ Tayyip Erdogan đ&atilde; trao đổi với người đứng đầu qu&acirc;n đội v&agrave; sẽ sớm thảo luận với Thủ tướng Ahmet Davutoglu để xử l&yacute; vụ việc.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Trong khi đ&oacute;, h&atilde;ng th&ocirc;ng tấn&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">RT</em>&nbsp;của Nga cho biết, một chiếc Su-24 của nước n&agrave;y bị bắn rơi khi đang thực hiện chiến dịch kh&ocirc;ng k&iacute;ch IS tr&ecirc;n l&atilde;nh thổ Syria.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Theo Bộ Quốc ph&ograve;ng Nga, chiếc m&aacute;y bay bị bắn hạ khi đang hoạt động ở độ cao 6.000 m. N&oacute; ho&agrave;n to&agrave;n chưa x&acirc;m phạm kh&ocirc;ng phận Thổ Nhĩ Kỳ.​</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		C&ugrave;ng ng&agrave;y, Thủ tướng Thổ Nhĩ Kỳ Ahmet Davutoglu cho biết &ocirc;ng đ&atilde; y&ecirc;u cầu tham mưu trưởng qu&acirc;n đội cũng như ngoại trưởng nước n&agrave;y tham vấn với Tổ chức Hiệp ước Bắc Đại T&acirc;y Dương (NATO) v&agrave; Li&ecirc;n Hợp Quốc về việc ph&aacute;t triển cũng như thắt chặt c&aacute;c biện ph&aacute;p an ninh dọc bi&ecirc;n giới với Syria. Tuy nhi&ecirc;n, ph&aacute;t biểu của &ocirc;ng kh&ocirc;ng đề cập đến chiếc m&aacute;y bay bị hắn hạ</p>\r\n','','0','1','0','0','Test','Test','Test','','','1448278205','1448419503','1','1');
INSERT INTO `articles` (`article_id`,`article_title`,`title_en`,`article_alias`,`image_url`,`description`,`content`,`source`,`hidden`,`cate_id`,`is_hot`,`view`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('2','Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?','May bay Nga bi ban o Syria sau khi vao Tho Nhi Ky','may-bay-nga-bi-ban-o-syria-sau-khi-vao-tho-nhi-ky','upload/images/2015/11/25/nga_tho_2-1.png','Giới chức Mỹ tin rằng máy bay Nga đã bị bắn trúng ở Syria, sau khi xâm phạm không phận Thổ Nhĩ Kỳ, trong khi Nga khẳng định máy bay của họ chưa bao giờ rời khỏi bầu trời Syria.','\r\n	<table align=\"center\" class=\"picture\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 30px 0px 30px -30px; padding: 0px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 660px; float: none; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; color: rgb(85, 85, 85); line-height: 20px; -webkit-font-smoothing: antialiased; background: transparent;\">\r\n		<tbody style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pic\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; cursor: pointer; background: transparent;\">\r\n					<img alt=\"Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/zugtwi/2015_11_25/nga_tho_2.png\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; width: 660px; height: auto; background: transparent;\" /></td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pCaption caption\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 5px 0px 8px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; background: transparent;\">\r\n					Địa điểm cường k&iacute;ch Su-24 bị bắn hạ, theo th&ocirc;ng tin của Mỹ. Đồ họa:&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">NYT</em></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Quan chức Mỹ giấu t&ecirc;n tiết lộ với&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">Reuters&nbsp;</em>rằng<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">&nbsp;</em>m&aacute;y bay Nga đ&atilde; bị bắn tr&uacute;ng ở Syria, sau khi x&acirc;m phạm kh&ocirc;ng phận Thổ Nhĩ Kỳ. Nguồn tin cho biết, nhận định được đưa ra dựa tr&ecirc;n t&iacute;n hiệu nhiệt tr&ecirc;n phi cơ.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Trước đ&oacute;, qu&acirc;n đội Mỹ ủng hộ tuy&ecirc;n bố của Thổ Nhĩ Kỳ rằng c&aacute;c phi c&ocirc;ng tr&ecirc;n chiến đấu cơ F-16 của họ đ&atilde; cảnh b&aacute;o m&aacute;y bay Nga 10 lần nhưng kh&ocirc;ng nhận được phản hồi. Do vậy, họ quyết định bắn hạ sau khi Su-24 x&acirc;m nhập kh&ocirc;ng phận Thổ Nhĩ Kỳ khoảng 17 gi&acirc;y.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		&ldquo;Ch&uacute;ng t&ocirc;i c&oacute; thể nghe thấy mọi chuyện đang diễn ra. Những k&ecirc;nh th&ocirc;ng tin n&agrave;y l&agrave; c&aacute;c k&ecirc;nh mở&rdquo;, người ph&aacute;t ng&ocirc;n qu&acirc;n đội Mỹ tại Iraq, đại t&aacute; Steven Warren n&oacute;i với c&aacute;c ph&oacute;ng vi&ecirc;n ng&agrave;y 24/11.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Mỹ cũng khẳng định qu&acirc;n đội kh&ocirc;ng li&ecirc;n quan đến vụ Thổ Nhĩ Kỳ bắn rơi m&aacute;y bay Nga. Đại sứ Thổ Nhĩ Kỳ tại Li&ecirc;n Hợp Quốc Halit Cevik đ&atilde; viết thư gửi Hội đồng Bảo an rằng, 2 m&aacute;y bay Nga đ&atilde; bay hơn 1,5 km ở bầu trời nước n&agrave;y trong 17 gi&acirc;y.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Trong khi đ&oacute;, Thổ Nhĩ Kỳ v&agrave; Nga đưa ra những tuy&ecirc;n bố, bằng chứng kh&aacute;c nhau để củng cố cũng như phủ nhận l&yacute; lẽ việc bắn hạ chiếc Su-24 của Nga.</p>\r\n	<table align=\"center\" class=\"picture\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 30px 0px 30px -30px; padding: 0px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; color: rgb(85, 85, 85); line-height: 20px; -webkit-font-smoothing: antialiased; background: transparent;\">\r\n		<tbody style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pic\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; cursor: pointer; background: transparent;\">\r\n					<img alt=\"Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/zugtwi/2015_11_25/nga_tho.png\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; width: 660px; height: auto; background: transparent;\" /></td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pCaption caption\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 5px 0px 8px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; background: transparent;\">\r\n					Vạch m&agrave;u đỏ l&agrave; đường bay của chiếc Su-24 theo lời của ch&iacute;nh phủ Nga, trong khi vạch m&agrave;u t&iacute;m l&agrave; đường bay x&acirc;m phạm kh&ocirc;ng phận Thổ Nhĩ Kỳ. Đồ họa:&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">NYT</em><span style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">&nbsp;</span></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n	<h3 style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; background: transparent;\">\r\n		Thổ Nhĩ Kỳ c&aacute;o buộc g&igrave;?</h3>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Qu&acirc;n đội Thổ Nhĩ Kỳ c&ocirc;ng bố một bản đồ cho thấy, m&aacute;y bay Nga đ&atilde; bay v&agrave;o v&ugrave;ng l&atilde;nh thổ hẹp của nước n&agrave;y ở gần bi&ecirc;n giới với Syria.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Sau chiếc Su-24, Ankara cho biết một m&aacute;y bay thứ hai tiếp tục x&acirc;m phạm kh&ocirc;ng phận nước n&agrave;y nhưng họ kh&ocirc;ng bắn hạ n&oacute;. Thổ Nhĩ Kỳ khẳng định, họ đ&atilde; cảnh b&aacute;o phi c&ocirc;ng tr&ecirc;n chiếc Su-24 &iacute;t nhất 10 lần m&aacute;y bay Nga đang x&acirc;m phạm kh&ocirc;ng phận nước n&agrave;y.</p>\r\n	<table align=\"center\" class=\"picture\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 30px 0px 30px -30px; padding: 0px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; color: rgb(85, 85, 85); line-height: 20px; -webkit-font-smoothing: antialiased; background: transparent;\">\r\n		<tbody style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pic\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; cursor: pointer; background: transparent;\">\r\n					<img alt=\"Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/zugtwi/2015_11_25/nga_tho_3.png\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; width: 660px; height: auto; background: transparent;\" /></td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pCaption caption\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 5px 0px 8px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; background: transparent;\">\r\n					Đường v&agrave;o (phải) v&agrave; ra của m&aacute;y bay Nga ở v&ugrave;ng gần với bi&ecirc;n giới Syria của Thổ Nhĩ Kỳ. Đồ họa:&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">NYT</em></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n	<h3 style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; background: transparent;\">\r\n		Nga phản b&aacute;c như thế n&agrave;o?</h3>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Qu&acirc;n đội Nga khẳng định m&aacute;y bay của họ chưa bao giờ rời khỏi bầu trời Syria, cũng như Thổ Nhĩ Kỳ kh&ocirc;ng hề cảnh b&aacute;o tới Su-24 như đ&atilde; n&oacute;i. Nga cũng c&ocirc;ng bố video về h&agrave;nh tr&igrave;nh bay chứng tỏ lập luận của nước n&agrave;y.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Tuy nhi&ecirc;n, qu&acirc;n đội Mỹ x&aacute;c nhận rằng, Thổ Nhĩ Kỳ đ&atilde; cảnh b&aacute;o phi c&ocirc;ng Nga 10 lần nhưng anh n&agrave;y phớt lờ ch&uacute;ng. Tổng thống Mỹ Barack Obama khẳng định: Thổ Nhĩ Kỳ c&oacute; quyền tự vệ v&agrave; bảo vệ kh&ocirc;ng phận.</p>\r\n	<table align=\"center\" class=\"article\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 14px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 600px; background: transparent;\">\r\n		<tbody style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n					<div class=\"inner-video\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; float: left; width: 600px; height: 337.079px; overflow: hidden; position: relative; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; -webkit-font-smoothing: antialiased; background: transparent;\">\r\n						<p class=\"cover formatted\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; float: left; overflow: hidden; cursor: pointer; width: 600px; height: 337.078px; position: relative; background-image: url(http://img.v3.news.zdn.vn/w660/Uploaded/zugtwi/2015_11_25/Zing_Nga__Ban_do.png); background-attachment: initial; background-color: transparent; background-size: cover !important; background-origin: initial; background-clip: initial; background-position: 50% 0%; background-repeat: no-repeat;\">\r\n							&nbsp;</p>\r\n						<h2 class=\"title\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 40px 100px 10px 20px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; position: absolute; bottom: 0px; left: 0px; right: 0px; color: rgb(255, 255, 255); text-shadow: rgba(0, 0, 0, 0.498039) 1px 1px 0px; line-height: 22px; -webkit-font-smoothing: antialiased; background: linear-gradient(rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.298039) 100%) transparent;\">\r\n							<a href=\"http://news.zing.vn/Video-chung-to-may-bay-Nga-khong-xam-pham-Tho-Nhi-Ky-post604018.html\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; vertical-align: baseline; text-decoration: none; color: rgb(34, 34, 34); display: block; width: 600px; height: 337.078px; float: left; position: relative; background: transparent;\" target=\"_blank\">Video chứng tỏ m&aacute;y bay Nga kh&ocirc;ng x&acirc;m phạm Thổ Nhĩ Kỳ</a></h2>\r\n					</div>\r\n				</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n	<h3 style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; background: transparent;\">\r\n		Nguồn gốc xung đột</h3>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Sự cố Su-24 bị bắn ở Thổ Nhĩ Kỳ l&agrave; điều m&agrave; giới quan s&aacute;t đ&atilde; lo ngại từ đ&acirc;u, giữa t&igrave;nh h&igrave;nh căng thẳng leo thang do nhiều lần chạm tr&aacute;n tr&ecirc;n kh&ocirc;ng giữa m&aacute;y bay Nga v&agrave; phương T&acirc;y.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		B&aacute;o&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">New York Times</em>&nbsp;cho rằng, m&aacute;y bay Nga thường bay gần, hoặc đi v&agrave;o kh&ocirc;ng phận của một số nước để tập luyện hoặc thậm ch&iacute; hoạt động do th&aacute;m. NATO v&agrave; c&aacute;c nước n&agrave;y l&ecirc;n &aacute;n h&agrave;nh vi của phi cơ Nga. Hồi th&aacute;ng 10/2015, NATO phản đối 2 m&aacute;y bay Nga đi v&agrave;o v&ugrave;ng Hatay của Thỗ Nhĩ Kỳ.</p>\r\n	<p style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 18px 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n		Phần lớn vụ chạm tr&aacute;n tr&ecirc;n kh&ocirc;ng xảy ra rải r&aacute;c ở ch&acirc;u &Acirc;u. C&aacute;c nước NATO nhiều lần cho chiến đấu cơ xuất k&iacute;ch để ngăn chặn m&aacute;y bay Nga tr&ecirc;n biển Baltic v&agrave; ở nhiều nơi kh&aacute;c.</p>\r\n	<table align=\"center\" class=\"picture\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 30px 0px 30px -30px; padding: 0px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; color: rgb(85, 85, 85); line-height: 20px; -webkit-font-smoothing: antialiased; background: transparent;\">\r\n		<tbody style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pic\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; cursor: pointer; background: transparent;\">\r\n					<img alt=\"Bản đồ ghi nhận những lần chạm trán trên không giữa máy bay Nga và các nước châu Âu từ tháng 3/2014 đến tháng 3/2015. Chấm đỏ biểu thị cho những lần có nguy cơ đụng độ cao, chấm cam là lần có nguy cơ thấp. Ảnh: NYT\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/zugtwi/2015_11_25/nga_tho_4.png\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; width: 660px; height: auto; background: transparent;\" /></td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">\r\n				<td class=\"pCaption caption\" style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 5px 0px 8px; border: 0px; outline: 0px; vertical-align: baseline; position: relative; background: transparent;\">\r\n					Bản đồ ghi nhận những lần chạm tr&aacute;n tr&ecirc;n kh&ocirc;ng giữa m&aacute;y bay Nga v&agrave; c&aacute;c nước ch&acirc;u &Acirc;u từ th&aacute;ng 3/2014 đến th&aacute;ng 3/2015. Chấm đỏ biểu thị cho những lần c&oacute; nguy cơ đụng độ cao, chấm cam l&agrave; lần c&oacute; nguy cơ thấp. Đồ họa:&nbsp;<em style=\"box-sizing: border-box; text-rendering: geometricPrecision; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">NYT</em></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n','','0','1','0','0','Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?','Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?','Máy bay Nga bị bắn ở Syria sau khi vào Thổ Nhĩ Kỳ?','','','1448419098','1448419098','1','1');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;


--
-- Create Table `articles_tag`
--

DROP TABLE IF EXISTS `articles_tag`;
CREATE TABLE `articles_tag` (
  `article_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `object_type` tinyint(4) NOT NULL,
  PRIMARY KEY (`article_id`,`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `articles_tag`
--

/*!40000 ALTER TABLE `articles_tag` DISABLE KEYS */;
INSERT INTO `articles_tag` (`article_id`,`tag_id`,`object_type`) VALUES ('1','39','2');
INSERT INTO `articles_tag` (`article_id`,`tag_id`,`object_type`) VALUES ('2','38','2');
/*!40000 ALTER TABLE `articles_tag` ENABLE KEYS */;


--
-- Create Table `banner`
--

DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_event` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `link_url` varchar(500) NOT NULL,
  `type_id` tinyint(4) NOT NULL,
  `size_default` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` smallint(6) NOT NULL,
  `updated_by` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `banner`
--

/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;


--
-- Create Table `block`
--

DROP TABLE IF EXISTS `block`;
CREATE TABLE `block` (
  `block_id` int(11) NOT NULL AUTO_INCREMENT,
  `block_name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`block_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Data for Table `block`
--

/*!40000 ALTER TABLE `block` DISABLE KEYS */;
INSERT INTO `block` (`block_id`,`block_name`,`status`) VALUES ('3','Giới thiệu','1');
INSERT INTO `block` (`block_id`,`block_name`,`status`) VALUES ('4','Hướng dẫn, hỗ trợ','1');
INSERT INTO `block` (`block_id`,`block_name`,`status`) VALUES ('9','Các chính sách','1');
INSERT INTO `block` (`block_id`,`block_name`,`status`) VALUES ('10','Thông tin','1');
/*!40000 ALTER TABLE `block` ENABLE KEYS */;


--
-- Create Table `cate`
--

DROP TABLE IF EXISTS `cate`;
CREATE TABLE `cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(255) NOT NULL,
  `cate_alias` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `cate_type_id` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `icon_url` varchar(255) NOT NULL,
  `content` text,
  `is_hot` tinyint(1) NOT NULL,
  `display_order` int(11) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_text` text NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` tinyint(4) NOT NULL,
  `updated_by` tinyint(4) NOT NULL,
  `hidden` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=392 DEFAULT CHARSET=utf8;

--
-- Data for Table `cate`
--

/*!40000 ALTER TABLE `cate` DISABLE KEYS */;
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('42','ĐẦU GHI HÌNH','dau-ghi-hinh-vdtech','0','4','','','','1','1','Đầu ghi hình VDTECH','Đầu ghi hình VDTECH','Đầu ghi hình VDTECH','','','1426722084','1448192804','0','1','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('54','CAMERA IP','camera-ip-vdtech','0','4','','','','1','2','CAMERA IP VDTECH','CAMERA IP VDTECH','CAMERA IP VDTECH','','','1426722240','1448192828','0','1','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('231','ĐẦU GHI HÌNH','dau-ghi-hinh-eyewide','0','2','','','ĐẦU GHI H&Igrave;NH EYEWIDE','1','1','ĐẦU GHI HÌNH EYEWIDE','ĐẦU GHI HÌNH EYEWIDE','ĐẦU GHI HÌNH EYEWIDE','Đồng hồ casio nam chính hãng tại tphcm','ĐẦU GHI H&Igrave;NH EYEWIDE','1426764396','1448198341','0','1','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('336','ĐẦU GHI HÌNH','dau-ghi-hinh-global','0','9','','','','1','1','ĐẦU GHI HÌNH GLOBAL','ĐẦU GHI HÌNH GLOBAL','ĐẦU GHI HÌNH GLOBAL','','','1427446490','1448192709','0','1','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('363','CAMERA IP','camera-ip-global','0','9','','','','1','2','CAMERA IP GLOBAL','CAMERA IP GLOBAL','CAMERA IP GLOBAL','','','1427447480','1448192689','0','1','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('379','CAMERA IP','camera-ip-eyewide','0','2','','','','0','2','CAMERA IP EYEWIDE','CAMERA IP EYEWIDE','CAMERA IP EYEWIDE','','','1429586855','1448198374','1','1','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('380','CAMERA AHD','camera-ahd-global','0','9','','','','0','3','CAMERA AHD GLOBAL','CAMERA AHD GLOBAL','CAMERA AHD GLOBAL','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('381','CAMERA AHD','camera-ahd-vdtech','0','4','','','','0','4','CAMERA AHD VDTECH','CAMERA AHD VDTECH','CAMERA AHD VDTECH','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('382','CAMERA ANALOG','camera-analog-vdtech','0','4','','','','0','5','CAMERA ANALOG VDTECH','CAMERA ANALOG VDTECH','CAMERA ANALOG VDTECH','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('383','CAMERA AHD','camera-ahd-eyewide','0','2','','','','0','6','CAMERA AHD EYEWIDE','CAMERA AHD EYEWIDE','CAMERA AHD EYEWIDE','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('384','CAMERA ANALOG','camera-analog-eyewide','0','2','','','','0','7','CAMERA ANALOG EYEWIDE','CAMERA ANALOG EYEWIDE','CAMERA ANALOG EYEWIDE','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('385','TRUNG TÂM BÁO CHÁY','trung-tam-bao-chay','0','10','','','','0','8','TRUNG TÂM BÁO CHÁY','TRUNG TÂM BÁO CHÁY','TRUNG TÂM BÁO CHÁY','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('386','ĐẦU BÁO KHÓI','dau-bao-khoi','0','10','','','','0','9','ĐẦU BÁO KHÓI','ĐẦU BÁO KHÓI','ĐẦU BÁO KHÓI','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('387','ĐẦU BÁO NHIỆT','dau-bao-nhiet','0','10','','','','0','10','ĐẦU BÁO NHIỆT','ĐẦU BÁO NHIỆT','ĐẦU BÁO NHIỆT','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('388','ĐẦU BÁO RÒ GA','dau-bao-ro-ga','0','10','','','','0','11','ĐẦU BÁO RÒ GA','ĐẦU BÁO RÒ GA','ĐẦU BÁO RÒ GA','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('389','TRUNG TÂM BÁO ĐỘNG','trung-tam-bao-dong','0','11','','','','0','12','TRUNG TÂM BÁO ĐỘNG','TRUNG TÂM BÁO ĐỘNG','TRUNG TÂM BÁO ĐỘNG','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('390','ĐẦU BÁO CHUYỂN ĐỘNG','dau-bao-chuyen-dong','0','11','','','','0','13','ĐẦU BÁO CHUYỂN ĐỘNG','ĐẦU BÁO CHUYỂN ĐỘNG','ĐẦU BÁO CHUYỂN ĐỘNG','','',NULL,NULL,'0','0','0');
INSERT INTO `cate` (`id`,`cate_name`,`cate_alias`,`parent_id`,`cate_type_id`,`image_url`,`icon_url`,`content`,`is_hot`,`display_order`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`) VALUES ('391','ĐẦU BÁO CỬA TỪ','dau-bao-cua-tu','0','11','','','','0','14','ĐẦU BÁO CỬA TỪ','ĐẦU BÁO CỬA TỪ','ĐẦU BÁO CỬA TỪ','','',NULL,NULL,'0','0','0');
/*!40000 ALTER TABLE `cate` ENABLE KEYS */;


--
-- Create Table `cate_type`
--

DROP TABLE IF EXISTS `cate_type`;
CREATE TABLE `cate_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_type_name` varchar(255) NOT NULL,
  `cate_type_alias` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `icon_url` varchar(255) NOT NULL,
  `is_menu` tinyint(1) NOT NULL,
  `display_order` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT '0',
  `created_by` tinyint(4) NOT NULL,
  `updated_by` tinyint(4) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Data for Table `cate_type`
--

/*!40000 ALTER TABLE `cate_type` DISABLE KEYS */;
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('2','EYEWIDE','eyewide','EYEWIDE','','','1','3','1425195921','1448192461','0','0','1','EYEWIDE','EYEWIDE','EYEWIDE');
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('4','VDTECH','vdtech','VDTECH','','','1','2','1425196015','1448192449','0','0','1','VDTECH','VDTECH','VDTECH');
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('9','GLOBAL','global','GLOBAL','','','1','1','1425196216','1448192430','0','0','1','Global','Global','Global');
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('10','BÁO CHÁY','bao-chay','BÁO CHÁY','','','0','4','1448192494','1448192494','0','1','1','BÁO CHÁY','BÁO CHÁY','BÁO CHÁY');
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('11','BÁO ĐỘNG','bao-dong','BÁO ĐỘNG','','','0','5','1448192509','1448192509','0','1','1','BÁO ĐỘNG','BÁO ĐỘNG','BÁO ĐỘNG');
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('12','TỔNG ĐÀI ĐIỆN THOẠI','tong-dai-dien-thoai','TỔNG ĐÀI ĐIỆN THOẠI','','','0','6','1448192536','1448192536','0','1','1','TỔNG ĐÀI ĐIỆN THOẠI','TỔNG ĐÀI ĐIỆN THOẠI','TỔNG ĐÀI ĐIỆN THOẠI');
INSERT INTO `cate_type` (`id`,`cate_type_name`,`cate_type_alias`,`description`,`image_url`,`icon_url`,`is_menu`,`display_order`,`created_at`,`updated_at`,`hidden`,`created_by`,`updated_by`,`meta_title`,`meta_description`,`meta_keyword`) VALUES ('13','PHỤ KIỆN','phu-kien','PHỤ KIỆN','','','0','7','1448192545','1448192545','0','1','1','PHỤ KIỆN','PHỤ KIỆN','PHỤ KIỆN');
/*!40000 ALTER TABLE `cate_type` ENABLE KEYS */;


--
-- Create Table `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) NOT NULL,
  `city_alias` varchar(255) NOT NULL,
  `display_order` int(11) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Data for Table `city`
--

/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` (`city_id`,`city_name`,`city_alias`,`display_order`) VALUES ('1','Hồ Chí Minh','ho-chi-minh','1');
INSERT INTO `city` (`city_id`,`city_name`,`city_alias`,`display_order`) VALUES ('2','Hà Nội','ha-noi','2');
INSERT INTO `city` (`city_id`,`city_name`,`city_alias`,`display_order`) VALUES ('10','Đà Nẵng','da-nang','3');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;


--
-- Create Table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `city_id` tinyint(4) NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8 NOT NULL,
  `handphone` varchar(50) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) CHARACTER SET utf8 NOT NULL,
  `last_login` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Data for Table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('1','NGuyen Van Ti','123 abc','1','0456713412','0932535326','ti@gmail.com','titi','e10adc3949ba59abbe56e057f20f883e','1396303200','1396303200','1396303200',NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('2','Le van Teo','5666 CMT8','1','043662244','098657483','teo@gmail.com','teoteo','','1396303200','1396303200','1429952700','1','1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('3','NGuyen Van Hoang','123 abc','2','','0917492306','hoangnhonline@gmail.com','huyhoang','e10adc3949ba59abbe56e057f20f883e','1431229123','1431229123',NULL,NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('4','NGuyen Van Hoang','123 abc','1','0917492306','0917492306','hoangnhonline1@gmail.com','huyhoang1','e10adc3949ba59abbe56e057f20f883e','1431229232','1431229232',NULL,NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('5','NGuyen Van Hoang','123 abc','1','0917492306','0917492306','hoangnhonline2@gmail.com','huyhoang2','e10adc3949ba59abbe56e057f20f883e','1431229265','1431229265',NULL,NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('6','asdsf','fdsfasf','1','asfasf','asfasfs','ddd2@gmail.com','hoang999','e10adc3949ba59abbe56e057f20f883e','1431230050','1431230050',NULL,NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('7','dasgdsgds','dsfdsg','1','safsaf','asff','dddd@aac.com','huyhoang123','4297f44b13955235245b2497399d7a93','1431230155','1431230155',NULL,NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('8','fasf','safasf','1','fasf','safff','ddddd@aa.com','ddddd','e10adc3949ba59abbe56e057f20f883e','1431230404','1431230404',NULL,NULL,'1');
INSERT INTO `customer` (`id`,`full_name`,`address`,`city_id`,`phone`,`handphone`,`email`,`username`,`password`,`last_login`,`created_at`,`updated_at`,`updated_by`,`status`) VALUES ('9','fasf','asf','1','safs','asfsf','ddd@sss.com','ddddf','e10adc3949ba59abbe56e057f20f883e','1431230536','1431230536',NULL,NULL,'1');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Create Table `email_code`
--

DROP TABLE IF EXISTS `email_code`;
CREATE TABLE `email_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `code_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `email_code`
--

/*!40000 ALTER TABLE `email_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_code` ENABLE KEYS */;


--
-- Create Table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `feedback`
--

/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;


--
-- Create Table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `url_1` varchar(255) NOT NULL,
  `object_id` int(11) NOT NULL,
  `object_type` tinyint(4) NOT NULL COMMENT '1: post.    2 :article    3:project',
  `display_order` int(11) NOT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=532 DEFAULT CHARSET=utf8;

--
-- Data for Table `images`
--

/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('1','images/orient.png','images/orient.png','3500','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('2','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3501','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('3','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3502','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('4','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3503','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('5','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3504','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('6','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3505','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('7','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3506','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('8','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3507','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('9','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3508','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('10','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3509','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('11','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3510','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('12','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3511','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('13','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3512','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('14','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3513','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('15','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3514','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('16','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3515','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('17','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3516','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('18','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3517','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('19','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3518','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('21','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3520','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('22','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3521','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('23','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3522','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('24','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3523','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('25','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3524','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('26','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3525','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('27','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3526','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('28','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3527','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('29','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3528','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('30','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3529','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('31','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3530','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('32','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3531','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('33','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3532','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('34','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3533','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('35','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3534','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('36','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3535','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('37','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3536','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('38','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3537','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('39','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3538','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('40','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3539','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('41','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3540','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('42','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3541','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('43','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3542','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('44','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3543','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('45','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3544','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('46','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3545','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('47','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3546','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('48','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3547','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('49','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3548','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('50','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3549','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('51','images/orient.png','images/orient.png','3550','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('52','images/orient.png','images/orient.png','3551','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('53','images/orient.png','images/orient.png','3552','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('54','images/orient.png','images/orient.png','3553','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('55','images/orient.png','images/orient.png','3554','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('56','images/orient.png','images/orient.png','3555','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('57','images/orient.png','images/orient.png','3556','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('58','images/orient.png','images/orient.png','3557','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('59','images/orient.png','images/orient.png','3558','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('60','images/orient.png','images/orient.png','3559','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('61','images/orient.png','images/orient.png','3560','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('62','images/orient.png','images/orient.png','3561','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('63','images/orient.png','images/orient.png','3562','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('64','images/orient.png','images/orient.png','3563','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('65','images/orient.png','images/orient.png','3564','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('66','images/orient.png','images/orient.png','3565','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('67','images/orient.png','images/orient.png','3566','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('68','images/orient.png','images/orient.png','3567','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('69','images/orient.png','images/orient.png','3568','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('70','images/orient.png','images/orient.png','3569','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('71','images/orient.png','images/orient.png','3570','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('72','images/orient.png','images/orient.png','3571','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('73','images/orient.png','images/orient.png','3572','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('74','images/orient.png','images/orient.png','3573','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('75','images/orient.png','images/orient.png','3574','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('76','images/orient.png','images/orient.png','3575','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('77','images/orient.png','images/orient.png','3576','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('78','images/orient.png','images/orient.png','3577','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('79','images/orient.png','images/orient.png','3578','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('80','images/orient.png','images/orient.png','3579','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('81','images/orient.png','images/orient.png','3580','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('82','images/orient.png','images/orient.png','3581','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('83','images/orient.png','images/orient.png','3582','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('84','images/orient.png','images/orient.png','3583','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('85','images/orient.png','images/orient.png','3584','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('86','images/orient.png','images/orient.png','3585','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('87','images/orient.png','images/orient.png','3586','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('88','images/orient.png','images/orient.png','3587','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('89','images/orient.png','images/orient.png','3588','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('90','images/orient.png','images/orient.png','3589','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('91','images/orient.png','images/orient.png','3590','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('92','images/orient.png','images/orient.png','3591','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('93','images/orient.png','images/orient.png','3592','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('94','images/orient.png','images/orient.png','3593','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('95','images/orient.png','images/orient.png','3594','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('96','images/orient.png','images/orient.png','3595','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('97','images/orient.png','images/orient.png','3596','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('98','images/orient.png','images/orient.png','3597','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('99','images/orient.png','images/orient.png','3598','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('100','images/orient.png','images/orient.png','3599','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('101','images/orient.png','images/orient.png','3600','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('102','images/titan.jpg','images/titan.jpg','3601','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('103','images/titan.jpg','images/titan.jpg','3602','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('104','images/titan.jpg','images/titan.jpg','3603','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('105','images/titan.jpg','images/titan.jpg','3604','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('106','images/titan.jpg','images/titan.jpg','3605','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('107','images/titan.jpg','images/titan.jpg','3606','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('108','images/titan.jpg','images/titan.jpg','3607','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('109','images/titan.jpg','images/titan.jpg','3608','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('110','images/titan.jpg','images/titan.jpg','3609','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('111','images/titan.jpg','images/titan.jpg','3610','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('112','images/titan.jpg','images/titan.jpg','3611','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('113','images/titan.jpg','images/titan.jpg','3612','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('114','images/titan.jpg','images/titan.jpg','3613','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('115','images/titan.jpg','images/titan.jpg','3614','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('116','images/titan.jpg','images/titan.jpg','3615','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('117','images/titan.jpg','images/titan.jpg','3616','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('118','images/titan.jpg','images/titan.jpg','3617','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('119','images/titan.jpg','images/titan.jpg','3618','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('120','images/titan.jpg','images/titan.jpg','3619','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('121','images/titan.jpg','images/titan.jpg','3620','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('122','images/titan.jpg','images/titan.jpg','3621','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('123','images/titan.jpg','images/titan.jpg','3622','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('124','images/titan.jpg','images/titan.jpg','3623','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('125','images/titan.jpg','images/titan.jpg','3624','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('126','images/titan.jpg','images/titan.jpg','3625','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('127','images/titan.jpg','images/titan.jpg','3626','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('128','images/titan.jpg','images/titan.jpg','3627','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('129','images/titan.jpg','images/titan.jpg','3628','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('130','images/titan.jpg','images/titan.jpg','3629','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('131','images/titan.jpg','images/titan.jpg','3630','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('132','images/titan.jpg','images/titan.jpg','3631','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('133','images/titan.jpg','images/titan.jpg','3632','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('134','images/titan.jpg','images/titan.jpg','3633','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('135','images/titan.jpg','images/titan.jpg','3634','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('136','images/titan.jpg','images/titan.jpg','3635','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('137','images/titan.jpg','images/titan.jpg','3636','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('138','images/titan.jpg','images/titan.jpg','3637','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('139','images/titan.jpg','images/titan.jpg','3638','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('140','images/titan.jpg','images/titan.jpg','3639','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('141','images/titan.jpg','images/titan.jpg','3640','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('142','images/titan.jpg','images/titan.jpg','3641','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('143','images/titan.jpg','images/titan.jpg','3642','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('144','images/titan.jpg','images/titan.jpg','3643','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('145','images/titan.jpg','images/titan.jpg','3644','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('146','images/titan.jpg','images/titan.jpg','3645','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('147','images/titan.jpg','images/titan.jpg','3646','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('148','images/titan.jpg','images/titan.jpg','3647','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('149','images/titan.jpg','images/titan.jpg','3648','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('150','images/titan.jpg','images/titan.jpg','3649','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('151','images/orient.png','images/orient.png','3650','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('152','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3651','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('153','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3652','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('154','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3653','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('155','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3654','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('156','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3655','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('157','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3656','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('158','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3657','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('159','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3658','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('160','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3659','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('161','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3660','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('162','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3661','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('163','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3662','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('164','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3663','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('165','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3664','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('166','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3665','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('167','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3666','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('168','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3667','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('169','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3668','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('170','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3669','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('171','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3670','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('172','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3671','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('173','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3672','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('174','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3673','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('175','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3674','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('176','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3675','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('177','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3676','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('178','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3677','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('179','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3678','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('180','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3679','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('181','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3680','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('182','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3681','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('183','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3682','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('184','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3683','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('185','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3684','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('186','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3685','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('187','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3686','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('188','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3687','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('189','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3688','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('190','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3689','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('191','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3690','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('192','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3691','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('193','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3692','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('194','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3693','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('195','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3694','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('196','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3695','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('197','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3696','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('198','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3697','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('199','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3698','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('200','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3699','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('201','images/orient.png','images/orient.png','3700','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('202','images/orient.png','images/orient.png','3701','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('203','images/orient.png','images/orient.png','3702','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('204','images/orient.png','images/orient.png','3703','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('205','images/orient.png','images/orient.png','3704','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('206','images/orient.png','images/orient.png','3705','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('207','images/orient.png','images/orient.png','3706','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('208','images/orient.png','images/orient.png','3707','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('209','images/orient.png','images/orient.png','3708','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('210','images/orient.png','images/orient.png','3709','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('211','images/orient.png','images/orient.png','3710','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('212','images/orient.png','images/orient.png','3711','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('213','images/orient.png','images/orient.png','3712','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('214','images/orient.png','images/orient.png','3713','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('215','images/orient.png','images/orient.png','3714','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('216','images/orient.png','images/orient.png','3715','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('217','images/orient.png','images/orient.png','3716','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('218','images/orient.png','images/orient.png','3717','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('219','images/orient.png','images/orient.png','3718','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('220','images/orient.png','images/orient.png','3719','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('221','images/orient.png','images/orient.png','3720','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('222','images/orient.png','images/orient.png','3721','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('223','images/orient.png','images/orient.png','3722','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('224','images/orient.png','images/orient.png','3723','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('225','images/orient.png','images/orient.png','3724','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('226','images/orient.png','images/orient.png','3725','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('227','images/orient.png','images/orient.png','3726','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('228','images/orient.png','images/orient.png','3727','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('229','images/orient.png','images/orient.png','3728','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('230','images/orient.png','images/orient.png','3729','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('231','images/orient.png','images/orient.png','3730','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('232','images/orient.png','images/orient.png','3731','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('233','images/orient.png','images/orient.png','3732','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('234','images/orient.png','images/orient.png','3733','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('235','images/orient.png','images/orient.png','3734','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('236','images/orient.png','images/orient.png','3735','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('237','images/orient.png','images/orient.png','3736','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('238','images/orient.png','images/orient.png','3737','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('239','images/orient.png','images/orient.png','3738','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('240','images/orient.png','images/orient.png','3739','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('241','images/orient.png','images/orient.png','3740','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('242','images/orient.png','images/orient.png','3741','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('243','images/orient.png','images/orient.png','3742','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('244','images/orient.png','images/orient.png','3743','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('245','images/orient.png','images/orient.png','3744','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('246','images/orient.png','images/orient.png','3745','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('247','images/orient.png','images/orient.png','3746','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('248','images/orient.png','images/orient.png','3747','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('249','images/orient.png','images/orient.png','3748','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('250','images/orient.png','images/orient.png','3749','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('251','images/orient.png','images/orient.png','3750','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('252','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3751','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('253','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3752','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('254','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3753','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('255','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3754','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('256','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3755','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('257','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3756','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('258','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3757','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('259','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3758','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('260','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3759','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('261','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3760','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('262','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3761','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('263','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3762','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('264','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3763','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('265','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3764','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('266','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3765','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('267','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3766','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('268','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3767','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('269','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3768','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('270','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3769','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('271','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3770','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('272','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3771','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('273','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3772','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('274','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3773','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('275','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3774','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('276','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3775','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('277','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3776','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('278','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3777','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('279','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3778','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('280','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3779','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('281','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3780','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('282','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3781','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('283','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3782','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('284','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3783','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('285','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3784','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('286','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3785','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('287','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3786','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('288','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3787','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('289','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3788','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('290','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3789','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('291','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3790','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('292','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3791','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('293','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3792','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('294','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3793','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('295','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3794','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('296','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3795','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('297','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3796','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('298','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3797','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('299','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3798','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('300','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3799','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('301','images/orient.png','images/orient.png','3800','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('302','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3801','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('303','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3802','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('304','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3803','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('305','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3804','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('306','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3805','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('307','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3806','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('308','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3807','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('309','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3808','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('310','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3809','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('311','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3810','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('312','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3811','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('313','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3812','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('314','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3813','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('315','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3814','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('316','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3815','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('317','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3816','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('318','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3817','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('319','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3818','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('320','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3819','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('321','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3820','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('322','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3821','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('323','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3822','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('324','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3823','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('325','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3824','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('326','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3825','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('327','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3826','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('328','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3827','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('329','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3828','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('330','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3829','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('331','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3830','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('332','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3831','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('333','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3832','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('334','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3833','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('335','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3834','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('336','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3835','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('337','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3836','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('338','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3837','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('339','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3838','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('340','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3839','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('341','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3840','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('342','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3841','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('343','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3842','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('344','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3843','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('345','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3844','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('346','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3845','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('347','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3846','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('348','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3847','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('349','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3848','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('350','images/dong-ho-citizen.jpg','images/dong-ho-citizen.jpg','3849','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('351','images/orient.png','images/orient.png','3850','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('352','images/orient.png','images/orient.png','3851','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('353','images/orient.png','images/orient.png','3852','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('354','images/orient.png','images/orient.png','3853','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('355','images/orient.png','images/orient.png','3854','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('356','images/orient.png','images/orient.png','3855','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('357','images/orient.png','images/orient.png','3856','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('358','images/orient.png','images/orient.png','3857','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('359','images/orient.png','images/orient.png','3858','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('360','images/orient.png','images/orient.png','3859','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('361','images/orient.png','images/orient.png','3860','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('362','images/orient.png','images/orient.png','3861','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('363','images/orient.png','images/orient.png','3862','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('364','images/orient.png','images/orient.png','3863','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('365','images/orient.png','images/orient.png','3864','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('366','images/orient.png','images/orient.png','3865','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('367','images/orient.png','images/orient.png','3866','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('368','images/orient.png','images/orient.png','3867','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('369','images/orient.png','images/orient.png','3868','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('370','images/orient.png','images/orient.png','3869','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('371','images/orient.png','images/orient.png','3870','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('372','images/orient.png','images/orient.png','3871','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('373','images/orient.png','images/orient.png','3872','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('374','images/orient.png','images/orient.png','3873','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('375','images/orient.png','images/orient.png','3874','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('376','images/orient.png','images/orient.png','3875','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('377','images/orient.png','images/orient.png','3876','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('378','images/orient.png','images/orient.png','3877','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('379','images/orient.png','images/orient.png','3878','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('380','images/orient.png','images/orient.png','3879','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('381','images/orient.png','images/orient.png','3880','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('382','images/orient.png','images/orient.png','3881','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('383','images/orient.png','images/orient.png','3882','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('384','images/orient.png','images/orient.png','3883','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('385','images/orient.png','images/orient.png','3884','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('386','images/orient.png','images/orient.png','3885','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('387','images/orient.png','images/orient.png','3886','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('388','images/orient.png','images/orient.png','3887','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('389','images/orient.png','images/orient.png','3888','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('390','images/orient.png','images/orient.png','3889','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('391','images/orient.png','images/orient.png','3890','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('393','images/orient.png','images/orient.png','3892','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('394','images/orient.png','images/orient.png','3893','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('395','images/orient.png','images/orient.png','3894','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('396','images/orient.png','images/orient.png','3895','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('397','images/orient.png','images/orient.png','3896','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('398','images/orient.png','images/orient.png','3897','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('399','images/orient.png','images/orient.png','3898','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('400','images/orient.png','images/orient.png','3899','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('401','images/orient.png','images/orient.png','3900','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('402','images/titan.jpg','images/titan.jpg','3901','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('403','images/titan.jpg','images/titan.jpg','3902','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('404','images/titan.jpg','images/titan.jpg','3903','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('405','images/titan.jpg','images/titan.jpg','3904','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('406','images/titan.jpg','images/titan.jpg','3905','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('407','images/titan.jpg','images/titan.jpg','3906','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('408','images/titan.jpg','images/titan.jpg','3907','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('409','images/titan.jpg','images/titan.jpg','3908','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('410','images/titan.jpg','images/titan.jpg','3909','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('411','images/titan.jpg','images/titan.jpg','3910','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('412','images/titan.jpg','images/titan.jpg','3911','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('413','images/titan.jpg','images/titan.jpg','3912','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('414','images/titan.jpg','images/titan.jpg','3913','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('415','images/titan.jpg','images/titan.jpg','3914','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('416','images/titan.jpg','images/titan.jpg','3915','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('417','images/titan.jpg','images/titan.jpg','3916','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('418','images/titan.jpg','images/titan.jpg','3917','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('419','images/titan.jpg','images/titan.jpg','3918','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('420','images/titan.jpg','images/titan.jpg','3919','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('421','images/titan.jpg','images/titan.jpg','3920','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('422','images/titan.jpg','images/titan.jpg','3921','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('423','images/titan.jpg','images/titan.jpg','3922','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('424','images/titan.jpg','images/titan.jpg','3923','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('425','images/titan.jpg','images/titan.jpg','3924','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('426','images/titan.jpg','images/titan.jpg','3925','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('427','images/titan.jpg','images/titan.jpg','3926','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('428','images/titan.jpg','images/titan.jpg','3927','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('429','images/titan.jpg','images/titan.jpg','3928','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('430','images/titan.jpg','images/titan.jpg','3929','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('431','images/titan.jpg','images/titan.jpg','3930','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('432','images/titan.jpg','images/titan.jpg','3931','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('433','images/titan.jpg','images/titan.jpg','3932','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('434','images/titan.jpg','images/titan.jpg','3933','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('435','images/titan.jpg','images/titan.jpg','3934','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('436','images/titan.jpg','images/titan.jpg','3935','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('437','images/titan.jpg','images/titan.jpg','3936','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('438','images/titan.jpg','images/titan.jpg','3937','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('439','images/titan.jpg','images/titan.jpg','3938','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('440','images/titan.jpg','images/titan.jpg','3939','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('441','images/titan.jpg','images/titan.jpg','3940','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('442','images/titan.jpg','images/titan.jpg','3941','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('443','images/titan.jpg','images/titan.jpg','3942','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('444','images/titan.jpg','images/titan.jpg','3943','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('445','images/titan.jpg','images/titan.jpg','3944','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('446','images/titan.jpg','images/titan.jpg','3945','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('447','images/titan.jpg','images/titan.jpg','3946','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('448','images/titan.jpg','images/titan.jpg','3947','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('449','images/titan.jpg','images/titan.jpg','3948','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('450','images/titan.jpg','images/titan.jpg','3949','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('451','images/orient.png','images/orient.png','3950','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('452','images/orient.png','images/orient.png','3951','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('453','images/orient.png','images/orient.png','3952','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('454','images/orient.png','images/orient.png','3953','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('455','images/orient.png','images/orient.png','3954','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('456','images/orient.png','images/orient.png','3955','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('457','images/orient.png','images/orient.png','3956','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('458','images/orient.png','images/orient.png','3957','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('459','images/orient.png','images/orient.png','3958','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('460','images/orient.png','images/orient.png','3959','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('461','images/orient.png','images/orient.png','3960','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('462','images/orient.png','images/orient.png','3961','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('463','images/orient.png','images/orient.png','3962','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('464','images/orient.png','images/orient.png','3963','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('465','images/orient.png','images/orient.png','3964','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('466','images/orient.png','images/orient.png','3965','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('467','images/orient.png','images/orient.png','3966','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('468','images/orient.png','images/orient.png','3967','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('469','images/orient.png','images/orient.png','3968','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('470','images/orient.png','images/orient.png','3969','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('471','images/orient.png','images/orient.png','3970','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('472','images/orient.png','images/orient.png','3971','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('473','images/orient.png','images/orient.png','3972','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('474','images/orient.png','images/orient.png','3973','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('475','images/orient.png','images/orient.png','3974','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('476','images/orient.png','images/orient.png','3975','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('477','images/orient.png','images/orient.png','3976','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('478','images/orient.png','images/orient.png','3977','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('479','images/orient.png','images/orient.png','3978','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('480','images/orient.png','images/orient.png','3979','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('481','images/orient.png','images/orient.png','3980','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('482','images/orient.png','images/orient.png','3981','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('483','images/orient.png','images/orient.png','3982','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('484','images/orient.png','images/orient.png','3983','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('485','images/orient.png','images/orient.png','3984','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('486','images/orient.png','images/orient.png','3985','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('490','images/orient.png','images/orient.png','3989','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('492','images/orient.png','images/orient.png','3991','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('493','images/orient.png','images/orient.png','3992','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('494','images/orient.png','images/orient.png','3993','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('495','images/orient.png','images/orient.png','3994','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('496','images/orient.png','images/orient.png','3995','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('497','images/orient.png','images/orient.png','3996','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('500','images/orient.png','images/orient.png','3999','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('501','images/orient.png','images/orient.png','4000','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('502','upload/2015/08/29/jellyfish_1440834360.jpg','upload/2015/08/29/jellyfish_1440834360_2.jpg','3895','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('503','upload/2015/08/29/desert_1440834360.jpg','upload/2015/08/29/desert_1440834360_2.jpg','3895','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('505','upload/2015/09/01/326_pp_vdt_405b_1441071211.jpg','upload/2015/09/01/326_pp_vdt_405b_1441071211_2.jpg','3998','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('506','upload/2015/09/01/camera-vdtech-vdt-666ahdl-13_1441071289.jpg','upload/2015/09/01/camera-vdtech-vdt-666ahdl-13_1441071289_2.jpg','3990','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('511','upload/2015/09/01/326_pp_vdt_405b_1441073053.jpg','upload/2015/09/01/326_pp_vdt_405b_1441073053_2.jpg','3891','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('512','upload/2015/09/01/camera-vdtech-vdt-666ahdl-13_1441073110.jpg','upload/2015/09/01/camera-vdtech-vdt-666ahdl-13_1441073110_2.jpg','3997','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('513','upload/2015/09/01/326_pp_vdt_405b_1441073435.jpg','upload/2015/09/01/326_pp_vdt_405b_1441073435_2.jpg','3988','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('514','upload/2015/09/01/p_5621_camera-vdtech-vdt-405ea_1441073435.jpg','upload/2015/09/01/p_5621_camera-vdtech-vdt-405ea_1441073435_2.jpg','3988','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('515','upload/2015/09/01/vdt-135zf_1441074690.jpg','upload/2015/09/01/vdt-135zf_1441074690_2.jpg','3519','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('522','upload/2015/11/24/1444628659_22_1448346428.png','upload/2015/11/24/1444628659_22_1448346428_2.png','3','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('523','upload/2015/11/24/1444959386_312_1448346471.png','upload/2015/11/24/1444959386_312_1448346471_2.png','4','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('524','upload/2015/11/24/1443885574_141_1448346525.png','upload/2015/11/24/1443885574_141_1448346525_2.png','5','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('525','upload/2015/11/24/1444020629_21_1448346559.png','upload/2015/11/24/1444020629_21_1448346559_2.png','6','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('526','upload/2015/11/24/1443886508_182_1448346591.png','upload/2015/11/24/1443886508_182_1448346591_2.png','7','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('527','upload/2015/11/24/350_vdt_135_135ea_1448346739.png','upload/2015/11/24/350_vdt_135_135ea_1448346739_2.png','8','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('528','upload/2015/11/24/350_vdtech_vdt1351_1448346715.jpg','upload/2015/11/24/350_vdtech_vdt1351_1448346715_2.jpg','9','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('529','upload/2015/11/24/350_vdt_27cvi_13_11_1448346727.png','upload/2015/11/24/350_vdt_27cvi_13_11_1448346727_2.png','10','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('530','upload/2015/11/24/1443885574_141_1448349392.png','upload/2015/11/24/1443885574_141_1448349392_2.png','11','1','1');
INSERT INTO `images` (`image_id`,`url`,`url_1`,`object_id`,`object_type`,`display_order`) VALUES ('531','upload/2015/11/25/nga_tho_2_1448422722.png','upload/2015/11/25/nga_tho_2_1448422722_2.png','11','1','1');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;


--
-- Create Table `link`
--

DROP TABLE IF EXISTS `link`;
CREATE TABLE `link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `text_link` varchar(255) NOT NULL,
  `block_id` int(11) NOT NULL,
  `link_url` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8;

--
-- Data for Table `link`
--

/*!40000 ALTER TABLE `link` DISABLE KEYS */;
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('114','Hướng dẫn mua hàng','4','http://google.com','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('115','Vận chuyển - giao hàng','4','http://google.com','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('116','Phương thức thanh toán','4','http://google.com','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('117','Hướng dẫn tạo tài khoản','4','http://google.com','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('118','Phương thức đổi - trả hàng','4','http://google.com','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('119','Về donghonghia.com','3','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('120','Hệ thống cửa hàng','3','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('121','Khuyến mại','3','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('122','Tuyển dụng','3','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('123','Liên hệ','3','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('124','Chính sách bảo hành','9','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('125','Chính sách tích điểm','9','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('126','Chính sách bán sỉ','9','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('127','Chính sách ký gửi sản phẩm','9','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('128','Bảo mật thông tin cá nhân','9','#','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('149','Giới thiệu','10','gioi-thieu.html','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('150','Hướng dẫn mua hàng','10','huong-dan-mua-hang.html','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('151','Phương thức thanh toán','10','phuong-thuc-thanh-toan.html','1');
INSERT INTO `link` (`link_id`,`text_link`,`block_id`,`link_url`,`status`) VALUES ('152','Bảo hành','10','bao-hanh.html','1');
/*!40000 ALTER TABLE `link` ENABLE KEYS */;


--
-- Create Table `manu`
--

DROP TABLE IF EXISTS `manu`;
CREATE TABLE `manu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manu_name` varchar(255) NOT NULL,
  `manu_alias` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) NOT NULL,
  `is_hot` tinyint(1) NOT NULL,
  `display_order` int(11) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` tinyint(4) NOT NULL,
  `updated_by` tinyint(4) NOT NULL,
  `hidden` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `manu`
--

/*!40000 ALTER TABLE `manu` DISABLE KEYS */;
/*!40000 ALTER TABLE `manu` ENABLE KEYS */;


--
-- Create Table `manu_catetype`
--

DROP TABLE IF EXISTS `manu_catetype`;
CREATE TABLE `manu_catetype` (
  `manu_id` int(11) NOT NULL,
  `catetype_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `manu_catetype`
--

/*!40000 ALTER TABLE `manu_catetype` DISABLE KEYS */;
/*!40000 ALTER TABLE `manu_catetype` ENABLE KEYS */;


--
-- Create Table `method`
--

DROP TABLE IF EXISTS `method`;
CREATE TABLE `method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data for Table `method`
--

/*!40000 ALTER TABLE `method` DISABLE KEYS */;
INSERT INTO `method` (`id`,`name`) VALUES ('1','Chuyển khoản qua ngân hàng');
INSERT INTO `method` (`id`,`name`) VALUES ('2','Thanh toán tại cửa hàng');
INSERT INTO `method` (`id`,`name`) VALUES ('3','Giao hàng thu tiền tận nơi (COD)');
/*!40000 ALTER TABLE `method` ENABLE KEYS */;


--
-- Create Table `order_detail`
--

DROP TABLE IF EXISTS `order_detail`;
CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `creation_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `order_detail`
--

/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;


--
-- Create Table `order_info`
--

DROP TABLE IF EXISTS `order_info`;
CREATE TABLE `order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `order_type` tinyint(4) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `delivery_date` int(11) NOT NULL,
  `delivery_hour` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `use_voucher` tinyint(1) NOT NULL,
  `voucher_code` varchar(20) NOT NULL,
  `export_order` tinyint(1) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_address` varchar(255) NOT NULL,
  `tax_no` varchar(50) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Data for Table `order_info`
--

/*!40000 ALTER TABLE `order_info` DISABLE KEYS */;
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('1','3898','1','safasf','fasfasf','asfasfasf','asfsaf@aa.com','1','0','0','1','1','0','','0','','','',NULL,'1','1434367373',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('2','3898','1','sdasd','asdas','safasf','afasf@aa.com','1','0','10','1','1','1','safasf','1','safasf','safasf','safasf',NULL,'1','1434367474',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('3','3898','1','asfasf','safsaf','safasffassd','safasf@aa.com','1','1434924000','10','1','1','0','','0','','','',NULL,'1','1434876549',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('4','3795','1','sdaf','safasf','asfasfasf','asfasf@aa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435154740',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('5','3795','1','sd','asdasda','sdasdasd','dddd@gg.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435154979',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('6','3795','1','sd','asdasda','sdasdasd','dddd@gg.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435154981',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('7','3795','1','sd','asdasda','sdasdasd','dddd@gg.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435154984',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('8','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155007',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('9','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155016',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('10','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155017',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('11','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155017',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('12','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155018',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('13','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155019',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('14','3795','1','sdasd','sadasd','asfasfsf','sadasd@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155019',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('15','3795','1','sdasd','sadasd','sadasdas','2222@aff.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435155347',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('16','3795','1','à','àasf','dâfasf','fffff@afadsfs.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435156012',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('17','3795','1','sadasd','122412','sâffff','ffff@aa.com','1','1435183200','10','1','1','1','EEEEE','1','FPT online','123 abc','09325523532325',NULL,'1','1435156859',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('18','3795','1','sg','dsgas','sdgadsgsdg','gsdgasdgs@sa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435157654',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('19','3795','1','sdasf','asfasf','safasfsaf','ssss@aaa.com','1','1435183200','10','1','1','0','','0','','','',NULL,'1','1435158597',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('20','3947','1','fasfasf','safasfasfasf','safasfasfasfa','aaa@aaa.com','1','1436738400','10','1','1','0','','0','','','',NULL,'1','1436699026',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('21','3596','1','dsfdsgdgsdsg','099325235','dgsdgsdg','sasafas@aa.com','1','1436738400','10','1','1','0','','0','','','',NULL,'1','1436699194',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('22','3647','2','sadasf','saasf','','ssfa@aa.com','1','1438556400','0','0','0','0','','0','','','',NULL,'1','1438535565',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('23','3891','1','asdfasdf','1234','asfd','asdf@gmail.com','1','1439161200','10','1','1','0','','0','','','',NULL,'1','1439136143',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('24','3891','1','afdas','1234','asdf','adf@gmail.com','1','1439161200','10','1','1','0','','0','','','',NULL,'1','1439137079',NULL);
INSERT INTO `order_info` (`id`,`product_id`,`order_type`,`customer_name`,`phone_number`,`address`,`email`,`gender`,`delivery_date`,`delivery_hour`,`city_id`,`state_id`,`use_voucher`,`voucher_code`,`export_order`,`company_name`,`company_address`,`tax_no`,`customer_id`,`status`,`created_at`,`updated_at`) VALUES ('25','3898','1','asdf','1234','asdf123','asdf@gmail.com','1','1439852400','10','1','1','0','','0','','','',NULL,'1','1439802237',NULL);
/*!40000 ALTER TABLE `order_info` ENABLE KEYS */;


--
-- Create Table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(20) CHARACTER SET utf8 NOT NULL,
  `sub_total` int(11) NOT NULL,
  `vat` int(11) NOT NULL,
  `ship` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `total_amount` tinyint(4) NOT NULL,
  `method_id` tinyint(4) NOT NULL,
  `order_note` varchar(500) CHARACTER SET utf8 NOT NULL,
  `staff_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `staff_note` varchar(500) CHARACTER SET utf8 NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` int(11) NOT NULL,
  `delivery_date` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `buyer_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `buyer_gender` tinyint(1) NOT NULL,
  `buyer_address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `buyer_city_id` tinyint(4) NOT NULL,
  `buyer_phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `buyer_handphone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `buyer_indentity_card` varchar(20) CHARACTER SET utf8 NOT NULL,
  `buyer_email` varchar(200) CHARACTER SET utf8 NOT NULL,
  `recipients_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `recipients_gender` tinyint(1) NOT NULL,
  `recipients_address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `recipients_city_id` tinyint(4) NOT NULL,
  `recipients_phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `recipients_handphone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `recipients_indentity_card` varchar(20) CHARACTER SET utf8 NOT NULL,
  `recipients_email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `orders`
--

/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;


--
-- Create Table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(255) NOT NULL,
  `page_alias` varchar(255) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` text,
  `is_hot` tinyint(1) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_text` text NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `pages`
--

/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` (`id`,`page_name`,`page_alias`,`category_id`,`image_url`,`description`,`content`,`is_hot`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`,`created_at`,`updated_at`,`status`) VALUES ('1','Download phần mềm','download-phan-mem','0','','','<div class=\"margin-top:100px\">\r\n	<ul>\r\n		<li>\r\n			<h3>\r\n				<a href=\"http://www.mediafire.com/download/yfmjf4gmapui82m/CMS3.0+V1.0.0.29.exe\" target=\"_blank\">PHẦN MỀM XEM TR&Ecirc;N M&Aacute;Y T&Iacute;NH AHD CMS 3.0 GLOBAL</a></h3>\r\n		</li>\r\n		<li>\r\n			<h3>\r\n				<a href=\"http://baotoan.com.vn/download/VDTECH-SOFTWARE-cua-IP-va-dau-ghi-AHD.rar\" target=\"_blank\">PHẦN MỀM CMS VDTECH ( AHD &ndash; IP )</a></h3>\r\n		</li>\r\n		<li>\r\n			<h3>\r\n				<a href=\"https://www.fshare.vn/file/5HMH79GARPYF\" target=\"_blank\">TEAMVIEWER 9</a></h3>\r\n		</li>\r\n	</ul>\r\n</div>\r\n',NULL,'Download phần mềm','Download phần mềm','Download phần mềm','','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;


--
-- Create Table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
CREATE TABLE `privilege` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `parent_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Data for Table `privilege`
--

/*!40000 ALTER TABLE `privilege` DISABLE KEYS */;
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('1','Danh mục chính','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('3','Chỉnh sửa','1');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('4','Xóa','1');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('5','Danh mục con','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('7','Thêm mới','5');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('8','Chỉnh sửa','5');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('9','Xóa','5');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('10','Thêm mới','1');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('11','Sản phẩm','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('13','Thêm mới','11');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('14','Chỉnh sửa','11');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('15','Xóa','11');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('16','Đơn hàng','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('17','Chỉnh sửa','16');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('18','Xóa','16');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('19','Thương hiệu','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('20','Thêm mới','19');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('21','Chỉnh sửa','19');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('22','Xóa','19');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('23','Khách hàng','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('24','Chỉnh sửa','23');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('25','Xóa','23');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('26','Nhân viên','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('27','Tạo mới','26');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('28','Chỉnh sửa','26');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('29','Xóa ','26');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('30','Trang nội dung','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('31','Thêm mới','30');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('32','Chỉnh sửa','30');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('33','Xóa','30');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('34','Danh mục bài viết','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('35','Thêm mới','34');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('36','Chỉnh sửa','34');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('37','Xóa','34');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('38','Bài viết','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('39','Thêm mới','38');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('40','Chỉnh sửa','38');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('41','Xóa','38');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('42','Độ tuổi','0');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('43','Thêm mới','42');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('44','Chỉnh sửa','42');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('45','Xóa','42');
INSERT INTO `privilege` (`id`,`name`,`parent_id`) VALUES ('46','Phân quyền','26');
/*!40000 ALTER TABLE `privilege` ENABLE KEYS */;


--
-- Create Table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `product_alias` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` text,
  `guide_use` text,
  `guarantee` text NOT NULL,
  `is_new` tinyint(1) NOT NULL,
  `is_hot` tinyint(1) NOT NULL,
  `is_saleoff` tinyint(1) NOT NULL,
  `trangthai` tinyint(1) NOT NULL DEFAULT '0',
  `percent_deal` varchar(20) DEFAULT NULL,
  `display_order` int(11) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `color` varchar(100) NOT NULL,
  `price` varchar(20) DEFAULT NULL,
  `price_saleoff` int(11) DEFAULT NULL,
  `deal_amount` int(11) NOT NULL,
  `sale_hot` tinyint(1) DEFAULT '0',
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` tinyint(4) NOT NULL,
  `updated_by` tinyint(4) NOT NULL,
  `hidden` tinyint(1) DEFAULT '0',
  `manu_id` int(11) DEFAULT NULL,
  `cate_type_id` int(11) NOT NULL,
  `cate_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Data for Table `product`
--

/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('3','','TAG-A3B3-F2','TAG-A3B3-F2','tag-a3b3-f2','upload/2015/11/24/1444628659_22_1448346428.png','','','<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px; background-color: transparent;\">\r\n	<tbody style=\"box-sizing: border-box;\">\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Th&ocirc;ng số kỹ thuật</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;Độ ph&acirc;n giải</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				1080P</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Cảm biến</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Sony</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Chuẩn n&eacute;n h&igrave;nh ảnh</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				H.264, tốc độ m&atilde; h&oacute;a d&ograve;ng k&eacute;p</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Hỗ trợ</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;25/30 FPS@1920*1080</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;Độ nhạy s&aacute;ng</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;tối thiểu 0.01Lux@F1.2(0Lux IR LED on)</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;Tốc độ m&agrave;n chập</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;1/25 ~ 1/8000s</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Đ&egrave;n Led:</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				42 IrLed Tầm quan s&aacute;t hồng ngoại &nbsp;đến 35m trong đ&ecirc;m</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Hỗ trợ</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;2 luồng dữ liệu , khung h&igrave;nh 30fps, băng th&ocirc;ng 32kbps ~ 16Mbps</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				C&ocirc;ng nghệ</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				WDR 50-100dB, 3D-DNR/AGC/AWB/Chống ngược s&aacute;ng /H&igrave;nh &nbsp; &nbsp;ảnh xoay v&ograve;ng (90-270℃)</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Ph&aacute;t hiện chuyển động th&ocirc;ng minh, B&aacute;o động qua Email, bản đồ</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Số lượng truy cập tối đa đồng thời l&ecirc;n đến 10 người</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;Hỗ trợ</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				giao thức ONVIF 2.2</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;Hỗ trợ Android, Windows Mobile, Symbian, iPhone nền tảng gi&aacute;m s&aacute;t điện thoại th&ocirc;ng minh</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				&nbsp;DC 12V</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				12V</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Phần mềm</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				CMS miễn ph&iacute; ; IP66</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n','','','0','1','0','1','','1','','','1000000','0','0','0','0','0','TAG-A3B3-F2','TAG-A3B3-F2','TAG-A3B3-F2','1448346430','1448349599','0','0','0',NULL,'9','363');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('4','','TAG-A3C3-F2','TAG-A3C3-F2','tag-a3c3-f2','upload/2015/11/24/1444959386_312_1448346471.png','','','<h1 class=\"product_title entry-title\" itemprop=\"name\" style=\"box-sizing: border-box; margin: 0px 0px 8px; font-size: 18px; font-family: Roboto, Arial, Helvetica, sans-serif; font-weight: normal; line-height: 1.2; color: rgb(68, 68, 68); opacity: 1; visibility: visible; transition: opacity 0.24s ease-in-out; clear: none; padding: 0px; text-transform: uppercase; border: none;\">\r\n	&nbsp;</h1>\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; font-family: arial; font-size: 14px; line-height: 20px; background-color: transparent;\">\r\n	<tbody style=\"box-sizing: border-box;\">\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Th&ocirc;ng số kỹ thuật</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Độ ph&acirc;n giải</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				1080P; K&iacute;ch thước ống k&iacute;nh: 3.6mm</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Vỏ</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Kim loại</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Cảm biến</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				1/2.8 Sony IMX Cmos Sensor</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Đ&egrave;n Led</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				2 Led Array quan s&aacute;t xa đến 25m-30 trong đ&ecirc;m</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Cho ph&acirc;n giải HD tr&ecirc;n t&iacute;n hiệu đường d&acirc;y analog, với &nbsp;khoảng c&aacute;ch tối đa 500m</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Chống ngược s&aacute;ng: BLC / D &ndash; WDR, T&ugrave;y chỉnh chống ngược s&aacute;ng từng v&ugrave;ng độc lập.<br style=\"box-sizing: border-box;\" />\r\n				C&ocirc;ng nghệ ch&iacute;p chống s&eacute;t,sốc điện l&ecirc;n đến 6000V<br style=\"box-sizing: border-box;\" />\r\n				-Đạt chuẩn IP66</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				C&ocirc;ng nghệ IR CUT cao cấp được l&agrave;m bằng kim loại</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n','','','0','1','0','1','','1','','','2000000','0','0','0','0','0','TAG-A3C3-F2','TAG-A3C3-F2','TAG-A3C3-F2','1448346493','1448349606','0','0','0',NULL,'9','363');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('5','','TAG-I3B3-F36','TAG-I3B3-F36','tag-i3b3-f36','upload/2015/11/24/1443885574_141_1448346525.png','','','<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px; background-color: transparent;\">\r\n	<tbody style=\"box-sizing: border-box;\">\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Th&ocirc;ng số kỹ thuật</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Độ ph&acirc;n giải</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				1080P; K&iacute;ch thước ống k&iacute;nh: 3.6mm</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Vỏ</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Kim loại</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Cảm biến</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				1/2.8 Sony IMX Cmos Sensor</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Đ&egrave;n Led</td>\r\n			<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				2 Led Array quan s&aacute;t xa đến 25m-30 trong đ&ecirc;m</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Cho ph&acirc;n giải HD tr&ecirc;n t&iacute;n hiệu đường d&acirc;y analog, với &nbsp;khoảng c&aacute;ch tối đa 500m</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				Chống ngược s&aacute;ng: BLC / D &ndash; WDR, T&ugrave;y chỉnh chống ngược s&aacute;ng từng v&ugrave;ng độc lập.<br style=\"box-sizing: border-box;\" />\r\n				C&ocirc;ng nghệ ch&iacute;p chống s&eacute;t,sốc điện l&ecirc;n đến 6000V<br style=\"box-sizing: border-box;\" />\r\n				-Đạt chuẩn IP66</td>\r\n		</tr>\r\n		<tr style=\"box-sizing: border-box;\">\r\n			<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n				C&ocirc;ng nghệ IR CUT cao cấp được l&agrave;m bằng kim loại</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n','','','0','1','0','1','','1','','','1200000','0','0','0','0','0','TAG-I3B3-F36','TAG-I3B3-F36','TAG-I3B3-F36','1448346528','1448349587','0','0','0',NULL,'9','363');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('6','','TAG-I3B3P-F42','TAG-I3B3P-F42','tag-i3b3p-f42','upload/2015/11/24/1444020629_21_1448346559.png','','','&nbsp;\r\n<div>\r\n	<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; background-color: transparent;\">\r\n		<tbody style=\"box-sizing: border-box;\">\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Th&ocirc;ng số kỹ thuật</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ ph&acirc;n giải</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					1080P</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Cảm biến</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Sony</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Chuẩn n&eacute;n h&igrave;nh ảnh</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					H.264, tốc độ m&atilde; h&oacute;a d&ograve;ng k&eacute;p</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;25/30 FPS@1920*1080</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ nhạy s&aacute;ng</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;tối thiểu 0.01Lux@F1.2(0Lux IR LED on)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Tốc độ m&agrave;n chập</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;1/25 ~ 1/8000s</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Đ&egrave;n Led:</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					42 IrLed Tầm quan s&aacute;t hồng ngoại &nbsp;đến 35m trong đ&ecirc;m</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;2 luồng dữ liệu , khung h&igrave;nh 30fps, băng th&ocirc;ng 32kbps ~ 16Mbps</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					C&ocirc;ng nghệ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					WDR 50-100dB, 3D-DNR/AGC/AWB/Chống ngược s&aacute;ng /H&igrave;nh &nbsp; &nbsp;ảnh xoay v&ograve;ng (90-270℃)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Ph&aacute;t hiện chuyển động th&ocirc;ng minh, B&aacute;o động qua Email, bản đồ</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Số lượng truy cập tối đa đồng thời l&ecirc;n đến 10 người</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					giao thức ONVIF 2.2</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ Android, Windows Mobile, Symbian, iPhone nền tảng gi&aacute;m s&aacute;t điện thoại th&ocirc;ng minh</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;DC 12V</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					12V</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Phần mềm</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					CMS miễn ph&iacute; ; IP66</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229); color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px;\">\r\n					&nbsp;</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<br />\r\n','','','0','1','0','1','','1','','','2000000','0','0','0','0','0','TAG-I3B3P-F42','TAG-I3B3P-F42','TAG-I3B3P-F42','1448346608','1448349580','0','0','0',NULL,'9','363');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('7','','TAG-I3D3P-F72','TAG-I3D3P-F72','tag-i3d3p-f72','upload/2015/11/24/1443886508_182_1448346591.png','','','<div>\r\n	&nbsp;</div>\r\n<div>\r\n	<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; background-color: transparent;\">\r\n		<tbody style=\"box-sizing: border-box;\">\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Th&ocirc;ng số kỹ thuật</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ ph&acirc;n giải</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					1080P</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Cảm biến</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Sony</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Chuẩn n&eacute;n h&igrave;nh ảnh</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					H.264, tốc độ m&atilde; h&oacute;a d&ograve;ng k&eacute;p</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;25/30 FPS@1920*1080</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ nhạy s&aacute;ng</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;tối thiểu 0.01Lux@F1.2(0Lux IR LED on)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Tốc độ m&agrave;n chập</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;1/25 ~ 1/8000s</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Đ&egrave;n Led:</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					42 IrLed Tầm quan s&aacute;t hồng ngoại &nbsp;đến 35m trong đ&ecirc;m</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;2 luồng dữ liệu , khung h&igrave;nh 30fps, băng th&ocirc;ng 32kbps ~ 16Mbps</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					C&ocirc;ng nghệ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					WDR 50-100dB, 3D-DNR/AGC/AWB/Chống ngược s&aacute;ng /H&igrave;nh &nbsp; &nbsp;ảnh xoay v&ograve;ng (90-270℃)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Ph&aacute;t hiện chuyển động th&ocirc;ng minh, B&aacute;o động qua Email, bản đồ</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Số lượng truy cập tối đa đồng thời l&ecirc;n đến 10 người</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					giao thức ONVIF 2.2</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ Android, Windows Mobile, Symbian, iPhone nền tảng gi&aacute;m s&aacute;t điện thoại th&ocirc;ng minh</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;DC 12V</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					12V</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Phần mềm</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					CMS miễn ph&iacute; ; IP66</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229); color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px;\">\r\n					&nbsp;</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<br />\r\n','','','0','1','0','1','','1','','','5000000','0','0','0','0','0','TAG-I3D3P-F72','TAG-I3D3P-F72','TAG-I3D3P-F72','1448346626','1448349571','0','0','0',NULL,'9','363');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('8','','VDTECH VDT 3060HL.60','VDTECH VDT 3060HL.60','vdtech-vdt-3060hl60','upload/2015/11/24/350_vdt_135_135ea_1448346739.png','','','<div>\r\n	&nbsp;</div>\r\n<div>\r\n	<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; background-color: transparent;\">\r\n		<tbody style=\"box-sizing: border-box;\">\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Th&ocirc;ng số kỹ thuật</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ ph&acirc;n giải</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					1080P</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Cảm biến</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Sony</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Chuẩn n&eacute;n h&igrave;nh ảnh</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					H.264, tốc độ m&atilde; h&oacute;a d&ograve;ng k&eacute;p</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;25/30 FPS@1920*1080</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ nhạy s&aacute;ng</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;tối thiểu 0.01Lux@F1.2(0Lux IR LED on)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Tốc độ m&agrave;n chập</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;1/25 ~ 1/8000s</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Đ&egrave;n Led:</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					42 IrLed Tầm quan s&aacute;t hồng ngoại &nbsp;đến 35m trong đ&ecirc;m</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;2 luồng dữ liệu , khung h&igrave;nh 30fps, băng th&ocirc;ng 32kbps ~ 16Mbps</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					C&ocirc;ng nghệ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					WDR 50-100dB, 3D-DNR/AGC/AWB/Chống ngược s&aacute;ng /H&igrave;nh &nbsp; &nbsp;ảnh xoay v&ograve;ng (90-270℃)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Ph&aacute;t hiện chuyển động th&ocirc;ng minh, B&aacute;o động qua Email, bản đồ</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Số lượng truy cập tối đa đồng thời l&ecirc;n đến 10 người</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					giao thức ONVIF 2.2</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ Android, Windows Mobile, Symbian, iPhone nền tảng gi&aacute;m s&aacute;t điện thoại th&ocirc;ng minh</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;DC 12V</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					12V</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Phần mềm</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					CMS miễn ph&iacute; ; IP66</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229); color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px;\">\r\n					&nbsp;</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<br />\r\n','','','0','1','0','1','','1','','','15000000','0','0','0','0','0','VDTECH VDT 3060HL.60','VDTECH VDT 3060HL.60','VDTECH VDT 3060HL.60','1448346760','1448349561','0','0','0',NULL,'4','54');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('9','','VDTECH VDT-135 IR.80','VDTECH VDT-135 IR.80','vdtech-vdt-135-ir80','upload/2015/11/24/350_vdtech_vdt1351_1448346715.jpg','','','<div>\r\n	&nbsp;</div>\r\n<div>\r\n	<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; background-color: transparent;\">\r\n		<tbody style=\"box-sizing: border-box;\">\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Th&ocirc;ng số kỹ thuật</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ ph&acirc;n giải</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					1080P</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Cảm biến</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Sony</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Chuẩn n&eacute;n h&igrave;nh ảnh</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					H.264, tốc độ m&atilde; h&oacute;a d&ograve;ng k&eacute;p</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;25/30 FPS@1920*1080</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ nhạy s&aacute;ng</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;tối thiểu 0.01Lux@F1.2(0Lux IR LED on)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Tốc độ m&agrave;n chập</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;1/25 ~ 1/8000s</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Đ&egrave;n Led:</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					42 IrLed Tầm quan s&aacute;t hồng ngoại &nbsp;đến 35m trong đ&ecirc;m</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;2 luồng dữ liệu , khung h&igrave;nh 30fps, băng th&ocirc;ng 32kbps ~ 16Mbps</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					C&ocirc;ng nghệ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					WDR 50-100dB, 3D-DNR/AGC/AWB/Chống ngược s&aacute;ng /H&igrave;nh &nbsp; &nbsp;ảnh xoay v&ograve;ng (90-270℃)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Ph&aacute;t hiện chuyển động th&ocirc;ng minh, B&aacute;o động qua Email, bản đồ</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Số lượng truy cập tối đa đồng thời l&ecirc;n đến 10 người</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					giao thức ONVIF 2.2</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ Android, Windows Mobile, Symbian, iPhone nền tảng gi&aacute;m s&aacute;t điện thoại th&ocirc;ng minh</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;DC 12V</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					12V</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Phần mềm</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					CMS miễn ph&iacute; ; IP66</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229); color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px;\">\r\n					&nbsp;</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<br />\r\n','','','0','1','0','1','','1','','','1600000','0','0','0','0','0','VDTECH VDT-135 IR.80','VDTECH VDT-135 IR.80','VDTECH VDT-135 IR.80','1448346777','1448349551','0','0','0',NULL,'4','54');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('10','','VDTECH VDT135','VDTECH VDT135','vdtech-vdt135','upload/2015/11/24/350_vdt_27cvi_13_11_1448346727.png','','','<div>\r\n	&nbsp;</div>\r\n<div>\r\n	<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"box-sizing: border-box; border-spacing: 0px; border-color: rgb(229, 229, 229); border-style: solid; border-width: 1px 0px 0px 1px; margin-bottom: 24px; width: 828px; background-color: transparent;\">\r\n		<tbody style=\"box-sizing: border-box;\">\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Th&ocirc;ng số kỹ thuật</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ ph&acirc;n giải</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					1080P</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Cảm biến</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Sony</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Chuẩn n&eacute;n h&igrave;nh ảnh</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					H.264, tốc độ m&atilde; h&oacute;a d&ograve;ng k&eacute;p</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;25/30 FPS@1920*1080</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Độ nhạy s&aacute;ng</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;tối thiểu 0.01Lux@F1.2(0Lux IR LED on)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Tốc độ m&agrave;n chập</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;1/25 ~ 1/8000s</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Đ&egrave;n Led:</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					42 IrLed Tầm quan s&aacute;t hồng ngoại &nbsp;đến 35m trong đ&ecirc;m</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;2 luồng dữ liệu , khung h&igrave;nh 30fps, băng th&ocirc;ng 32kbps ~ 16Mbps</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					C&ocirc;ng nghệ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					WDR 50-100dB, 3D-DNR/AGC/AWB/Chống ngược s&aacute;ng /H&igrave;nh &nbsp; &nbsp;ảnh xoay v&ograve;ng (90-270℃)</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Ph&aacute;t hiện chuyển động th&ocirc;ng minh, B&aacute;o động qua Email, bản đồ</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Số lượng truy cập tối đa đồng thời l&ecirc;n đến 10 người</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					giao thức ONVIF 2.2</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td colspan=\"2\" style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;Hỗ trợ Android, Windows Mobile, Symbian, iPhone nền tảng gi&aacute;m s&aacute;t điện thoại th&ocirc;ng minh</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					&nbsp;DC 12V</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					12V</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					Phần mềm</td>\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229);\">\r\n					CMS miễn ph&iacute; ; IP66</td>\r\n			</tr>\r\n			<tr style=\"box-sizing: border-box;\">\r\n				<td style=\"box-sizing: border-box; padding: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(229, 229, 229); border-right-width: 1px; border-right-style: solid; border-right-color: rgb(229, 229, 229); color: rgb(68, 68, 68); font-family: arial; font-size: 14px; line-height: 20px;\">\r\n					&nbsp;</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<br />\r\n','','','0','1','0','1','','1','','','2000000','0','0','0','0','0','VDTECH VDT135','VDTECH VDT135','VDTECH VDT135','1448346796','1448349241','0','0','0',NULL,'4','54');
INSERT INTO `product` (`id`,`product_code`,`product_name`,`name_en`,`product_alias`,`image_url`,`video_url`,`description`,`content`,`guide_use`,`guarantee`,`is_new`,`is_hot`,`is_saleoff`,`trangthai`,`percent_deal`,`display_order`,`size`,`color`,`price`,`price_saleoff`,`deal_amount`,`sale_hot`,`start_date`,`end_date`,`meta_title`,`meta_description`,`meta_keyword`,`created_at`,`updated_at`,`created_by`,`updated_by`,`hidden`,`manu_id`,`cate_type_id`,`cate_id`) VALUES ('11','','VDTECH VDT13511','VDTECH VDT13511','vdtech-vdt13511','upload/2015/11/24/1443885574_141_1448349392.png','','','đấg fsh gsfhfdsh fdh dfhdsf hsd','','','0','1','0','1','','1','','','12000000','0','0','0','0','0','VDTECH VDT13511','VDTECH VDT13511','VDTECH VDT13511','1448349398','1448422724','0','0','0',NULL,'4','381');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;


--
-- Create Table `product_cate`
--

DROP TABLE IF EXISTS `product_cate`;
CREATE TABLE `product_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_id` int(11) NOT NULL,
  `cate_type_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `product_cate`
--

/*!40000 ALTER TABLE `product_cate` DISABLE KEYS */;
INSERT INTO `product_cate` (`id`,`cate_id`,`cate_type_id`,`product_id`) VALUES ('3','336','9','1');
INSERT INTO `product_cate` (`id`,`cate_id`,`cate_type_id`,`product_id`) VALUES ('4','336','9','2');
/*!40000 ALTER TABLE `product_cate` ENABLE KEYS */;


--
-- Create Table `promotion_code`
--

DROP TABLE IF EXISTS `promotion_code`;
CREATE TABLE `promotion_code` (
  `code_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `code_value` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`code_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `promotion_code`
--

/*!40000 ALTER TABLE `promotion_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion_code` ENABLE KEYS */;


--
-- Create Table `sendcontent`
--

DROP TABLE IF EXISTS `sendcontent`;
CREATE TABLE `sendcontent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `type` tinyint(4) NOT NULL,
  `creation_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Data for Table `sendcontent`
--

/*!40000 ALTER TABLE `sendcontent` DISABLE KEYS */;
/*!40000 ALTER TABLE `sendcontent` ENABLE KEYS */;


--
-- Create Table `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE `seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `meta_title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `meta_description` varchar(255) CHARACTER SET utf8 NOT NULL,
  `meta_keyword` varchar(255) CHARACTER SET utf8 NOT NULL,
  `seo_title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `seo_text` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Data for Table `seo`
--

/*!40000 ALTER TABLE `seo` DISABLE KEYS */;
INSERT INTO `seo` (`id`,`page_name`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`) VALUES ('1','Trang chủ','Viễn thông Anh Khôi','Viễn thông Anh Khôi','Viễn thông Anh Khôi','Viễn thông Anh Khôi','<div>\r\n	Chuy&ecirc;n cung cấp tất cả c&aacute;c loại camera với gi&aacute; tốt nhất tr&ecirc;n to&agrave;n quốc.</div>\r\n');
INSERT INTO `seo` (`id`,`page_name`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`) VALUES ('3','Liên hệ','Liên hệ','Liên hệ','Liên hệ','',NULL);
INSERT INTO `seo` (`id`,`page_name`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`) VALUES ('4','Tin tức','Tin tức','Tin tức','Tin tức','',NULL);
INSERT INTO `seo` (`id`,`page_name`,`meta_title`,`meta_description`,`meta_keyword`,`seo_title`,`seo_text`) VALUES ('10','Tìm kiếm','Tìm kiếm','Tìm kiếm','Tìm kiếm','',NULL);
/*!40000 ALTER TABLE `seo` ENABLE KEYS */;


--
-- Create Table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(255) NOT NULL,
  `state_alias` varchar(255) NOT NULL,
  `city_id` int(11) NOT NULL,
  `display_order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Data for Table `state`
--

/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('1','Quận 1','quan-1','1','1');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('2','Quận 2','quan-2','1','2');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('3','Quận 3','quan-3','1','3');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('4','Quận 4','quan-4','1','4');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('5','Quận Ba Đình','quan-ba-dinh','2','1');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('6','Quận Đống Đa','quan-dong-da','2','2');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('7','Quận Cầu Giấy','quan-cau-giay','2','3');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('9','Quận 5','quan-5','1','4');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('10','Quận 6','quan-6','1','4');
INSERT INTO `state` (`id`,`state_name`,`state_alias`,`city_id`,`display_order`) VALUES ('11','Quận Hoàn Kiếm','quan-hoan-kiem','2','3');
/*!40000 ALTER TABLE `state` ENABLE KEYS */;


--
-- Create Table `tag`
--

DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) NOT NULL,
  `tag_name_kd` varchar(255) NOT NULL,
  PRIMARY KEY (`tag_id`),
  FULLTEXT KEY `tag_name` (`tag_name`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Data for Table `tag`
--

/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('1','huy hoàng','huy-hoang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('2','Thiết kế 1','thiet-ke-1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('3',' Thiết kế 1','thiet-ke-1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('4','Thiết kế 1','thiet-ke-1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('5',' ke gy','ke-gy');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('6','tag1','tag1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('7',' tag2','tag2');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('8',' tag3','tag3');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('9','  tag2','tag2');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('10','  tag3','tag3');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('11','trai nghiem','trai-nghiem');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('12','ve que','ve-que');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('13',' ve que','ve-que');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('14','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('15','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('16','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('17','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('18','Tags','tags');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('19','tu khoa','tu-khoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('20',' tu khoa','tu-khoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('21',' 1','1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('22','  tu khoa','tu-khoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('23',' 1','1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('24','   tu khoa','tu-khoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('25','  1','1');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('26','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('27','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('28','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('29','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('30','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('31','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('32','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('33','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('34','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('35','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('36','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('37','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('38','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('39','','');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;


--
-- Create Table `text`
--

DROP TABLE IF EXISTS `text`;
CREATE TABLE `text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Data for Table `text`
--

/*!40000 ALTER TABLE `text` DISABLE KEYS */;
INSERT INTO `text` (`id`,`text`) VALUES ('1','HOTLINE');
INSERT INTO `text` (`id`,`text`) VALUES ('2','0913.665.513');
INSERT INTO `text` (`id`,`text`) VALUES ('3','Đồng hồ nam nữ ch&iacute;nh h&atilde;ng');
INSERT INTO `text` (`id`,`text`) VALUES ('4','<p>\r\n	đồng hồ nam nữ ch&iacute;nh h&atilde;ng tại tphcm</p>\r\n');
INSERT INTO `text` (`id`,`text`) VALUES ('5','K&ecirc;nh th&ocirc;ng tin');
INSERT INTO `text` (`id`,`text`) VALUES ('6','Nhập Email để c&oacute; thể nhận được th&ocirc;ng tin đầy đủ v&agrave; mới nhất mỗi khi c&oacute; khuyến m&atilde;i');
INSERT INTO `text` (`id`,`text`) VALUES ('7','<p>\r\n	Bản quyền 2015 vinawatch.com<br />\r\n	Đơn vị chủ quản: Shop đồng hồ mắt k&iacute;nh Vinawatch<br />\r\n	M&atilde; số thuế: 0106384726</p>\r\n');
INSERT INTO `text` (`id`,`text`) VALUES ('12','Newsletter');
INSERT INTO `text` (`id`,`text`) VALUES ('8','Shop đồng hồ mắt k&iacute;nh Vinawatch');
INSERT INTO `text` (`id`,`text`) VALUES ('9','31 Nguyễn Tất Th&agrave;nh P13 Q4 ( gần cầu Kh&aacute;nh Hội Quận 1) TPHCM');
INSERT INTO `text` (`id`,`text`) VALUES ('10','0913.665.513');
INSERT INTO `text` (`id`,`text`) VALUES ('11','vinawatch@gmail.com');
INSERT INTO `text` (`id`,`text`) VALUES ('13','Nhập email của bạn để nhận th&ocirc;ng tin khuyến m&atilde;i từ Vinawatch');
/*!40000 ALTER TABLE `text` ENABLE KEYS */;


--
-- Create Table `url`
--

DROP TABLE IF EXISTS `url`;
CREATE TABLE `url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `object_id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

--
-- Data for Table `url`
--

/*!40000 ALTER TABLE `url` DISABLE KEYS */;
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('12','dau-ghi-hinh-eyewide','231','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('13','camera-ip-eyewide','379','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('19','dau-ghi-hinh-global','336','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('20','camera-ip-global','363','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('24','dau-ghi-hinh-vdtech','42','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('25','camera-ip-vdtech','54','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('46','camera','9','3');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('47','dau-ghi-hinh','4','3');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('48','bao-trom-bao-chay','2','3');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('49','camera-ahd-global','380','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('50','camera-ahd-vdtech','381','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('51','camera-analog-vdtech','382','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('52','camera-ahd-eyewide','383','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('53','camera-analog-eyewide','384','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('54','trung-tam-bao-chay','385','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('55','dau-bao-khoi','386','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('56','dau-bao-nhiet','387','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('57','dau-bao-ro-ga','388','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('58','trung-tam-bao-dong','389','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('59','dau-bao-chuyen-dong','390','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('60','dau-bao-cua-tu','391','1');
INSERT INTO `url` (`id`,`alias`,`object_id`,`type`) VALUES ('61','download-phan-mem','1','2');
/*!40000 ALTER TABLE `url` ENABLE KEYS */;


--
-- Create Table `user_privilege`
--

DROP TABLE IF EXISTS `user_privilege`;
CREATE TABLE `user_privilege` (
  `user_id` int(11) NOT NULL,
  `privilege_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `user_privilege`
--

/*!40000 ALTER TABLE `user_privilege` DISABLE KEYS */;
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','1');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','5');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','11');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','16');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','19');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','23');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','26');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','30');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','34');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','38');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('5','42');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('4','1');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('4','3');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('4','4');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('4','10');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('4','5');
INSERT INTO `user_privilege` (`user_id`,`privilege_id`) VALUES ('4','7');
/*!40000 ALTER TABLE `user_privilege` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `last_login` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` tinyint(4) NOT NULL,
  `updated_by` tinyint(4) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`,`username`,`password`,`full_name`,`email`,`phone`,`address`,`city_id`,`status`,`last_login`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('4','hoang','e10adc3949ba59abbe56e057f20f883e','dgadsgdsg','hoang@gmail.com','sdfgsdfgdf','fdgsdfg','1','1',NULL,'0','1429927485','0','1');
INSERT INTO `users` (`user_id`,`username`,`password`,`full_name`,`email`,`phone`,`address`,`city_id`,`status`,`last_login`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('2','huyhoang','e10adc3949ba59abbe56e057f20f883e','huy hoang','hoangnh@gmail.com','0917492306','123 abcssssssssss','1','1',NULL,'1426400277','1429053907','0','1');
INSERT INTO `users` (`user_id`,`username`,`password`,`full_name`,`email`,`phone`,`address`,`city_id`,`status`,`last_login`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('3','liembd','851eec1df720cab32b54a2241942d6ad','dsgsadgsdgsd','sdgadsgadsg','asdfasf','safsdf','1','1','0','1429053937','1429053937','1','1');
INSERT INTO `users` (`user_id`,`username`,`password`,`full_name`,`email`,`phone`,`address`,`city_id`,`status`,`last_login`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('1','admin','e10adc3949ba59abbe56e057f20f883e','Administrator','admin@vienthonganhkhoi.com','0917492306','','0','1',NULL,'0','0','0','0');
INSERT INTO `users` (`user_id`,`username`,`password`,`full_name`,`email`,`phone`,`address`,`city_id`,`status`,`last_login`,`created_at`,`updated_at`,`created_by`,`updated_by`) VALUES ('5','nhanvienmoi','851eec1df720cab32b54a2241942d6ad','Thai Anh Tuan','tuanthai@gmail.com','0908116411','65/2a Luong Huu Khanh','1','1','0','1429776747','1429776911','1','1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

