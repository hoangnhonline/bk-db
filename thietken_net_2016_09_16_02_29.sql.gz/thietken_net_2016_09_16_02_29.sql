-- Status:6:22:MP_0:thietken_net:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|campaign|3|16384||InnoDB
-- TABLE|uid|3|49152||InnoDB
-- TABLE|uid_campaign|3|16384||InnoDB
-- TABLE|uid_website|9|16384||InnoDB
-- TABLE|users|1|2148|2016-03-24 21:30:04|MyISAM
-- TABLE|website|3|16384||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:29

--
-- Create Table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
CREATE TABLE `campaign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file_url` varchar(500) DEFAULT NULL,
  `file_type` varchar(3) DEFAULT NULL,
  `website_url` varchar(500) NOT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `campaign`
--

/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` (`id`,`name`,`file_url`,`file_type`,`website_url`,`width`,`height`,`status`,`created_at`,`updated_at`) VALUES ('1','phuong mặt lồn','upload/2016/03/24/d26eea75f4036fa63b349f9e2f1de740_1458830510.gif','gif','http://webanhang.com','300','250','1','1458830513','1458903470');
INSERT INTO `campaign` (`id`,`name`,`file_url`,`file_type`,`website_url`,`width`,`height`,`status`,`created_at`,`updated_at`) VALUES ('2','chien dich test 1','upload/2016/03/24/images_1458832553.jpg','jpg','http://zing.vn','280','280','1','1458832556','1458832556');
INSERT INTO `campaign` (`id`,`name`,`file_url`,`file_type`,`website_url`,`width`,`height`,`status`,`created_at`,`updated_at`) VALUES ('3','bao cao su','upload/2016/03/25/1367504942840_1458904528.jpg','jpg','http://chuyencungcap.com/san-pham/san-pham-ho-tro-tinh-duc-192.0.html','300','300','1','1458904538','1458904538');
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;


--
-- Create Table `uid`
--

DROP TABLE IF EXISTS `uid`;
CREATE TABLE `uid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `campaign_id` varchar(255) NOT NULL,
  `website_id` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `campaign_id` (`campaign_id`,`website_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `uid`
--

/*!40000 ALTER TABLE `uid` DISABLE KEYS */;
INSERT INTO `uid` (`id`,`code`,`campaign_id`,`website_id`,`status`,`created_at`,`updated_at`) VALUES ('1','1458830569','1','3,2,1','1','1458830569','1458830569');
INSERT INTO `uid` (`id`,`code`,`campaign_id`,`website_id`,`status`,`created_at`,`updated_at`) VALUES ('2','1458832588','2','3,2,1','1','1458832588','1458832588');
INSERT INTO `uid` (`id`,`code`,`campaign_id`,`website_id`,`status`,`created_at`,`updated_at`) VALUES ('3','1458904576','3','3,2,1','1','1458904576','1458904576');
/*!40000 ALTER TABLE `uid` ENABLE KEYS */;


--
-- Create Table `uid_campaign`
--

DROP TABLE IF EXISTS `uid_campaign`;
CREATE TABLE `uid_campaign` (
  `uid` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  UNIQUE KEY `uid` (`uid`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `uid_campaign`
--

/*!40000 ALTER TABLE `uid_campaign` DISABLE KEYS */;
INSERT INTO `uid_campaign` (`uid`,`campaign_id`) VALUES ('1','1');
INSERT INTO `uid_campaign` (`uid`,`campaign_id`) VALUES ('2','2');
INSERT INTO `uid_campaign` (`uid`,`campaign_id`) VALUES ('3','3');
/*!40000 ALTER TABLE `uid_campaign` ENABLE KEYS */;


--
-- Create Table `uid_website`
--

DROP TABLE IF EXISTS `uid_website`;
CREATE TABLE `uid_website` (
  `uid` int(11) NOT NULL,
  `website_id` int(11) NOT NULL,
  UNIQUE KEY `uid` (`uid`,`website_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `uid_website`
--

/*!40000 ALTER TABLE `uid_website` DISABLE KEYS */;
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('1','1');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('1','2');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('1','3');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('2','1');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('2','2');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('2','3');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('3','1');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('3','2');
INSERT INTO `uid_website` (`uid`,`website_id`) VALUES ('3','3');
/*!40000 ALTER TABLE `uid_website` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` tinyint(4) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `address` varchar(500) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `yahoo` varchar(255) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`,`email`,`password`,`level`,`name`,`phone`,`image_url`,`address`,`skype`,`yahoo`,`created_at`,`updated_at`,`status`) VALUES ('10','admin','e9ea90857363708afc42938a00719e76','1','admin','','upload/images/2015/12/01/koala-6.jpg','','','','0','1448987548','1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Create Table `website`
--

DROP TABLE IF EXISTS `website`;
CREATE TABLE `website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `website_url` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `display_order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `website`
--

/*!40000 ALTER TABLE `website` DISABLE KEYS */;
INSERT INTO `website` (`id`,`name`,`website_url`,`status`,`created_at`,`updated_at`,`display_order`) VALUES ('1','WEB 1','http://diendandienthoai.net','1','1458807115','1458807115','1');
INSERT INTO `website` (`id`,`name`,`website_url`,`status`,`created_at`,`updated_at`,`display_order`) VALUES ('2','WEB 2','http://nguoitayninh.com/','1','1458807126','1458807126','1');
INSERT INTO `website` (`id`,`name`,`website_url`,`status`,`created_at`,`updated_at`,`display_order`) VALUES ('3','WEB 3','http://news.zing.vn','1','1458807136','1458807136','1');
/*!40000 ALTER TABLE `website` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

