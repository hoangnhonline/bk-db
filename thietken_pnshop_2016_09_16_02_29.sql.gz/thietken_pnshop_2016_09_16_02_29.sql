-- Status:22:1008:MP_0:thietken_pnshop:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|chatlieu|2|2092|2015-01-22 21:21:28|MyISAM
-- TABLE|donhang|0|1024|2015-01-22 21:21:28|MyISAM
-- TABLE|donhangct|4|2164|2015-01-22 21:21:28|MyISAM
-- TABLE|khachhang|5|2232|2015-01-22 21:21:28|MyISAM
-- TABLE|khoanggia|4|2100|2015-01-22 21:21:28|MyISAM
-- TABLE|kieu|4|2144|2015-01-22 21:21:28|MyISAM
-- TABLE|letter|0|1024|2015-01-22 21:21:28|MyISAM
-- TABLE|loaisp|6|2580|2015-01-22 21:21:28|MyISAM
-- TABLE|loaitin|3|2132|2015-01-22 21:21:28|MyISAM
-- TABLE|mau|11|2516|2015-01-22 21:21:28|MyISAM
-- TABLE|menu|12|12776|2015-01-22 21:21:28|MyISAM
-- TABLE|sanpham|15|10824|2015-01-22 21:21:28|MyISAM
-- TABLE|size|5|2148|2015-01-22 21:21:28|MyISAM
-- TABLE|sp_chat|13|2165|2015-01-22 21:21:28|MyISAM
-- TABLE|sp_kieu|17|1177|2015-01-22 21:21:28|MyISAM
-- TABLE|sp_mau|31|2451|2015-01-22 21:21:28|MyISAM
-- TABLE|sp_size|70|2678|2015-01-22 21:21:28|MyISAM
-- TABLE|sp_tag|10|2138|2015-01-22 21:21:28|MyISAM
-- TABLE|tag|789|60400|2015-01-22 21:21:28|MyISAM
-- TABLE|theloai|4|2148|2015-01-22 21:21:28|MyISAM
-- TABLE|tintuc|2|41020|2015-01-22 21:21:28|MyISAM
-- TABLE|users|1|2100|2015-01-22 21:21:28|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:29

--
-- Create Table `chatlieu`
--

DROP TABLE IF EXISTS `chatlieu`;
CREATE TABLE `chatlieu` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat` varchar(100) NOT NULL,
  PRIMARY KEY (`chat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `chatlieu`
--

/*!40000 ALTER TABLE `chatlieu` DISABLE KEYS */;
INSERT INTO `chatlieu` (`chat_id`,`chat`) VALUES ('1','thun 4 chiều');
INSERT INTO `chatlieu` (`chat_id`,`chat`) VALUES ('2','vải');
/*!40000 ALTER TABLE `chatlieu` ENABLE KEYS */;


--
-- Create Table `donhang`
--

DROP TABLE IF EXISTS `donhang`;
CREATE TABLE `donhang` (
  `idDH` int(20) NOT NULL AUTO_INCREMENT,
  `idKH` int(11) NOT NULL,
  `tongtiendh` int(11) NOT NULL,
  `tongsp` int(11) NOT NULL,
  `ngaymua` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`idDH`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `donhang`
--

/*!40000 ALTER TABLE `donhang` DISABLE KEYS */;
/*!40000 ALTER TABLE `donhang` ENABLE KEYS */;


--
-- Create Table `donhangct`
--

DROP TABLE IF EXISTS `donhangct`;
CREATE TABLE `donhangct` (
  `idDHCT` int(11) NOT NULL AUTO_INCREMENT,
  `idDH` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `tiensp` int(11) NOT NULL,
  `mausac` varchar(20) NOT NULL,
  `size` varchar(10) NOT NULL,
  PRIMARY KEY (`idDHCT`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Data for Table `donhangct`
--

/*!40000 ALTER TABLE `donhangct` DISABLE KEYS */;
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`,`mausac`,`size`) VALUES ('2','2','120','3','360000','9','M');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`,`mausac`,`size`) VALUES ('3','3','120','1','120000','9','M');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`,`mausac`,`size`) VALUES ('4','3','121','1','120000','10','XS');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`,`mausac`,`size`) VALUES ('5','4','112','1','3000000','6','M');
/*!40000 ALTER TABLE `donhangct` ENABLE KEYS */;


--
-- Create Table `khachhang`
--

DROP TABLE IF EXISTS `khachhang`;
CREATE TABLE `khachhang` (
  `idKH` int(11) NOT NULL AUTO_INCREMENT,
  `hoten` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dienthoai` varchar(12) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `tongtien` int(30) NOT NULL,
  `lanmuacuoi` int(11) NOT NULL,
  `solanmua` int(11) NOT NULL,
  PRIMARY KEY (`idKH`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Data for Table `khachhang`
--

/*!40000 ALTER TABLE `khachhang` DISABLE KEYS */;
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`dienthoai`,`diachi`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('1','Nguyen tan Phương','','01677160153','Q7','3000000','1393835574','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`dienthoai`,`diachi`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('8','2','','2','we','3000000','1396922042','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`dienthoai`,`diachi`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('7','as','','243224234234','a','0','1395647970','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`dienthoai`,`diachi`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('6','as','','243224234234','a','0','1395647969','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`dienthoai`,`diachi`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('9','2','','2234','we','0','1396922052','1');
/*!40000 ALTER TABLE `khachhang` ENABLE KEYS */;


--
-- Create Table `khoanggia`
--

DROP TABLE IF EXISTS `khoanggia`;
CREATE TABLE `khoanggia` (
  `kg_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `giatu` int(11) NOT NULL,
  `giaden` int(11) NOT NULL,
  `thutu` smallint(6) NOT NULL,
  PRIMARY KEY (`kg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Data for Table `khoanggia`
--

/*!40000 ALTER TABLE `khoanggia` DISABLE KEYS */;
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('1','0','100000','1');
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('2','100','200000','2');
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('3','200','500000','3');
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('4','500','5000000','4');
/*!40000 ALTER TABLE `khoanggia` ENABLE KEYS */;


--
-- Create Table `kieu`
--

DROP TABLE IF EXISTS `kieu`;
CREATE TABLE `kieu` (
  `kieu_id` int(11) NOT NULL AUTO_INCREMENT,
  `kieu` varchar(255) NOT NULL,
  `loai_id` int(11) NOT NULL,
  PRIMARY KEY (`kieu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `kieu`
--

/*!40000 ALTER TABLE `kieu` DISABLE KEYS */;
INSERT INTO `kieu` (`kieu_id`,`kieu`,`loai_id`) VALUES ('1','cổ trụ','1');
INSERT INTO `kieu` (`kieu_id`,`kieu`,`loai_id`) VALUES ('2','cổ tròn','1');
INSERT INTO `kieu` (`kieu_id`,`kieu`,`loai_id`) VALUES ('3','tay dài','1');
INSERT INTO `kieu` (`kieu_id`,`kieu`,`loai_id`) VALUES ('4','tay ngắn','1');
/*!40000 ALTER TABLE `kieu` ENABLE KEYS */;


--
-- Create Table `letter`
--

DROP TABLE IF EXISTS `letter`;
CREATE TABLE `letter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ngay` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `letter`
--

/*!40000 ALTER TABLE `letter` DISABLE KEYS */;
/*!40000 ALTER TABLE `letter` ENABLE KEYS */;


--
-- Create Table `loaisp`
--

DROP TABLE IF EXISTS `loaisp`;
CREATE TABLE `loaisp` (
  `loai_id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(255) NOT NULL,
  `idTL` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `metad` varchar(255) NOT NULL,
  `metak` varchar(255) NOT NULL,
  `ten_kd` varchar(100) NOT NULL,
  `AnHien` int(10) NOT NULL,
  PRIMARY KEY (`loai_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `loaisp`
--

/*!40000 ALTER TABLE `loaisp` DISABLE KEYS */;
INSERT INTO `loaisp` (`loai_id`,`loai`,`idTL`,`title`,`metad`,`metak`,`ten_kd`,`AnHien`) VALUES ('1','Áo thun  nữ','2','Áo thun  nữ','Áo thun  nữ','Áo thun  nữ','ao-thun-nu','1');
INSERT INTO `loaisp` (`loai_id`,`loai`,`idTL`,`title`,`metad`,`metak`,`ten_kd`,`AnHien`) VALUES ('2','Áo sơ mi  nữ','2','Áo sơ mi  nữ','Áo sơ mi  nữ','Áo sơ mi  nữ','ao-so-mi-nu','1');
INSERT INTO `loaisp` (`loai_id`,`loai`,`idTL`,`title`,`metad`,`metak`,`ten_kd`,`AnHien`) VALUES ('3','Áo thun nam','1','Áo thun nam','Áo thun nam','Áo thun nam','ao-thun-nam','1');
INSERT INTO `loaisp` (`loai_id`,`loai`,`idTL`,`title`,`metad`,`metak`,`ten_kd`,`AnHien`) VALUES ('4','Áo sơ mi nam','1','Áo sơ mi nam','Áo sơ mi nam','Áo sơ mi nam','ao-so-mi-nam','1');
INSERT INTO `loaisp` (`loai_id`,`loai`,`idTL`,`title`,`metad`,`metak`,`ten_kd`,`AnHien`) VALUES ('5','sản phẩm đặc trưng','0','sản phẩm đặc trưng','sản phẩm đặc trưng','sản phẩm đặc trưng','san-pham-dac-trung','0');
INSERT INTO `loaisp` (`loai_id`,`loai`,`idTL`,`title`,`metad`,`metak`,`ten_kd`,`AnHien`) VALUES ('6','Nón','4','Nón','Nón','Nón','non','1');
/*!40000 ALTER TABLE `loaisp` ENABLE KEYS */;


--
-- Create Table `loaitin`
--

DROP TABLE IF EXISTS `loaitin`;
CREATE TABLE `loaitin` (
  `idLT` int(10) NOT NULL AUTO_INCREMENT,
  `TenLT` text COLLATE utf8_unicode_ci NOT NULL,
  `TenLT_KhongDau` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idLT`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `loaitin`
--

/*!40000 ALTER TABLE `loaitin` DISABLE KEYS */;
INSERT INTO `loaitin` (`idLT`,`TenLT`,`TenLT_KhongDau`) VALUES ('1','Tips','tips');
INSERT INTO `loaitin` (`idLT`,`TenLT`,`TenLT_KhongDau`) VALUES ('2','Tin tức','tin-tuc');
INSERT INTO `loaitin` (`idLT`,`TenLT`,`TenLT_KhongDau`) VALUES ('3','Câu nói hay','cau-noi-hay');
/*!40000 ALTER TABLE `loaitin` ENABLE KEYS */;


--
-- Create Table `mau`
--

DROP TABLE IF EXISTS `mau`;
CREATE TABLE `mau` (
  `mau_id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(50) NOT NULL,
  `hinh` varchar(255) NOT NULL,
  PRIMARY KEY (`mau_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Data for Table `mau`
--

/*!40000 ALTER TABLE `mau` DISABLE KEYS */;
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('3','Đen','upload/mausac/black.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('5','Hồng','upload/mausac/Pink.gif');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('6','Đỏ tươi','upload/mausac/red.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('7','Tím','upload/mausac/Purple.gif');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('9','Vàng','upload/mausac/yellow.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('10','Xanh đen','upload/mausac/Black_green.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('17','Trắng','upload/mausac/vaytrang.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('12','Xanh đậm','upload/mausac/Green.gif');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('13','Xanh da trời','upload/mausac/blue.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('21','Đỏ đô','upload/mausac/do-do.jpg');
INSERT INTO `mau` (`mau_id`,`ten`,`hinh`) VALUES ('20','Xám','upload/mausac/19a.jpg');
/*!40000 ALTER TABLE `mau` ENABLE KEYS */;


--
-- Create Table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `idMenu` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) NOT NULL,
  `noidung` text NOT NULL,
  PRIMARY KEY (`idMenu`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Data for Table `menu`
--

/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('1','Các bước mua hàng','<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\"><strong>Mua h&agrave;ng tại Lahava.vn rất dễ d&agrave;ng, chỉ cần thực hiện theo c&aacute;c bước sau:</strong></span></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\">1. Truy cập v&agrave;o trang chủ, chọn danh mục cần mua.</span></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\">2. D&ugrave;ng bộ lọc để lọc sản phẩm cần t&igrave;m (c&oacute; thể lọc theo Chất liệu, Kiểu d&aacute;ng, M&agrave;u sắc, Gi&aacute;...)</span></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\">3. Click v&agrave;o h&igrave;nh để xem chi tiết sản phẩm.</span></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\">4. Chọn m&agrave;u sắc, size để bỏ v&agrave;o giỏ h&agrave;ng. Tại trang Giỏ h&agrave;ng bạn c&oacute; thể điều chỉnh về số lượng sản phẩm.</span></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\">5. Click v&agrave;o Đặt H&agrave;ng để tiến h&agrave;nh đặt h&agrave;ng. Nhập đầy đủ th&ocirc;ng tin m&agrave; lahava.vn y&ecirc;u cầu.</span></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size: 12px;\">6. Cuối c&ugrave;ng, kiểm tra hộp thư để x&aacute;c nhận th&ocirc;ng tin đơn h&agrave;ng.</span></span></p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('2','Cách chọn size','<p>\r\n	<span style=\"font-size:12px;\">Việc chọn size l&agrave; v&ocirc; c&ugrave;ng quan trọng, n&oacute; quyết định hơn 80% của bộ v&aacute;y bạn đang mặc c&oacute; đẹp hay l&agrave; kh&ocirc;ng, v&igrave; vậy để tr&aacute;nh trường hợp lấy số đo nhầm hoặc đo kh&ocirc;ng đ&uacute;ng c&aacute;ch, bạn n&ecirc;n nhờ người hiểu biết trong ng&agrave;nh may mặc để đo gi&uacute;p bạn. Trường hợp bạn phải tự đo, h&atilde;y click &nbsp;v&agrave;o l&ecirc;n kết sau v&agrave; l&agrave;m theo hướng dẫn.&nbsp;<a href=\"http://yeuthoitrang.vn/huong-dan-cach-tu-lay-so-do-3-vong\" target=\"_blank\"><strong>http://yeuthoitrang.vn/huong-dan-cach-tu-lay-so-do-3-vong</strong></a></span></p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('3','Thanh toán','<p>\r\n	<span style=\"font-size:16px;\"><strong>Một số phương thức thanh to&aacute;n khi mua h&agrave;ng tại LAHAVA</strong></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>1. Thanh to&aacute;n trực tiếp:</strong><br />\r\n	&nbsp;</p>\r\n<p>\r\n	Bạn đến trực tiếp cửa h&agrave;ng của ch&uacute;ng t&ocirc;i để tiến h&agrave;nh thanh to&aacute;n, tại địa chỉ 113 Trần Huy Liệu, Phường 12, Quận Ph&uacute; nhuận, TPHCM<br />\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>2. Thanh to&aacute;n qua cổng Visa, Paypal, Western union, Bưu điện:</strong><br />\r\n	&nbsp;</p>\r\n<p>\r\n	Trường hợp bạn muốn thanh to&aacute;n theo c&aacute;c phương thức n&agrave;y, h&atilde;y click v&agrave;o phần Li&ecirc;n hệ v&agrave; sau đ&oacute; điền th&ocirc;ng tin y&ecirc;u cầu, ch&uacute;ng t&ocirc;i sẽ gửi lại cho bạn đầy đủ th&ocirc;ng tin để thanh to&aacute;n.<br />\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>3. Thanh to&aacute;n bằng Chuyển khoản ng&acirc;n h&agrave;ng:</strong><br />\r\n	&nbsp;</p>\r\n<p>\r\n	Ch&uacute;ng t&ocirc;i hỗ trợ thanh to&aacute;n qua c&aacute;c ng&acirc;n h&agrave;ng sau: Agribank, Đ&ocirc;ng &Aacute;, Sacombank, Vietcombank, ACB, Viettinbank.</p>\r\n<p>\r\n	Hotline hỗ trợ thanh to&aacute;n: <strong>0975.997.567</strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-size:16px;\"><strong>Điều khoản thanh to&aacute;n.</strong></span><br />\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Kh&aacute;ch h&agrave;ng trong nước:</strong><br />\r\n	&nbsp;</p>\r\n<p>\r\n	Nếu bạn đang sống trong khu vực TPHCM, chỉ cần thanh to&aacute;n trước 70% tr&ecirc;n tổng gi&aacute; trị đơn h&agrave;ng, 30% c&ograve;n lại nh&acirc;n vi&ecirc;n của LAHAVA sẽ thu khi giao h&agrave;ng.<br />\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Kh&aacute;ch h&agrave;ng ngo&agrave;i khu vực TPHCM v&agrave; nước ngo&agrave;i:</strong><br />\r\n	&nbsp;</p>\r\n<p>\r\n	Nếu bạn sống ngo&agrave;i khu vực TPHCM hoặc nước ngo&agrave;i, đơn h&agrave;ng chỉ được x&aacute;c nhận khi bạn thanh to&aacute;n đủ 100% gi&aacute; trị đơn h&agrave;ng.</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('4','Giao nhận','<p>\r\n	<span style=\"font-size:16px;\"><strong>Giao h&agrave;ng</strong></span></p>\r\n<p>\r\n	<br />\r\n	Nếu kh&aacute;ch h&agrave;ng ở khu vực TPHCM, bạn c&oacute; thể đến trực tiếp cửa h&agrave;ng của ch&uacute;ng t&ocirc;i để thử v&agrave; nhận h&agrave;ng tại cửa h&agrave;ng, hoặc ch&uacute;ng t&ocirc;i cũng c&oacute; thể gửi đến tận nơi theo địa chỉ bạn cung cấp.</p>\r\n<p>\r\n	<br />\r\n	Đối với kh&aacute;ch h&agrave;ng ở ngo&agrave;i khu vực TPHCM v&agrave; đang sống ở nước ngo&agrave;i, sản phẩm sẽ được giao đến tận nơi theo địa chỉ kh&aacute;ch h&agrave;ng cung cấp.</p>\r\n<p>\r\n	<br />\r\n	<span style=\"font-size:16px;\"><strong>Đổi trả</strong></span></p>\r\n<p>\r\n	<br />\r\n	Nếu sản phẩm kh&aacute;ch h&agrave;ng nhận do lỗi ph&iacute;a LAHAVA (kh&ocirc;ng đ&uacute;ng size, lỗi đường may, lỗi kỹ thuật...) ch&uacute;ng t&ocirc;i sẽ chịu tr&aacute;ch nhiệm v&agrave; ho&agrave;n trả lại cho bạn 100%. Nhưng h&agrave;ng đổi lại cũng phải đảm bảo rằng c&ograve;n mới 100% v&agrave; chưa qua sử dụng, nh&atilde;n m&aacute;c c&ograve;n nguy&ecirc;n.</p>\r\n<p>\r\n	<br />\r\n	Nếu lỗi từ ph&iacute;a kh&aacute;ch h&agrave;ng (mập ốm thất thường....) LAHAVA cũng sẽ vui vẻ v&agrave; khuyến kh&iacute;ch bạn gửi lại sản phẩm để ch&uacute;ng t&ocirc;i điều chỉnh gi&uacute;p bạn c&oacute; bộ trang phục vừa vẹn nhất.</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('5','Đăng ký nhận mail','<p>\r\n	Dang ki nhan mail _ VI</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('6','Hợp tác','<p>\r\n	Với xu hướng ph&aacute;t triển v&agrave; lu&ocirc;n mở rộng h&igrave;nh thức kinh doanh, LAHAVA c&agrave;ng hy vọng được hợp t&aacute;c rộng r&atilde;i với c&aacute;c bạn đang hoạt động trong &nbsp;lĩnh vực thời trang v&agrave; may mặc. Nếu bạn tự tin v&agrave;o năng lực của m&igrave;nh v&agrave; muốn ph&aacute;t triển bản th&acirc;n cũng như đ&oacute;ng g&oacute;p cho sự ph&aacute;t triển của LAHAVA, đừng ngần ngại li&ecirc;n hệ với ch&uacute;ng t&ocirc;i qua email <strong>info@lahava.vn</strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Rất cảm ơn tới sự quan t&acirc;m v&agrave; hợp t&aacute;c của c&aacute;c bạn!</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('7','Showroom','<p>\r\n	<span style=\"font-size:14px;\"><strong>LAHAVA Couture</strong></span></p>\r\n<p>\r\n	113 Trần Huy Liệu, Phường 12, Quận Ph&uacute; nhuận, TP.HCM<br />\r\n	info@lahava.vn - www.lahava.vn<br />\r\n	Hotline: 0975.997.567 - 08.6671 3910<br />\r\n	&nbsp;</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('8','Liên hệ','<p>\r\n	<span style=\"font-size:18px;\"><strong>HỖ TRỢ TƯ VẤN SẢN PHẨM</strong></span></p>\r\n<p>\r\n	<span style=\"font-size:14px;\"><strong>HOTLINE: 0942 926 456 - 0975 997 567</strong></span></p>\r\n<p>\r\n	<span style=\"font-size:14px;\"><strong>EMAIL: info@lahava.vn</strong></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-size:14px;\"><strong>* Bạn n&ecirc;n cung cấp cho ch&uacute;ng t&ocirc;i m&atilde; sản phẩm để được tư vấn ch&iacute;nh x&aacute;c!</strong></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-size:18px;\"><strong>LAHAVA</strong></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\">113 Trần Huy Liệu, Phường 12, Quận Ph&uacute; Nhuận, TP.HCM</span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\">DT: (08) 6671 3910 - 0975 997 567</span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\">EMAIL: info@lahava.vn</span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><a href=\"http://lahava.vn\">www.lahava.vn</a></span><span style=\"font-size:14px;\"></span></p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('9','Giới thiệu','<p>\r\n	Được th&agrave;nh lập v&agrave;o năm 2010, kh&ocirc;ng phải l&agrave; ti&ecirc;n phong nhưng với niềm đam m&ecirc; v&agrave; kh&aacute;t khao, ch&uacute;ng t&ocirc;i sau v&agrave;i năm đ&atilde; từng bước khẳng định vị tr&iacute; của m&igrave;nh tr&ecirc;n thị trường Thời trang dạ hội - &Aacute;o cưới vốn rất s&ocirc;i động ở S&agrave;i g&ograve;n n&oacute;i ri&ecirc;ng v&agrave; Việt Nam n&oacute;i chung. Sản phẩm của LAHAVA chủ yếu bao gồm v&aacute;y cưới, v&aacute;y dạ hội v&agrave; đầm dự tiệc cưới.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Sản phẩm của LAHAVA đ&aacute;p ứng đa dạng nhu cầu của kh&aacute;ch h&agrave;ng, sự h&agrave;i l&ograve;ng của kh&aacute;ch h&agrave;ng lu&ocirc;n l&agrave; mục ti&ecirc;u ph&aacute;t triển của ch&uacute;ng t&ocirc;i. Với đội ngũ kỹ thuật c&oacute; kinh nghiệm l&acirc;u năm v&agrave; tay nghề cao, l&agrave;m việc nhiệt t&igrave;nh v&agrave; hăng say, ch&uacute;ng t&ocirc;i tự tin mang đến cho bạn những sản phẩm thời trang ho&agrave;n hảo nhất!</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-size:14px;\"><strong>LAHAVA Couture</strong></span></p>\r\n<p>\r\n	113 Trần Huy Liệu, Phường 12, Quận Ph&uacute; nhuận, TP.HCM</p>\r\n<p>\r\n	Tel: 0942.926.456 - 0975.997.567</p>\r\n<p>\r\n	Email: info@lahava.vn</p>\r\n<p>\r\n	www.lahava.vn</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('10','Nội dung bảo quản','<p>\r\n	&bull; Kh&ocirc;ng giặt với đồ m&agrave;u<br />\r\n	&bull; Kh&ocirc;ng giặt bằng m&aacute;y<br />\r\n	&bull; Kh&ocirc;ng d&ugrave;ng thuốc tẩy<br />\r\n	&bull; Kh&ocirc;ng ủi với nhiệt độ tr&ecirc;n 110&deg;c</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('11','Nội dung giao nhận','<p>\r\n	&bull; Nhận h&agrave;ng trong v&ograve;ng 7 đến 15 ng&agrave;y l&agrave;m việc<br />\r\n	&bull; Giao nhận tại cửa h&agrave;ng hoặc giao tận nơi<br />\r\n	&bull; Th&ocirc;ng qua c&aacute;c dịch vụ chuyển ph&aacute;t nhanh, bưu điện...<br />\r\n	&bull; Giao h&agrave;ng miễn ph&iacute; tr&ecirc;n to&agrave;n quốc</p>\r\n');
INSERT INTO `menu` (`idMenu`,`ten`,`noidung`) VALUES ('12','Nội dung đổi trả','<p>\r\n	&bull; Miễn ph&iacute; đổi trả, sửa chữa sản phẩm<br />\r\n	&bull; Đổi trả tại cửa h&agrave;ng hoặc qua bưu điện<br />\r\n	&bull; Sản phẩm đổi trả phải đảm bảo c&aacute;c quy định tại LAHAVA</p>\r\n');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;


--
-- Create Table `sanpham`
--

DROP TABLE IF EXISTS `sanpham`;
CREATE TABLE `sanpham` (
  `sp_id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_sp` varchar(20) NOT NULL,
  `ten_sp` varchar(255) NOT NULL,
  `ten_sp_kd` varchar(255) NOT NULL,
  `mo_ta` text NOT NULL,
  `chi_tiet` text NOT NULL,
  `hinh_dai_dien` varchar(255) NOT NULL,
  `hinh_anh` text NOT NULL,
  `gia` int(11) NOT NULL,
  `khuyen_mai` int(11) NOT NULL,
  `ngay` int(11) NOT NULL,
  `loai_id` int(11) NOT NULL,
  `idTL` int(10) NOT NULL,
  `kg_id` int(11) NOT NULL,
  PRIMARY KEY (`sp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=139 DEFAULT CHARSET=utf8;

--
-- Data for Table `sanpham`
--

/*!40000 ALTER TABLE `sanpham` DISABLE KEYS */;
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('124','LP2','Áo Lampoghini đỏ tươi','ao-lampoghini-do-tuoi','','<p style=\"text-align: center;\">\r\n	<img alt=\"\" src=\"upload/images/4.png\" /></p>\r\n','upload/images/4.png','','130000','0','-25200','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('125','LP3','Áo Lampoghini xanh đen','ao-lampoghini-xanh-den','','<p style=\"text-align: center;\">\r\n	<img alt=\"\" src=\"upload/images/2.png\" /></p>\r\n','upload/images/2.png','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('126','LP4','Áo Lampoghini xanh da trời','ao-lampoghini-xanh-da-troi','','<p style=\"text-align: center;\">\r\n	<img alt=\"\" src=\"upload/images/6.png\" /></p>\r\n','upload/images/6.png','','130000','10','1401379200','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('127','LP5','Áo Lampoghini vàng','ao-lampoghini-vang','','','upload/images/7.png','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('128','LP6','Áo Lampoghini trắng','ao-lampoghini-trang','','<p style=\"text-align: center;\">\r\n	<img src=\"upload/images/5.png\" /></p>\r\n','upload/images/5.png','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('129','LP7','Áo Lampoghini xám','ao-lampoghini-xam','','','upload/images/10.png','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('130','LP8','Áo Lampoghini đen','ao-lampoghini-den','','','upload/images/8.png','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('131','LP9','Áo Lampoghini hồng','ao-lampoghini-hong','','','upload/images/9.png','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('132','PL1','Áo Polo trắng','ao-polo-trang','','','upload/images/2.jpg','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('133','PL2','Áo Polo hồng','ao-polo-hong','','','upload/images/polo-hong.jpg','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('134','PL3','Áo Polo vàng','ao-polo-vang','','','upload/images/polo-vang.jpg','','130000','0','0','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('135','LP','Áo Lampoghini cao cấp','ao-lampoghini-cao-cap','Áo lamborghini cho các bạn nam và nữ Áo nam 120k Áo nữ 90k','<ul style=\"font-family: \'Open Sans\', Helvetica, Arial, sans-serif; letter-spacing: 0px; font-size: 13px; line-height: 19px; color: rgb(66, 73, 77); list-style-type: square;\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<p>\r\n			&Aacute;o thun nam Lamborghini cao cấp, chất lượng xuất khẩu, vải c&aacute; sấu co d&atilde;n 4 chiều, th&ecirc;u logo Lamborghini sang trọng.<br />\r\n			&Aacute;o thun lamborghini c&oacute; thiết kế đơn giản đậm chất nam t&iacute;nh c&agrave;ng l&agrave;m tăng vẻ lịch l&atilde;m sang trọng cho người mặc.<br />\r\n			Th&iacute;ch hợp ngay cả nơi c&ocirc;ng sở, mặc ở nh&agrave; hay vui chơi cung bạn b&egrave;. Bạn c&oacute; mix với quần jean hoặc quần t&acirc;y, quần lững,&nbsp;quần sort, đều rất đẹp.</p>\r\n		<p>\r\n			&Aacute;o lamborghini c&oacute; 9 m&agrave;u sắc:<strong>&nbsp;Trắng, đen, đỏ, hồng, v&agrave;ng, xanh coban, xanh da, xanh l&aacute;, xanh đen, x&aacute;m.</strong><br />\r\n			Sản phẩm gồm c&aacute;c size&nbsp;<strong>S, <em>M, &nbsp;L, XL, XXL</em></strong></p>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/2.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/10.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/3.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/4.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/5.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/6.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/7.png\" /></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div style=\"text-align: center;\">\r\n			<img alt=\"\" src=\"upload/images/8.png\" /></div>\r\n	</li>\r\n</ul>\r\n','upload/images/1.png','','130000','0','-25200','5','0','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('136','PL','Áo Polo cao cấp','ao-polo-cao-cap','','<p style=\"text-align: center;\">\r\n	<img alt=\"\" src=\"upload/images/polo1.jpg\" /></p>\r\n','upload/images/polo1.jpg','','130000','0','0','5','0','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('123','LP1','Áo Lampoghini đỏ đô','ao-lampoghini-do-do','Áo thun Nam LAMBORGHINI cao cấp vải co dãn 4 chiều, thêu logo Lamborghini','<ul style=\"list-style-type:square;\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div>\r\n			<samp><cite><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: x-large; vertical-align: baseline; background-color: transparent; outline: 0px;\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: 24px; vertical-align: baseline; background-color: transparent; outline: 0px; font-family: \'times new roman\';\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">&Aacute;o thun Nam LAMBORGHINI cao cấp vải co d&atilde;n 4 chiều, th&ecirc;u logo Lamborghini</span></span></span></cite></samp></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div>\r\n			<samp><cite><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: x-large; vertical-align: baseline; background-color: transparent; outline: 0px;\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: 24px; vertical-align: baseline; background-color: transparent; outline: 0px; font-family: \'times new roman\';\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">Thiết kế đơn giản đậm chất nam t&iacute;nh c&agrave;ng l&agrave;m tăng vẻ lịch l&atilde;m sang trọng cho người mặc</span></span></span></cite></samp></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div>\r\n			<samp><cite><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: x-large; vertical-align: baseline; background-color: transparent; outline: 0px;\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: 24px; vertical-align: baseline; background-color: transparent; outline: 0px; font-family: \'times new roman\';\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">Th&iacute;ch hợp ngay cả nơi c&ocirc;ng sở, mặc ở nh&agrave; hay vui chơi cung bạn b&egrave;. Bạn c&oacute; mix với quần jean hoặc quần t&acirc;y, quần sọt đều rất đẹp.</span></span></span></cite></samp></div>\r\n	</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">\r\n		<div>\r\n			<samp><cite><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: x-large; vertical-align: baseline; background-color: transparent; outline: 0px;\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; font-size: 24px; vertical-align: baseline; background-color: transparent; outline: 0px; font-family: \'times new roman\';\"><span style=\"margin: 0px; padding: 0px; border: none; list-style: none; vertical-align: baseline; background-color: transparent; outline: 0px;\">Sản phẩm kh&ocirc;ng chỉ ph&ugrave; hợp cho ri&ecirc;ng bạn m&agrave; đ&acirc;y c&ograve;n l&agrave; m&oacute;n qu&agrave; tuyệt vời d&agrave;nh cho người th&acirc;n. Nhanh tay c&aacute;c bạn nh&eacute; ^^</span></span></span></cite></samp></div>\r\n	</li>\r\n</ul>\r\n<p style=\"text-align: center;\">\r\n	<img alt=\"\" src=\"upload/images/lampo-do.jpg\" /></p>\r\n','upload/images/lampo-do.jpg','','130000','0','-25200','3','1','2');
INSERT INTO `sanpham` (`sp_id`,`ma_sp`,`ten_sp`,`ten_sp_kd`,`mo_ta`,`chi_tiet`,`hinh_dai_dien`,`hinh_anh`,`gia`,`khuyen_mai`,`ngay`,`loai_id`,`idTL`,`kg_id`) VALUES ('138','','','','','','upload/images/Ao%20Thun%20Polo%202013%20(4).jpg','','0','0','0','1','0','1');
/*!40000 ALTER TABLE `sanpham` ENABLE KEYS */;


--
-- Create Table `size`
--

DROP TABLE IF EXISTS `size`;
CREATE TABLE `size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(10) NOT NULL,
  PRIMARY KEY (`size_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Data for Table `size`
--

/*!40000 ALTER TABLE `size` DISABLE KEYS */;
INSERT INTO `size` (`size_id`,`size`) VALUES ('2','S');
INSERT INTO `size` (`size_id`,`size`) VALUES ('3','M');
INSERT INTO `size` (`size_id`,`size`) VALUES ('4','L');
INSERT INTO `size` (`size_id`,`size`) VALUES ('5','XL');
INSERT INTO `size` (`size_id`,`size`) VALUES ('6','XXL');
/*!40000 ALTER TABLE `size` ENABLE KEYS */;


--
-- Create Table `sp_chat`
--

DROP TABLE IF EXISTS `sp_chat`;
CREATE TABLE `sp_chat` (
  `chat_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  PRIMARY KEY (`chat_id`,`sp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `sp_chat`
--

/*!40000 ALTER TABLE `sp_chat` DISABLE KEYS */;
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','123');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','124');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','125');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','126');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','127');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','129');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','130');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','131');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','132');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','133');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','134');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','135');
INSERT INTO `sp_chat` (`chat_id`,`sp_id`) VALUES ('1','136');
/*!40000 ALTER TABLE `sp_chat` ENABLE KEYS */;


--
-- Create Table `sp_kieu`
--

DROP TABLE IF EXISTS `sp_kieu`;
CREATE TABLE `sp_kieu` (
  `kieu_id` int(10) NOT NULL,
  `sp_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `sp_kieu`
--

/*!40000 ALTER TABLE `sp_kieu` DISABLE KEYS */;
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('4','125');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','125');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','119');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('4','124');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','124');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('4','123');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','123');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','126');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','127');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','128');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','129');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','130');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','131');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','132');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('4','132');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','133');
INSERT INTO `sp_kieu` (`kieu_id`,`sp_id`) VALUES ('1','134');
/*!40000 ALTER TABLE `sp_kieu` ENABLE KEYS */;


--
-- Create Table `sp_mau`
--

DROP TABLE IF EXISTS `sp_mau`;
CREATE TABLE `sp_mau` (
  `sp_id` int(11) NOT NULL,
  `mau_id` int(11) NOT NULL,
  `loai_id` int(11) NOT NULL,
  PRIMARY KEY (`sp_id`,`mau_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `sp_mau`
--

/*!40000 ALTER TABLE `sp_mau` DISABLE KEYS */;
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','21','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('134','9','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','20','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','17','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('133','5','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('132','17','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('131','5','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('130','3','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('129','20','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('128','17','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('127','9','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('126','13','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('125','10','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('124','6','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('123','21','3');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','13','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','12','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','10','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','9','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','7','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','6','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','5','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('135','3','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','3','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','5','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','6','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','9','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','10','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','17','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','20','5');
INSERT INTO `sp_mau` (`sp_id`,`mau_id`,`loai_id`) VALUES ('136','21','5');
/*!40000 ALTER TABLE `sp_mau` ENABLE KEYS */;


--
-- Create Table `sp_size`
--

DROP TABLE IF EXISTS `sp_size`;
CREATE TABLE `sp_size` (
  `sp_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  PRIMARY KEY (`sp_id`,`size_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `sp_size`
--

/*!40000 ALTER TABLE `sp_size` DISABLE KEYS */;
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('123','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('123','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('123','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('123','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('123','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('124','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('124','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('124','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('124','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('124','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('125','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('125','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('125','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('125','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('125','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('126','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('126','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('126','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('126','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('126','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('127','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('127','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('127','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('127','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('127','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('128','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('128','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('128','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('128','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('128','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('129','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('129','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('129','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('129','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('129','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('130','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('130','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('130','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('130','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('130','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('131','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('131','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('131','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('131','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('131','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('132','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('132','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('132','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('132','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('132','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('133','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('133','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('133','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('133','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('133','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('134','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('134','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('134','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('134','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('134','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('135','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('135','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('135','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('135','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('135','6');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('136','2');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('136','3');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('136','4');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('136','5');
INSERT INTO `sp_size` (`sp_id`,`size_id`) VALUES ('136','6');
/*!40000 ALTER TABLE `sp_size` ENABLE KEYS */;


--
-- Create Table `sp_tag`
--

DROP TABLE IF EXISTS `sp_tag`;
CREATE TABLE `sp_tag` (
  `sp_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`sp_id`,`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `sp_tag`
--

/*!40000 ALTER TABLE `sp_tag` DISABLE KEYS */;
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('125','811');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('127','813');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('128','814');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('129','815');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('130','816');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('131','817');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('132','818');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('133','819');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('136','822');
INSERT INTO `sp_tag` (`sp_id`,`tag_id`) VALUES ('138','824');
/*!40000 ALTER TABLE `sp_tag` ENABLE KEYS */;


--
-- Create Table `tag`
--

DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) NOT NULL,
  `tag_name_kd` varchar(255) NOT NULL,
  PRIMARY KEY (`tag_id`),
  FULLTEXT KEY `tag_name` (`tag_name`)
) ENGINE=MyISAM AUTO_INCREMENT=825 DEFAULT CHARSET=utf8;

--
-- Data for Table `tag`
--

/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('113','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('114','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('115','vay cuoi','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('116','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('111','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('112','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('36','váy đuôi cá','vay-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('37','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('38','váy ren đuôi cá','vay-ren-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('39','lace wedding','lace-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('40','fishing dress','fishing-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('41','ao cuoi','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('42','wedding dress;','wedding-dress;');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('43','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('44','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('45','váy cưới đỏ','vay-cuoi-do');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('46','áo cưới đỏ','ao-cuoi-do');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('47','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('48','may ao cuoi','may-ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('49','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('50','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('51','ao cuoi cao cap','ao-cuoi-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('52','đầm cưới đẹp','dam-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('53','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('54','ao cuoi','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('55','couture wedding','couture-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('56','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('57','ao cuoi dep','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('58','vay cuoi','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('59','vay cuoi dep','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('60','ao cuoi cup nguc','ao-cuoi-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('61','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('62','váy cưới đuôi cá','vay-cuoi-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('63','đầm đuôi cá','dam-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('64','đầm cưới đuôi cá','dam-cuoi-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('65','strapless wedding lace','strapless-wedding-lace');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('66','lace wedding dress','lace-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('67','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('68','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('69','đầm dự tiệc cưới','dam-du-tiec-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('70','đầm xòe','dam-xoe');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('71','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('72','đầm cưới ngắn','dam-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('73','cocktail dresses','cocktail-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('74','party dress','party-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('75','nice dresses','nice-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('76','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('77','đầm chữ v','dam-chu-v');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('78','đầm xếp ly','dam-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('79','váy dự tiệc đẹp','vay-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('80','v neck dress','v-neck-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('81','dress for party','dress-for-party');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('82','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('83','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('84','váy xếp ly','vay-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('85','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('86','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('87','váy ngắn','vay-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('88','váy cưới ngắn','vay-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('89','váy cúp ngực','vay-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('90','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('91','short dress','short-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('92','đầm dài dạ hội','dam-dai-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('93','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('94','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('95','đầm hở lưng','dam-ho-lung');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('96','đầm cắt khoét','dam-cat-khoet');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('97','đầm lệch vai','dam-lech-vai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('98','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('99','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('100','prom dresses','prom-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('101','cut out dress','cut-out-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('102','đầm cưới','dam-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('103','đầm chiffon','dam-chiffon');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('104','đầm cao cấp','dam-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('105','chiffon dress','chiffon-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('106','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('107','couture dress','couture-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('108','dam da hoi','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('109','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('110','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('117','ao cuoi','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('118','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('119','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('120','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('121','vay cuoi','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('122','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('123','ao cuoi','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('124','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('125','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('126','lace wedding','lace-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('127','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('128','váy cưới cúp ngực','vay-cuoi-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('129','đầm cưới cao cấp','dam-cuoi-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('130','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('131','đầm cưới dạ hội','dam-cuoi-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('132','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('133','strapless wedding dress','strapless-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('134','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('135','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('136','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('137','áo cưới đẹp','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('138','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('139','đầm đính đá','dam-dinh-da');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('140','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('141','lace dresses','lace-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('142','strapless lace dress','strapless-lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('143','wedding dresses','wedding-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('144','bridal dress','bridal-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('145','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('146','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('147','đầm ngắn dự tiệc','dam-ngan-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('148','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('149','váy kim sa','vay-kim-sa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('150','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('151','váy dạ hội ngắn','vay-da-hoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('152','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('153','đầm dự tiệc đẹp','dam-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('154','glamorous dress','glamorous-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('155','sequin dress','sequin-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('156','luxury dresses','luxury-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('157','đầm dạ hội lệch vai','dam-da-hoi-lech-vai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('158','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('159','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('160','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('161','đầm cách điệu','dam-cach-dieu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('162','đầm xanh','dam-xanh');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('163','đầm phối màu tinh tế','dam-phoi-mau-tinh-te');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('164','đầm dự tiệc sang trọng','dam-du-tiec-sang-trong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('165','mẫu đầm dài đẹp','mau-dam-dai-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('166','fashion dress','fashion-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('167','đầm ngắn','đam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('168','đầm dự tiệc','đam-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('169','đầm dạ hội','đam-da-hai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('170','đầm dự tiệc','đam-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('171','đầm dạ hội cao cấp','đam-da-hai-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('172','sweetheart bodice gown','sweetheart-bodice-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('173','đầm dạ hội','đam-da-hai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('174','đầm dự tiệc','đam-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('175','đầm xếp li','đam-xap-li');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('176','đầm dạ hội','đam-da-hai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('177','đầm dạ hội sang trọng','đam-da-hai-sang-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('178','may đầm dạ hội','may-đam-da-hai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('179','one shoulder gown','one-shoulder-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('180','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('181','đầm ren đẹp','đam-ren-đap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('182','váy ren cao cấp','vay-ren-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('183','đầm dự tiệc','đam-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('184','váy dự tiệc','vay-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('185','đầm ngắn','đam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('186','váy tay lửng','vay-tay-lang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('187','mini dresses','mini-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('188','lace gown','lace-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('189','luxury lace dress','luxury-lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('190','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('191','đầm ren','đam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('192','đầm ren dự tiệc','đam-ren-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('193','đầm dự tiệc','đam-da-tiac');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('194','đầm ngắn','đam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('195','váy ren dài tay','vay-ren-dai-tay');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('196','đầm cưới','đam-cưai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('197','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('198','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('199','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('200','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('201','đầm tua rua','dam-tua-rua');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('202','Embellished neck line','embellished-neck-line');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('203','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('204','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('205','đầm lông thú','dam-long-thu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('206','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('207','feather dress','feather-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('208','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('209','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('210','đầm ren cao cấp','dam-ren-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('211','váy tua rua','vay-tua-rua');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('212','ren chiếc lá','ren-chiec-la');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('213','floral and leaf lace','floral-and-leaf-lace');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('214','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('215','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('216','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('217','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('218','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('219','đầm ren ngắn','dam-ren-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('220','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('221','beige lace','beige-lace');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('222','đầm ren đỏ','dam-ren-do');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('223','váy ren ngắn','vay-ren-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('224','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('225','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('226','red lace dress','red-lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('227','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('228','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('229','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('230','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('231','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('232','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('233','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('234','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('235','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('236','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('237','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('238','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('239','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('240','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('241','đầm ren chỉ','dam-ren-chi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('242','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('243','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('244','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('245','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('246','váy ren đẹp','vay-ren-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('247','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('248','đầm lông vũ','dam-long-vu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('249','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('250','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('251','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('252','váy ren dự tiệc','vay-ren-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('253','LAHAVA dresses','lahava-dresses');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('254','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('255','váy ren dạ hội','vay-ren-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('256','đầm công chúa','dam-cong-chua');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('257','đầm ren cô dâu','dam-ren-co-dau');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('258','váy ren ngắn đẹp','vay-ren-ngan-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('259','đầm ren hồng','dam-ren-hong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('260','pink lace dress','pink-lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('261','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('262','princess dress','princess-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('263','bridesmaid style','bridesmaid-style');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('264','đầm phù dâu','dam-phu-dau');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('265','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('266','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('267','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('268','bridesmaid dress','bridesmaid-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('269','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('270','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('271','đầm ngắn đẹp','dam-ngan-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('272','váy ngắn dự tiệc','vay-ngan-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('273','red dress','red-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('274','twisted pleat overlay dress','twisted-pleat-overlay-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('275','party for dress','party-for-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('276','đầm khoét','dam-khoet');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('277','đầm cutout','dam-cutout');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('278','mẫu đầm ngắn đẹp','mau-dam-ngan-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('279','mẫu đầm dự tiệc đẹp','mau-dam-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('280','đầm dự tiệc đẹp','dam-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('281','đầm lông vũ đẹp','dam-long-vu-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('282','đầm Jennifer Lopez','dam-jennifer-lopez');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('283','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('284','đầm ngắn dự tiệc đẹp','dam-ngan-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('285','jennifer lopez dress','jennifer-lopez-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('286','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('287','đầm dự tiệc đẹp','dam-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('288','mẫu đầm ren','mau-dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('289','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('290','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('291','đầm voan đẹp','dam-voan-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('292','váy cưới dạ hội','vay-cuoi-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('293','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('294','charming one shoulder dress','charming-one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('295','đầm cưới ren','dam-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('296','đầm ren đuôi cá','dam-ren-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('297','đầm ren cúp ngực','dam-ren-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('298','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('299','nice wedding dress','nice-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('300','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('301','đầm cưới ren đẹp','dam-cuoi-ren-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('302','đầm dạ hội cưới','dam-da-hoi-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('303','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('304','mẫu váy cưới ren','mau-vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('305','mẫu ren đẹp','mau-ren-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('306','mẫu váy đẹp','mau-vay-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('307','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('308','đầm cúp ngực đẹp','dam-cup-nguc-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('309','váy dạ hội cưới','vay-da-hoi-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('310','đầm cô dâu','dam-co-dau');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('311','áo cưới cao cấp','ao-cuoi-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('312','graceful dress','graceful-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('313','dress couture','dress-couture');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('314','áo cưới cúp ngực','ao-cuoi-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('315','may áo cưới','may-ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('316','đầm cưới sang trọng','dam-cuoi-sang-trong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('317','những mẫu váy cưới đẹp','nhung-mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('318','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('319','wedding 2013','wedding-2013');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('320','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('321','đầm dài ren','dam-dai-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('322','váy cưới cao cấp','vay-cuoi-cao-cap');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('323','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('324','mẫu đầm đẹp','mau-dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('325','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('326','vietnam wedding','vietnam-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('327','vietnam dress','vietnam-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('328','lace wedding','lace-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('329','dress V neck','dress-v-neck');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('330','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('331','váy trễ vai','vay-tre-vai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('332','mẫu váy cưới mới','mau-vay-cuoi-moi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('333','đầm đính ren','dam-dinh-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('334','off shoulder dress','off-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('335','váy cổ chữ V','vay-co-chu-v');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('336','váy ren hot','vay-ren-hot');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('337','váy cưới ren đẹp','vay-cuoi-ren-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('338','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('339','V neck wedding dress','v-neck-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('340','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('341','lace wedding','lace-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('342','váy cưới kết hoa','vay-cuoi-ket-hoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('343','đầm kết bông','dam-ket-bong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('344','đầm 2 dây','dam-2-day');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('345','đầm cưới','dam-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('346','may áo cưới đẹp','may-ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('347','chỗ may áo cưới đẹp','cho-may-ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('348','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('349','graceful wedding dress','graceful-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('350','bridal gown','bridal-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('351','lahava wedding','lahava-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('352','two straps wedding','two-straps-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('353','áo cưới đính re','ao-cuoi-dinh-re');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('354','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('355','đầm cưới phồng','dam-cuoi-phong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('356','đầm cô đâu','dam-co-dau');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('357','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('358','váy cưới đính ren','vay-cuoi-dinh-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('359','may áo cưới','may-ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('360','váy cưới lệch vai','vay-cuoi-lech-vai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('361','áo cưới','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('362','áo cưới có đuôi','ao-cuoi-co-duoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('363','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('364','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('365','Pleated bodice','pleated-bodice');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('366','đầm cưới ren','dam-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('367','váy ren cưới','vay-ren-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('368','áo cưới đẹp nhất','ao-cuoi-dep-nhat');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('369','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('370','lace wedding','lace-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('371','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('372','váy cưới lửng','vay-cuoi-lung');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('373','mẫu đầm cưới ngắn đẹp','mau-dam-cuoi-ngan-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('374','đầm cưới hight low','dam-cuoi-hight-low');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('375','váy cưới đẹp nhất','vay-cuoi-dep-nhat');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('376','hight low wedding dress','hight-low-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('377','short wedding dress','short-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('378','đầm cưới đính hoa đẹp','dam-cuoi-dinh-hoa-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('379','đầm cưới cách điệu','dam-cuoi-cach-dieu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('380','áo cưới','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('381','Fabulous ruffled','fabulous-ruffled');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('382','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('383','đầm cưới ren','dam-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('384','váy cưới ren ngọt ngào','vay-cuoi-ren-ngot-ngao');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('385','mẫu đầm cưới ren đẹp','mau-dam-cuoi-ren-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('386','đầm ren trắng','dam-ren-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('387','white lace wedding gown','white-lace-wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('388','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('389','lahava lace dress','lahava-lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('390','new lace dress','new-lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('391','đầm cưới trắng','dam-cuoi-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('392','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('393','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('394','white wedding gown','white-wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('395','new wedding dress','new-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('396','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('397','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('398','đầm dập ly','dam-dap-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('399','ruched dress','ruched-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('400','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('401','vietnam wedding dress','vietnam-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('402','đầm kết hoa','dam-ket-hoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('403','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('404','one shoulder wedding dress','one-shoulder-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('405','đầm cưới nơ','dam-cuoi-no');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('406','đầm cưới xếp ly','dam-cuoi-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('407','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('408','bowknot dress','bowknot-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('409','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('410','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('411','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('412','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('413','đầm cưới cúp ngực','dam-cuoi-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('414','fishing wedding dress','fishing-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('415','charming strapless dress','charming-strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('416','váy cưới tay cánh tiên','vay-cuoi-tay-canh-tien');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('417','váy cưới màu trắng','vay-cuoi-mau-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('418','vietnam wedding','vietnam-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('419','glamour wedding dress','glamour-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('420','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('421','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('422','áo cưới đuôi cá','ao-cuoi-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('423','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('424','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('425','áo cưới mới','ao-cuoi-moi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('426','couture wedding dress','couture-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('427','fishtail wedding dress','fishtail-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('428','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('429','đầm sere','dam-sere');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('430','áo cưới','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('431','đầm cưới xòe','dam-cuoi-xoe');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('432','váy cưới xòe','vay-cuoi-xoe');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('433','đầm cô dâu đẹp','dam-co-dau-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('434','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('435','asia weddng dress','asia-weddng-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('436','áo cưới','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('437','váy cưới tùng xòe','vay-cuoi-tung-xoe');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('438','váy cưới trắng','vay-cuoi-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('439','sere đẹp','sere-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('440','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('441','áo cưới','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('442','asia wedding dress','asia-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('443','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('444','áo cưới 3 tầng','ao-cuoi-3-tang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('445','váy cưới độc','vay-cuoi-doc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('446','váy cưới cách điệu','vay-cuoi-cach-dieu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('447','đầm cưới','dam-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('448','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('449','three levels wedding dress','three-levels-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('450','đầm đính cườm','dam-dinh-cuom');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('451','váy cưới đính pha lê','vay-cuoi-dinh-pha-le');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('452','áo cưới trắng','ao-cuoi-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('453','mẫu váy cưới đẹp','mau-vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('454','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('455','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('456','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('457','đầm cổ chữ V','dam-co-chu-v');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('458','mẫu đầm dạ hội đẹp','mau-dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('459','long prom dress','long-prom-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('460','prom for party','prom-for-party');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('461','blue dress','blue-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('462','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('463','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('464','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('465','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('466','đầm dạ hội voan','dam-da-hoi-voan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('467','Sleeveless hight split','sleeveless-hight-split');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('468','đầm ren dài','dam-ren-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('469','đầm ren dạ hội','dam-ren-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('470','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('471','đầm xẻ tà','dam-xe-ta');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('472','once lace shoulder','once-lace-shoulder');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('473','black lace bodice','black-lace-bodice');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('474','built with bra','built-with-bra');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('475','asian dress','asian-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('476','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('477','đầm dạ hội đỏ','dam-da-hoi-do');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('478','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('479','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('480','long evening dress','long-evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('481','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('482','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('483','Full shiny beadins straps','full-shiny-beadins-straps');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('484','Detachable ribbon','detachable-ribbon');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('485','tencel Fabric','tencel-fabric');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('486','zip on the back','zip-on-the-back');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('487','đầm dạ hội cúp ngực','dam-da-hoi-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('488','may đầm dài','may-dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('489','đầm đính pha lê','dam-dinh-pha-le');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('490','long dress','long-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('491','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('492','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('493','fully pleated bodice','fully-pleated-bodice');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('494','shiny pleated silk chiffon fabric','shiny-pleated-silk-chiffon-fabric');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('495','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('496','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('497','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('498','đầm dài dự tiệc','dam-dai-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('499','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('500','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('501','one shoulder style','one-shoulder-style');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('502','Unique sash from shoulder to skirt','unique-sash-from-shoulder-to-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('503','Fully pleated bodice','fully-pleated-bodice');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('504','Satin waistband','satin-waistband');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('505','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('506','đầm xếp ly đẹp','dam-xep-ly-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('507','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('508','lace around neckline','lace-around-neckline');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('509','prom dress','prom-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('510','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('511','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('512','prom dress','prom-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('513','váy xẻ tà','vay-xe-ta');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('514','váy cách điệu','vay-cach-dieu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('515','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('516','mẫu váy dạ hội đẹp','mau-vay-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('517','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('518','prom dress','prom-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('519','chiffon velvet fabric','chiffon-velvet-fabric');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('520','váy dạ hội sexy','vay-da-hoi-sexy');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('521','mẫu đầm gợi cảm','mau-dam-goi-cam');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('522','đầm dạ hội cá tính','dam-da-hoi-ca-tinh');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('523','đầm lưới','dam-luoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('524','váy lệch vai','vay-lech-vai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('525','handmade flowers','handmade-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('526','Delicate beads chain on the waist','delicate-beads-chain-on-the-waist');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('527','built without bra','built-without-bra');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('528','fine lace','fine-lace');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('529','zip on the left','zip-on-the-left');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('530','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('531','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('532','đầm dài đuôi cá','dam-dai-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('533','đầm màu tím','dam-mau-tim');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('534','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('535','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('536','mẫu váy tôn dáng','mau-vay-ton-dang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('537','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('538','Fitted top with handmade flowers','fitted-top-with-handmade-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('539','mermaid style','mermaid-style');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('540','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('541','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('542','đầm xếp ly','dam-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('543','váy dạ hội màu hồng','vay-da-hoi-mau-hong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('544','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('545','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('546','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('547','Sweetheart neckline with beads decorated','sweetheart-neckline-with-beads-decorated');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('548','Fully pleats with beads chain','fully-pleats-with-beads-chain');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('549','A slit on the skirt','a-slit-on-the-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('550','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('551','đầm trang trí hoa','dam-trang-tri-hoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('552','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('553','strapless style','strapless-style');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('554','Pleated bust with flowers','pleated-bust-with-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('555','đầm dạ hội đơn giản','dam-da-hoi-don-gian');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('556','chất liệu đẹp','chat-lieu-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('557','váy dạ hội đuôi cá','vay-da-hoi-duoi-ca');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('558','simple evening dress','simple-evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('559','Fully beaded cap sleeves','fully-beaded-cap-sleeves');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('560','Fitted bodice with mermaid skirt','fitted-bodice-with-mermaid-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('561','A bowknot with beads on the waist','a-bowknot-with-beads-on-the-waist');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('562','đầm dạ hội gợi cảm','dam-da-hoi-goi-cam');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('563','đầm dài sexy','dam-dai-sexy');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('564','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('565','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('566','Sexy V neck with short sleeves','sexy-v-neck-with-short-sleeves');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('567','Beaded back with buttons','beaded-back-with-buttons');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('568','Satin waistband with bowknot and ornament on','satin-waistband-with-bowknot-and-ornament-on');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('569','Mermaid skirt style','mermaid-skirt-style');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('570','váy dạ hội xẻ tà','vay-da-hoi-xe-ta');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('571','đầm dài cá tính','dam-dai-ca-tinh');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('572','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('573','váy dạ hội màu đỏ','vay-da-hoi-mau-do');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('574','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('575','Ruched bodice with beads decorated','ruched-bodice-with-beads-decorated');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('576','A slit on the right skirt','a-slit-on-the-right-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('577','Zip on the left side','zip-on-the-left-side');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('578','đầm xếp ly','dam-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('579','đầm dài nhẹ nhàng','dam-dai-nhe-nhang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('580','đầm dạ hội màu xanh','dam-da-hoi-mau-xanh');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('581','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('582','v cut evening dress','v-cut-evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('583','pleated dress','pleated-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('584','Crisscross back','crisscross-back');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('585','Satin Bowknot','satin-bowknot');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('586','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('587','đầm dạ hội màu hồng nhạt','dam-da-hoi-mau-hong-nhat');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('588','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('589','đầm dự tiệc đẹp','dam-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('590','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('591','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('592','lovely evening dress','lovely-evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('593','fully pleated skirt','fully-pleated-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('594','đầm xếp ly','dam-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('595','sleeveless evening dress','sleeveless-evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('596','Lace on the fitted bodice','lace-on-the-fitted-bodice');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('597','delicated beads','delicated-beads');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('598','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('599','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('600','đầm dạ hội màu xám','dam-da-hoi-mau-xam');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('601','single shoulder','single-shoulder');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('602','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('603','One shoulder with flowers and beads on','one-shoulder-with-flowers-and-beads-on');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('604','Fully pleated top','fully-pleated-top');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('605','A decoration on the dress','a-decoration-on-the-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('606','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('607','váy dự tiệc','vay-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('608','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('609','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('610','đầm xếp ly','dam-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('611','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('612','lace sleeve','lace-sleeve');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('613','Shiny beads with pleats','shiny-beads-with-pleats');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('614','Zip on the right','zip-on-the-right');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('615','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('616','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('617','One shoulder with flowers decorated','one-shoulder-with-flowers-decorated');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('618','Fully ruched bodice till hip','fully-ruched-bodice-till-hip');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('619','Sexy V neck and mermaid skirt','sexy-v-neck-and-mermaid-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('620','Built with bra and bones','built-with-bra-and-bones');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('621','đầm dạ hội màu tím','dam-da-hoi-mau-tim');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('622','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('623','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('624','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('625','Flying fabric on shoulder','flying-fabric-on-shoulder');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('626','Stylish design on the waist','stylish-design-on-the-waist');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('627','zip on the right side','zip-on-the-right-side');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('628','đầm xếp tầng','dam-xep-tang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('629','đầm dạ hội màu đỏ','dam-da-hoi-mau-do');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('630','đầm dự tiệc cưới sang trọng','dam-du-tiec-cuoi-sang-trong');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('631','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('632','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('633','evening gown','evening-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('634','Built with bone and bra','built-with-bone-and-bra');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('635','Multi-layers skirt','multi-layers-skirt');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('636','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('637','áo cưới đẹp','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('638','váy cưới lông vũ','vay-cuoi-long-vu');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('639','feather wedding dress','feather-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('640','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('641','wedding bridal','wedding-bridal');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('642','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('643','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('644','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('645','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('646','váy ren trắng','vay-ren-trang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('647','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('648','lace two shoulder style','lace-two-shoulder-style');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('649','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('650','đầm dạ hội ren','dam-da-hoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('651','váy đính ren','vay-dinh-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('652','đầm dạ hội màu nuy','dam-da-hoi-mau-nuy');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('653','lace prom','lace-prom');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('654','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('655','váy dạ hội lưới đính ren','vay-da-hoi-luoi-dinh-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('656','đầm dạ hội màu đen','dam-da-hoi-mau-den');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('657','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('658','handmade flowers','handmade-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('659','black prom gown','black-prom-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('660','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('661','váy lưới kết hoa','vay-luoi-ket-hoa');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('662','wedding prom gown','wedding-prom-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('663','sexy strapless dress','sexy-strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('664','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('665','handmade flowers','handmade-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('666','áo cưới đẹp','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('667','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('668','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('669','vietnam wedding','vietnam-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('670','đầm dài xếp ly','dam-dai-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('671','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('672','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('673','beautiful drape','beautiful-drape');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('674','one shoulder evening gown','one-shoulder-evening-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('675','couture evening dress','couture-evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('676','nude color dress','nude-color-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('677','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('678','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('679','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('680','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('681','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('682','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('683','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('684','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('685','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('686','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('687','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('688','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('689','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('690','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('691','váy cưới xếp ly','vay-cuoi-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('692','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('693','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('694','V-cut neckline with lace and beads','v-cut-neckline-with-lace-and-beads');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('695','Chiffon velvet fabric','chiffon-velvet-fabric');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('696','Detachable train sash','detachable-train-sash');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('697','Back overlace with diamonds','back-overlace-with-diamonds');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('698','đầm cưới ngắn','dam-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('699','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('700','đầm cưới ngắn','dam-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('701','đầm ngắn dự tiệc','dam-ngan-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('702','đầm cưới đính ren đẹp','dam-cuoi-dinh-ren-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('703','đầm cưới tùng xòe','dam-cuoi-tung-xoe');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('704','white short wedding dress','white-short-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('705','short wedding dress','short-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('706','váy cắt khoét','vay-cat-khoet');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('707','formal dress','formal-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('708','elie saab dress design','elie-saab-dress-design');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('709','huy hoang','huy-hoang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('710','huy hoàng','huy-hoang');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('711','abdef','abdef');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('712','đầm cưới ngắn','dam-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('713','đầm ngắn dự tiệc','dam-ngan-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('714','short wedding dress','short-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('715','short wedding dress','short-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('716','đầm cưới ngắn','dam-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('717','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('718','đầm dự tiệc cưới','dam-du-tiec-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('719','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('720','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('721','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('722','short wedding dress','short-wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('723','đầm cưới ngắn','dam-cuoi-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('724','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('725','váy cưới','vay-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('726','đầm dạ hội','dam-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('727','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('728','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('729','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('730','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('731','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('732','áo cưới đẹp','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('733','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('734','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('735','vietnam wedding','vietnam-wedding');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('736','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('737','handmade flowers','handmade-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('738','đầm dạ hội đẹp','dam-da-hoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('739','handmade flowers','handmade-flowers');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('740','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('741','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('742','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('743','váy cưới đẹp','vay-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('744','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('745','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('746','váy cưới ren','vay-cuoi-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('747','áo cưới đẹp','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('748','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('749','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('750','đầm dài','dam-dai');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('751','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('752','evening gown','evening-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('753','váy dạ hội','vay-da-hoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('754','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('755','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('756','đầm dự tiệc cưới','dam-du-tiec-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('757','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('758','evening dress','evening-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('759','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('760','đầm xếp ly','dam-xep-ly');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('761','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('762','váy ren ngắn','vay-ren-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('763','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('764','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('765','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('766','đầm dự tiệc đẹp','dam-du-tiec-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('767','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('768','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('769','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('770','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('771','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('772','đầm dự tiệc cưới','dam-du-tiec-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('773','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('774','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('775','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('776','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('777','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('778','váy ren ngắn','vay-ren-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('779','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('780','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('781','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('782','one shoulder dress','one-shoulder-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('783','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('784','váy ren','vay-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('785','đầm ngắn','dam-ngan');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('786','đầm dự tiệc','dam-du-tiec');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('787','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('788','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('789','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('790','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('791','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('792','wedding gown','wedding-gown');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('793','áo cưới đẹp','ao-cuoi-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('794','đầm đẹp','dam-dep');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('795','đầm cô dâu','dam-co-dau');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('796','đầm cúp ngực','dam-cup-nguc');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('797','đầm ren','dam-ren');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('798','strapless dress','strapless-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('799','lace dress','lace-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('800','áo cưới','ao-cuoi');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('801','wedding dress','wedding-dress');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('802','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('803','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('804','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('805','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('806','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('807','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('808','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('809','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('810','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('811','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('812','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('813','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('814','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('815','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('816','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('817','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('818','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('819','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('820','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('821','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('822','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('823','','');
INSERT INTO `tag` (`tag_id`,`tag_name`,`tag_name_kd`) VALUES ('824','','');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;


--
-- Create Table `theloai`
--

DROP TABLE IF EXISTS `theloai`;
CREATE TABLE `theloai` (
  `idTL` int(10) NOT NULL AUTO_INCREMENT,
  `TenTL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idTL`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `theloai`
--

/*!40000 ALTER TABLE `theloai` DISABLE KEYS */;
INSERT INTO `theloai` (`idTL`,`TenTL`) VALUES ('1',' Thời Trang Nam');
INSERT INTO `theloai` (`idTL`,`TenTL`) VALUES ('2','Thời Trang Nữ');
INSERT INTO `theloai` (`idTL`,`TenTL`) VALUES ('3','Couple');
INSERT INTO `theloai` (`idTL`,`TenTL`) VALUES ('4','Phụ kiện');
/*!40000 ALTER TABLE `theloai` ENABLE KEYS */;


--
-- Create Table `tintuc`
--

DROP TABLE IF EXISTS `tintuc`;
CREATE TABLE `tintuc` (
  `idTin` int(10) NOT NULL AUTO_INCREMENT,
  `idLT` int(10) NOT NULL,
  `TieuDe` text COLLATE utf8_unicode_ci NOT NULL,
  `TieuDe_KhongDau` text COLLATE utf8_unicode_ci NOT NULL,
  `TomTat` text COLLATE utf8_unicode_ci NOT NULL,
  `UrlHinh` text COLLATE utf8_unicode_ci NOT NULL,
  `Ngay` datetime NOT NULL,
  `NoiDung` text COLLATE utf8_unicode_ci NOT NULL,
  `AnHien` int(10) NOT NULL,
  PRIMARY KEY (`idTin`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `tintuc`
--

/*!40000 ALTER TABLE `tintuc` DISABLE KEYS */;
INSERT INTO `tintuc` (`idTin`,`idLT`,`TieuDe`,`TieuDe_KhongDau`,`TomTat`,`UrlHinh`,`Ngay`,`NoiDung`,`AnHien`) VALUES ('1','2','Cận cảnh giàn khoan HD-981 đang hoạt động phi pháp','can-canh-gian-khoan-hd-981-dang-hoat-dong-phi-phap','<p>\r\n	<span style=\"color: rgb(68, 68, 68); font-family: \'Times New Roman\', Times, serif; font-size: 14px; font-weight: bold; line-height: 19.488000869750977px;\">Gi&agrave;n khoan Hải Dương 981 trị gi&aacute; 1 tỷ USD của Trung Quốc c&oacute; diện t&iacute;ch bằng s&acirc;n b&oacute;ng đ&aacute;, c&oacute; thể chịu được s&oacute;ng cao 10 m&eacute;t c&ugrave;ng sức gi&oacute; 160km/h.</span></p>\r\n','http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/dau4_copy.JPG','2014-05-08 14:28:58','<p>\r\n	<span style=\"background-color: transparent; color: rgb(68, 68, 68); font-family: \'Times New Roman\', Times, serif; font-size: 1.16em; font-weight: bold; line-height: 1.4;\">Gi&agrave;n khoan Hải Dương 981 trị gi&aacute; 1 tỷ USD của Trung Quốc c&oacute; diện t&iacute;ch bằng s&acirc;n b&oacute;ng đ&aacute;, c&oacute; thể chịu được s&oacute;ng cao 10 m&eacute;t c&ugrave;ng sức gi&oacute; 160km/h.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<article style=\"box-sizing: border-box; margin: 0px 20px 0px 0px; padding: 0px 0px 5px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; background-color: transparent; float: left; position: inherit; z-index: 1; width: 660px; color: rgb(0, 0, 0); cursor: default;\">\r\n	<div class=\"content\" itemprop=\"articleBody\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 1.16em; vertical-align: baseline; background-color: transparent; font-family: \'Times New Roman\', Times, serif; line-height: 1.4;\">\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/dau4_copy.JPG\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						<p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n							Hải Dương 981 (HD-981) l&agrave; gi&agrave;n khoan nửa nổi nửa ch&igrave;m, d&agrave;i 114 m, rộng 90 m, cao 137 m v&agrave; nặng 31.000 tấn. Diện t&iacute;ch mặt s&agrave;n của n&oacute; rộng bằng một s&acirc;n b&oacute;ng đ&aacute; ti&ecirc;u chuẩn. Theo&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Nhật b&aacute;o phố Wall</em>&nbsp;của Mỹ, lượng th&eacute;p để x&acirc;y dựng HD-981 lớn gấp 4 lần số nguy&ecirc;n liệu dựng th&aacute;p Eiffel của Ph&aacute;p. Theo thiết kế, HD-981 c&oacute; thể chịu được s&oacute;ng cao 10 m c&ugrave;ng sức gi&oacute; l&ecirc;n tới 160 km/h. Ảnh:&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">China News</em></p>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/dau2.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						<p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n							Tổng c&ocirc;ng ty Dầu kh&iacute; Hải Dương Trung Quốc (CNOOC) hạ thủy gi&agrave;n khoan HD-981 v&agrave;o giữa năm 2012. Hiện tại, HD-981 thuộc quyền quản l&yacute; của c&ocirc;ng ty dịch vụ Bãi d&acirc;̀u Trung Qu&ocirc;́c (COSL), đơn vị trực thuộc CNOOC. Ảnh:&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Xinhua.</em></p>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Khanh_thanh_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						HD-981 l&agrave; loại gi&agrave;n khoan b&aacute;n ch&igrave;m thế hệ thứ 6, chuyện dụng ở v&ugrave;ng nước s&acirc;u đầu ti&ecirc;n của Trung Quốc. N&oacute; ra đời nhằm khai th&aacute;c dầu v&agrave; kh&iacute; đốt ở những v&ugrave;ng biển c&oacute; độ s&acirc;u tối đa 3.000 m. Mũi khoan của HD-981 c&oacute; thể tiếp cận những t&uacute;i dầu nằm ở độ s&acirc;u 10.000 m. Trước đ&oacute;, c&aacute;c gi&agrave;n khoan của Trung Quốc chỉ c&oacute; thể khai th&aacute;c dầu ở những v&ugrave;ng biển s&acirc;u tối đa 500 m. Ảnh:&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Xinhua</em></td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Dieu_khien_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						Tại buổi lễ đặt t&ecirc;n &ldquo;Offshore Oil Aircraft Carrier&rdquo; (H&agrave;ng kh&ocirc;ng mẫu hạm dầu mỏ) cho gi&agrave;n khoan HD 981, Chủ tịch CNOOC Wang Yilin tuy&ecirc;n bố: &quot;Thiết bị khoan dầu dưới biển s&acirc;u của Trung Quốc đ&atilde; bắt đầu chuyển động v&agrave; n&oacute; rất cần thiết cho việc thực hiện chiến lược khai th&aacute;c dầu ngo&agrave;i khơi của Trung Quốc&rdquo;. Ảnh:&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Xinhua.</em></td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Dieu_khien_2_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						Ph&ograve;ng điều khiển trung t&acirc;m. Ảnh:&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Xinhua.</em></td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Phong_an_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						Căng tin tr&ecirc;n gi&agrave;n khoan.</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Phong_the_thao_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						Ph&ograve;ng tập thể thao d&agrave;nh cho c&aacute;c nh&acirc;n vi&ecirc;n.</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Hanh_lang_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						H&agrave;nh lang khu ph&ograve;ng ngủ.</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Truc_thang_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						Gi&agrave;n khoan Hải Dương 981 c&ograve;n c&oacute; s&acirc;n đỗ trực thăng.</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"Nhập mô tả cho ảnh\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/Sua_chua_1_1.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer;\" /></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						Theo h&atilde;ng tin&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Reuters</em>&nbsp;của Anh, gi&agrave;n khoan nước s&acirc;u trị gi&aacute; một tỷ USD của Trung Quốc từng phải sửa chữa đầu năm 2013 v&igrave; r&ograve; rỉ. CNOOC cho biết: &ldquo;C&aacute;c kỹ thuật vi&ecirc;n ph&aacute;t hiện r&ograve; rỉ trong ph&ograve;ng m&aacute;y bơm của HD-981 trong một đợt kiểm tra định kỳ&rdquo;. C&aacute;c hoạt động sửa chữa k&eacute;o d&agrave;i tới cuối th&aacute;ng 2 c&ugrave;ng năm. Ảnh:&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Xinhua&nbsp;</em></td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<table cellpadding=\"0\" cellspacing=\"0\" class=\"picture\" style=\"box-sizing: border-box; margin: 8px 0px 25px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background-color: rgb(240, 240, 240); border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif; line-height: 14px; color: rgb(51, 51, 51); clear: both; position: relative;\">\r\n			<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pic\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative;\">\r\n						<img alt=\"\" src=\"http://img.v3.news.zdn.vn/w660/Uploaded/sotnzj/2014_05_06/khoan3_copy.jpg\" style=\"box-sizing: border-box; margin: 0px 0px -3px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; max-width: 100%; width: 660px; height: auto; cursor: pointer; opacity: 0.95;\" /><a class=\"btnSlideshow\" href=\"http://news.zing.vn/Can-canh-gian-khoan-HD981-dang-hoat-dong-phi-phap-post414232.html#slideshow\" style=\"box-sizing: border-box; margin: 0px; padding: 0px 10px; vertical-align: baseline; background-image: url(http://stc.v3.news.zing.vn/css/img/expand.png); background-color: rgba(0, 0, 0, 0.6); background-size: 16px; text-decoration: none; color: rgb(255, 255, 255); position: absolute; top: 0px; right: 0px; width: 30px; height: 30px; overflow: hidden; text-indent: -999px; display: block; background-position: 50% 50%; background-repeat: no-repeat no-repeat;\">Ph&oacute;ng to</a></td>\r\n				</tr>\r\n				<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<td class=\"pCaption caption\" style=\"box-sizing: border-box; margin: 0px; padding: 10px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; position: relative; line-height: 1.6;\">\r\n						<p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n							Tạp ch&iacute;&nbsp;<em style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">Mining &amp; Power</em>&nbsp;dẫn lời Simon Powell, một chuy&ecirc;n gia về Dầu mỏ v&agrave; Kh&iacute; đốt ch&acirc;u &Aacute;, nhận định: &ldquo;HD-981 c&oacute; nhiều khả năng t&igrave;m ra kh&iacute; đốt hơn dầu mỏ. Tuy nhi&ecirc;n, nếu n&oacute; ph&aacute;t hiện kh&iacute; tự nhi&ecirc;n ở v&ugrave;ng biển s&acirc;u 1 &ndash; 2 km, c&oacute; thể kh&iacute; sẽ mắc kẹt ph&iacute;a dưới. Như vậy, hoạt động n&agrave;y sẽ kh&ocirc;ng mang lại hiệu quả kinh tế&rdquo;.</p>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n			<table style=\"box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border-style: solid; border-color: rgb(204, 204, 204); outline: 0px; vertical-align: baseline; background-color: transparent; border-collapse: collapse; border-spacing: 0px; width: 660px; font-family: Arial, Helvetica, sans-serif;\">\r\n				<tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n					<tr style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n						<td style=\"box-sizing: border-box; margin: 0px; padding: 4px 10px; border-top-width: 0px; border-left-width: 0px; border-right-style: solid; border-bottom-style: solid; border-right-color: rgb(238, 238, 238); border-bottom-color: rgb(221, 221, 221); outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n							<p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent;\">\r\n								Ng&agrave;y 1/5, Trung Quốc đ&atilde; đưa gi&agrave;n khoan HD-981 v&agrave; khoảng 80 t&agrave;u, kể cả t&agrave;u qu&acirc;n sự v&agrave;o hoạt động ở khu vực thuộc l&ocirc; dầu kh&iacute; 143 thuộc thềm lục địa Việt Nam, đi ngược lại luật ph&aacute;p v&agrave; th&ocirc;ng lệ quốc tế, vi phạm nghi&ecirc;m trọng chủ quyền của Việt Nam đối với Ho&agrave;ng Sa, quyền chủ quyền v&agrave; quyền t&agrave;i ph&aacute;n đối với c&aacute;c v&ugrave;ng đặc quyền kinh tế v&agrave; thềm lục địa của Việt Nam.<br style=\"box-sizing: border-box;\" />\r\n								Khi c&aacute;c t&agrave;u thực thi ph&aacute;p luật của Việt Nam ra kiểm tra, ngăn chặn th&igrave; c&aacute;c t&agrave;u bảo vệ của Trung Quốc được sự yểm trợ của m&aacute;y bay chủ động đ&acirc;m thẳng t&agrave;u Việt Nam, d&ugrave;ng v&ograve;i rồng, s&uacute;ng bắn nước l&agrave;m hư hỏng t&agrave;u v&agrave; g&acirc;y thương t&iacute;ch kiểm ngư vi&ecirc;n.</p>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n		</div>\r\n	</div>\r\n	<div id=\"credit\" style=\"box-sizing: border-box; margin: 8px 0px; padding: 0px; border: 0px; outline: 0px; font-size: 0.9em; vertical-align: baseline; background-color: transparent; font-family: \'Open Sans Condensed\', Arial, Helvetica, sans-serif; clear: both; float: right; line-height: 18px; text-align: center;\">\r\n		&nbsp;</div>\r\n	</article></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>','1');
INSERT INTO `tintuc` (`idTin`,`idLT`,`TieuDe`,`TieuDe_KhongDau`,`TomTat`,`UrlHinh`,`Ngay`,`NoiDung`,`AnHien`) VALUES ('2','3','Câu chuyện cảm động','cau-chuyen-cam-dong','<p>\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 14px; line-height: 20px;\">Ban đ&ecirc;m, lợn đực l&uacute;c n&agrave;o cũng thức để tr&ocirc;ng cho lợn c&aacute;i. N&oacute; sợ, thừa l&uacute;c ch&uacute;ng ngủ say, người ta sẽ đến bắt lợn c&aacute;i đem đi thịt. Ng&agrave;y lại ng&agrave;y, lợn c&aacute;i c&agrave;ng b&eacute;o trắng n&otilde;n n&agrave;, lợn đực c&agrave;ng gầy đi tr&ocirc;ng thấy.</span></p>\r\n','https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-prn2/v/t34.0-12/s403x403/10345064_629868753772900_1909791790_n.jpg?oh=71a0297b7b074541b4936523a4b35c06&oe=536CC554&__gda__=1399674903_87095489b69145610102e116489a275a','2014-05-08 00:00:00','<div class=\"aboveUnitContent\" style=\"margin-top: 15px; margin-bottom: 15px; color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 11px; line-height: 14.079999923706055px;\">\r\n	<div class=\"userContentWrapper\">\r\n		<div class=\"_wk\" style=\"font-size: 14px; line-height: 20px;\">\r\n			<span class=\"userContent\">Ban đ&ecirc;m, lợn đực l&uacute;c n&agrave;o cũng thức để tr&ocirc;ng cho lợn c&aacute;i. N&oacute; sợ, thừa l&uacute;c ch&uacute;ng ngủ say, người ta sẽ đến bắt lợn c&aacute;i đem đi thịt. Ng&agrave;y lại ng&agrave;y, lợn c&aacute;i c&agrave;ng b&eacute;o trắng n&otilde;n n&agrave;, lợn đực c&agrave;ng gầy đi tr&ocirc;ng thấy.<br />\r\n			<br />\r\n			Đến một ng&agrave;y, lợn đực t&igrave;nh cờ ng<span class=\"text_exposed_show\" style=\"display: inline;\">he được &ocirc;ng chủ n&oacute;i chuyện với tay đồ tể. &Ocirc;ng ta muốn thịt lợn c&aacute;i đang b&eacute;o tốt. Lợn đực nghe vậy m&agrave; l&ograve;ng đau khổ kh&ocirc;n c&ugrave;ng. Thế l&agrave; từ l&uacute;c đ&oacute;, t&iacute;nh t&igrave;nh lợn đực thay đổi hẳn. Mỗi lần &ocirc;ng chủ mang đồ ăn đến l&agrave; lợn đực ta gi&agrave;nh ăn bằng sạch, ăn xong n&oacute; lại nằm ườn ra ngủ như chết. N&oacute; c&ograve;n n&oacute;i với lợn c&aacute;i, từ giờ ban đ&ecirc;m phải canh g&aacute;c thay cho n&oacute;. Nếu ph&aacute;t hiện ra kh&ocirc;ng chịu canh th&igrave; n&oacute; sẽ kh&ocirc;ng bao giờ quan t&acirc;m đến lợn c&aacute;i nữa. Thời gian qua đi, lợn c&aacute;i cảm thấy lợn đực c&agrave;ng ng&agrave;y c&agrave;ng kh&ocirc;ng để &yacute; g&igrave; đến m&igrave;nh nữa. Lợn c&aacute;i buồn b&atilde;, thất vọng v&ocirc; c&ugrave;ng. C&ograve;n lợn đực h&agrave;ng ng&agrave;y vẫn v&ocirc; tư, vui vẻ như kh&ocirc;ng c&oacute; chuyện g&igrave; xảy ra.<br />\r\n			<br />\r\n			Ngoảnh đi ngoảnh lại một th&aacute;ng qua đi, &ocirc;ng chủ dẫn tay đồ tể đến chuồng lợn. &Ocirc;ng ta thấy lợn c&aacute;i trước đ&acirc;y đẫy đ&agrave;, n&otilde;n nường l&agrave; thế giờ chẳng c&ograve;n lại được bao nhi&ecirc;u thịt. C&ograve;n lợn đực lại trở n&ecirc;n b&eacute;o trắng hẳn ra. L&uacute;c n&agrave;y, lợn đực ta liền chạy thục mạng xung quanh chuồng, n&oacute; muốn thu h&uacute;t sự ch&uacute; &yacute; của &ocirc;ng chủ, chứng tỏ n&oacute; l&agrave; con lợn b&eacute;o tốt, khỏe mạnh. Cuối c&ugrave;ng th&igrave; tay đồ tể cũng bắt lợn đực đi. Khoảnh khắc bị l&ocirc;i ra khỏi chuồng, lợn đực vẫn cười v&agrave; n&oacute;i với lại với lợn c&aacute;i: &quot;Sau n&agrave;y em nhớ đừng ăn nhiều nh&eacute;!&quot;<br />\r\n			<br />\r\n			Lợn c&aacute;i đau x&oacute;t c&ugrave;ng cực, định x&ocirc;ng ra theo chồng, nhưng cửa chuồng đ&atilde; đ&oacute;ng sầm trước mặt n&oacute;. Qua h&agrave;ng r&agrave;o tre lợn c&aacute;i vẫn nh&igrave;n thấy &aacute;nh mắt chớp chớp của lợn đực. Tối h&ocirc;m đ&oacute;, lợn c&aacute;i nh&igrave;n nh&agrave; chủ vui vẻ, qu&acirc;y quần b&ecirc;n nhau ăn thịt lợn, n&oacute; buồn b&atilde; thả m&igrave;nh nằm xuống nơi trước đ&acirc;y lợn đực vẫn nằm. Đột nhi&ecirc;n n&oacute; ph&aacute;t hiện thấy tr&ecirc;n tường c&oacute; d&ograve;ng chữ: &quot;Nếu t&igrave;nh y&ecirc;u kh&ocirc;ng thể diễn đạt được bằng lời, anh nguyện d&ugrave;ng sinh mạng để chứng minh.&quot; Lợn c&aacute;i đọc xong d&ograve;ng chữ m&agrave; l&ograve;ng đau quặn thắt...</span></span><span class=\"userContentSecondary fcg\" style=\"color: gray;\">&nbsp;&mdash; với&nbsp;<a data-ft=\"{\" data-hovercard=\"/ajax/hovercard/user.php?id=100005484283170&amp;extragetparams=%7B%22directed_target_id%22%3Anull%7D\" href=\"https://www.facebook.com/phamvantuyen.phamvantuyen.5\" style=\"color: rgb(59, 89, 152); cursor: pointer; text-decoration: none;\">Phamvantuyen Pham van Tuyen</a>&nbsp;v&agrave;&nbsp;<a ajaxify=\"/ajax/browser/dialog/participants/?q=AeKbkFwWXpbeDiyvFexJxYHTVR5Fa-uSoXQF_F619Qv5TxevMgRPM91tsXYyyZsz5xK6BJ98feESwDKViE_wrnAamo2riujbtv0wf-hAbPXXZa_HxElOa7zdDNTOMqYVyOkiDcuhG4xaE5xt6tD9dPvz9dh5q_6QGwIZX0rWDXf8CBiq1LjHN02_uTGJF6cmzmf2EF0Y5qBaZsOceYKVVgtpO9jI433SvFtPBDJ8UBJtgRzsP_Uz9ClJEkFNmq2a6ydqQu8M4gpnWj93yjfISQAKlKzLXDM_9gEYX-3EhuutvqPF1EFApgIviCiIo65bXvjEDBuyn-6Kwt640-AMif8J2pFuQqgC8n-Bbr7I_KeSuA\" aria-label=\"Thúy Vân\r\nMinh Hương Phung\" data-ft=\"{\" data-hover=\"tooltip\" data-tooltip-position=\"below\" href=\"https://www.facebook.com/browse/participants/?q=AeJmW6WUSQnHyjfa5enPmMU06TfFDsY9RD0teSEGFmY-f0gOtkQM0v2K-gZv3qCW_SckWK2DYtr7ZruWxfdQJL6AMPeqKc1h00jAOlpvjzjrnbmC2vZJtvHwPcmDieNltdLZ0meW7bLNy2Oy-HEuDJ1C53zXtlNixJ9vb9KpqWH8LklOetBum1Nnn7XdBcP0tvoSZG3VpUpfIiR-EoD8s8wsJQOAduPrCCRuL-Faa9M5gZElFklOh_1O9V6fuASZA5AMLJWgaBBCR1v1dVGAsJZNOTqBXnqMGpF0TZWY-Xex1gaWPGGPvmQz_Yyi0sKDnYl6K3b56AULY-1R3B_IT7hk\" id=\"js_12\" rel=\"dialog\" role=\"button\" style=\"color: rgb(59, 89, 152); cursor: pointer; text-decoration: none;\">2 người kh&aacute;c</a>.</span></div>\r\n	</div>\r\n</div>\r\n<div class=\"photoUnit clearfix\" style=\"zoom: 1; margin: 0px -15px; position: relative; color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 11px; line-height: 14.079999923706055px;\">\r\n	<div class=\"letterboxedImage photoWrap verticallyCentered\" style=\"position: relative; margin-left: 3px; background-color: rgb(242, 242, 242); height: 381px; width: 403px; background-position: initial initial; background-repeat: initial initial;\">\r\n		<div class=\"uiScaledImageContainer scaledImage\" style=\"position: absolute; overflow: hidden; top: 190.5px; margin: -190px auto 0px; width: 403px; height: 381px; text-align: center;\">\r\n			<a ajaxify=\"https://www.facebook.com/photo.php?fbid=10154118115925646&amp;set=a.10152974212050646.1073741837.10150142097160646&amp;type=1&amp;relevant_count=1&amp;src=https%3A%2F%2Ffbcdn-sphotos-h-a.akamaihd.net%2Fhphotos-ak-prn2%2Fv%2Ft34.0-12%2F10345064_629868753772900_1909791790_n.jpg%3Foh%3D10fdec34fa6fef904ced7bab405c7c9e%26oe%3D536D04F7%26__gda__%3D1399642226_1b71487f13de9e1034e2f50290c0a1fc&amp;size=450%2C426&amp;source=9&amp;player_origin=pages\" class=\"photo photoWidth1\" data-ft=\"{\" data-gt=\"{\" href=\"https://www.facebook.com/photo.php?fbid=10154118115925646&amp;set=a.10152974212050646.1073741837.10150142097160646&amp;type=1&amp;relevant_count=1\" rel=\"theater\" style=\"color: rgb(59, 89, 152); cursor: pointer; text-decoration: none; float: left;\"><img .=\"\" :=\"\" a=\"\" alt=\"Hình ảnh: Ban đêm, lợn đực lúc nào cũng thức để trông cho lợn cái. Nó sợ, thừa lúc chúng ngủ say, người ta sẽ đến bắt lợn cái đem đi thịt. Ngày lại ngày, lợn cái càng béo trắng nõn nà, lợn đực càng gầy đi trông thấy.\r\n\r\nĐến một ngày, lợn đực tình cờ nghe được ông chủ nói chuyện với tay đồ tể. Ông ta muốn thịt lợn cái đang béo tốt. Lợn đực nghe vậy mà lòng đau khổ khôn cùng. Thế là từ lúc đó, tính tình lợn đực thay đổi hẳn. Mỗi lần ông chủ mang đồ ăn đến là lợn đực ta giành ăn bằng sạch, ăn xong nó lại nằm ườn ra ngủ như chết. Nó còn nói với lợn cái, từ giờ ban đêm phải canh gác thay cho nó. Nếu phát hiện ra không chịu canh thì nó sẽ không bao giờ quan tâm đến lợn cái nữa. Thời gian qua đi, lợn cái cảm thấy lợn đực càng ngày càng không để ý gì đến mình nữa. Lợn cái buồn bã, thất vọng vô cùng. Còn lợn đực hàng ngày vẫn vô tư, vui vẻ như không có chuyện gì xảy ra.\r\n\r\nNgoảnh đi ngoảnh lại một tháng qua đi, ông chủ dẫn tay đồ tể đến chuồng lợn. Ông ta thấy lợn cái trước đây đẫy đà, nõn nường là thế giờ chẳng còn lại được bao nhiêu thịt. Còn lợn đực lại trở nên béo trắng hẳn ra. Lúc này, lợn đực ta liền chạy thục mạng xung quanh chuồng, nó muốn thu hút sự chú ý của ông chủ, chứng tỏ nó là con lợn béo tốt, khỏe mạnh. Cuối cùng thì tay đồ tể cũng bắt lợn đực đi. Khoảnh khắc bị lôi ra khỏi chuồng, lợn đực vẫn cười và nói với lại với lợn cái: \" anh=\"\" au=\"\" c=\"\" c.=\"\" class=\"scaledImageFitWidth img\" em=\"\" height=\"381\" i=\"\" m=\"\" m.=\"\" n=\"\" ng=\"\" nh=\"\" nhau=\"\" o=\"\" p=\"\" qua=\"\" ra=\"\" sau=\"\" sinh=\"\" src=\"https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-prn2/v/t34.0-12/s403x403/10345064_629868753772900_1909791790_n.jpg?oh=71a0297b7b074541b4936523a4b35c06&amp;oe=536CC554&amp;__gda__=1399674903_87095489b69145610102e116489a275a\" style=\"border: 0px; height: auto; min-height: 100%; position: relative; width: 403px;\" t=\"\" theo=\"\" tre=\"\" u=\"\" vui=\"\" width=\"403\" xong=\"\" y=\"\" /></a></div>\r\n	</div>\r\n</div>\r\n','1');
/*!40000 ALTER TABLE `tintuc` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `idUser` int(20) NOT NULL AUTO_INCREMENT,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`idUser`,`email`,`password`) VALUES ('1','admin','e5c89ef4446aca1e22e3391b97353cc9');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

