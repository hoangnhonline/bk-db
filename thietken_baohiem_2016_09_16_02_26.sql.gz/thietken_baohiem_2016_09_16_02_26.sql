-- Status:7:51:MP_0:thietken_baohiem:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|bdl_phiphauthuat|5|16384||InnoDB
-- TABLE|bdl_place|4|16384||InnoDB
-- TABLE|bdl_pttm|4|16384||InnoDB
-- TABLE|contract|5|16384||InnoDB
-- TABLE|customers|17|16384||InnoDB
-- TABLE|data|13|16384||InnoDB
-- TABLE|users|3|16384||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:26

--
-- Create Table `bdl_phiphauthuat`
--

DROP TABLE IF EXISTS `bdl_phiphauthuat`;
CREATE TABLE `bdl_phiphauthuat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Data for Table `bdl_phiphauthuat`
--

/*!40000 ALTER TABLE `bdl_phiphauthuat` DISABLE KEYS */;
INSERT INTO `bdl_phiphauthuat` (`id`,`value`) VALUES ('1','CĂNG DA MẶT');
INSERT INTO `bdl_phiphauthuat` (`id`,`value`) VALUES ('2','TẠO DÁNG MŨI');
INSERT INTO `bdl_phiphauthuat` (`id`,`value`) VALUES ('3','THẨM MỸ MẮT');
INSERT INTO `bdl_phiphauthuat` (`id`,`value`) VALUES ('4','TẠO DÁNG MẶT');
INSERT INTO `bdl_phiphauthuat` (`id`,`value`) VALUES ('5','TRẺ HÓA MÔI');
/*!40000 ALTER TABLE `bdl_phiphauthuat` ENABLE KEYS */;


--
-- Create Table `bdl_place`
--

DROP TABLE IF EXISTS `bdl_place`;
CREATE TABLE `bdl_place` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `bdl_place`
--

/*!40000 ALTER TABLE `bdl_place` DISABLE KEYS */;
INSERT INTO `bdl_place` (`id`,`value`) VALUES ('1','Thẩm mỹ Pamas Hồ Chí Minh');
INSERT INTO `bdl_place` (`id`,`value`) VALUES ('2','Thẩm mỹ Pamas Vũng Tàu');
INSERT INTO `bdl_place` (`id`,`value`) VALUES ('3','Thẩm mỹ Pamas Đà Nẵng');
INSERT INTO `bdl_place` (`id`,`value`) VALUES ('4','Thẩm mỹ Pamas Hà Nội');
/*!40000 ALTER TABLE `bdl_place` ENABLE KEYS */;


--
-- Create Table `bdl_pttm`
--

DROP TABLE IF EXISTS `bdl_pttm`;
CREATE TABLE `bdl_pttm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Data for Table `bdl_pttm`
--

/*!40000 ALTER TABLE `bdl_pttm` DISABLE KEYS */;
INSERT INTO `bdl_pttm` (`id`,`value`) VALUES ('1','MŨI');
INSERT INTO `bdl_pttm` (`id`,`value`) VALUES ('2','MẮT');
INSERT INTO `bdl_pttm` (`id`,`value`) VALUES ('3','KHUÔN MẶT');
INSERT INTO `bdl_pttm` (`id`,`value`) VALUES ('4','NÂNG NGỰC');
/*!40000 ALTER TABLE `bdl_pttm` ENABLE KEYS */;


--
-- Create Table `contract`
--

DROP TABLE IF EXISTS `contract`;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `date_from` int(11) NOT NULL,
  `date_to` int(11) NOT NULL,
  `no_date` tinyint(4) NOT NULL,
  `persons` tinyint(4) NOT NULL,
  `type` varchar(20) NOT NULL,
  `plan_id` varchar(20) NOT NULL,
  `incidental_plan` tinyint(4) NOT NULL,
  `medical_plan` varchar(2) NOT NULL,
  `area` varchar(2) NOT NULL,
  `personal_accident` tinyint(4) NOT NULL,
  `total_price` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `holder_name` varchar(255) NOT NULL,
  `holder_address` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `inv_company` varchar(255) DEFAULT NULL,
  `inv_address` varchar(255) DEFAULT NULL,
  `inv_tax` varchar(100) DEFAULT NULL,
  `residence_country` varchar(100) NOT NULL,
  `departure_country` varchar(100) NOT NULL,
  `method_id` tinyint(4) NOT NULL,
  `internal_cert_number` varchar(50) DEFAULT NULL,
  `pdf_file1` varchar(500) DEFAULT NULL,
  `pdf_file2` varchar(500) DEFAULT NULL,
  `notes` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1 : chua duyet, 2 : da duyet , 3 : da xuat file',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Data for Table `contract`
--

/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` (`id`,`customer_id`,`date_from`,`date_to`,`no_date`,`persons`,`type`,`plan_id`,`incidental_plan`,`medical_plan`,`area`,`personal_accident`,`total_price`,`unit_price`,`holder_name`,`holder_address`,`phone`,`inv_company`,`inv_address`,`inv_tax`,`residence_country`,`departure_country`,`method_id`,`internal_cert_number`,`pdf_file1`,`pdf_file2`,`notes`,`status`,`created_at`,`updated_at`) VALUES ('1','5','1456790400','1456963200','3','2','Individual','BW2BN','1','B','W','2','688','344','Nguyen Van A','1235248645','0917492306','sf CTY A','123 dia chia CTY','6067587325','','','2','GL/14467','http://www.bluecross.com.vn/webservice/Globalink/GL1.pdf','','abc','3','1456653450','1456653495');
INSERT INTO `contract` (`id`,`customer_id`,`date_from`,`date_to`,`no_date`,`persons`,`type`,`plan_id`,`incidental_plan`,`medical_plan`,`area`,`personal_accident`,`total_price`,`unit_price`,`holder_name`,`holder_address`,`phone`,`inv_company`,`inv_address`,`inv_tax`,`residence_country`,`departure_country`,`method_id`,`internal_cert_number`,`pdf_file1`,`pdf_file2`,`notes`,`status`,`created_at`,`updated_at`) VALUES ('2','6','1461974400','1462320000','5','3','Family','AW4AN','1','A','W','4','1300','650','','','',NULL,NULL,NULL,'','','2',NULL,NULL,NULL,'','1','1460605855','1460605855');
INSERT INTO `contract` (`id`,`customer_id`,`date_from`,`date_to`,`no_date`,`persons`,`type`,`plan_id`,`incidental_plan`,`medical_plan`,`area`,`personal_accident`,`total_price`,`unit_price`,`holder_name`,`holder_address`,`phone`,`inv_company`,`inv_address`,`inv_tax`,`residence_country`,`departure_country`,`method_id`,`internal_cert_number`,`pdf_file1`,`pdf_file2`,`notes`,`status`,`created_at`,`updated_at`) VALUES ('3','6','1460592000','1476057600','127','1','Individual','CA1CN','1','C','A','1','3572','3572','','','',NULL,NULL,NULL,'','','3',NULL,NULL,NULL,'testing','1','1460607847','1460607847');
INSERT INTO `contract` (`id`,`customer_id`,`date_from`,`date_to`,`no_date`,`persons`,`type`,`plan_id`,`incidental_plan`,`medical_plan`,`area`,`personal_accident`,`total_price`,`unit_price`,`holder_name`,`holder_address`,`phone`,`inv_company`,`inv_address`,`inv_tax`,`residence_country`,`departure_country`,`method_id`,`internal_cert_number`,`pdf_file1`,`pdf_file2`,`notes`,`status`,`created_at`,`updated_at`) VALUES ('4','6','1473897600','1479513600','66','1','Individual','BA1BN','1','B','A','1','1392','1392','','','',NULL,NULL,NULL,'','','2',NULL,NULL,NULL,'','1','1460608182','1460608182');
INSERT INTO `contract` (`id`,`customer_id`,`date_from`,`date_to`,`no_date`,`persons`,`type`,`plan_id`,`incidental_plan`,`medical_plan`,`area`,`personal_accident`,`total_price`,`unit_price`,`holder_name`,`holder_address`,`phone`,`inv_company`,`inv_address`,`inv_tax`,`residence_country`,`departure_country`,`method_id`,`internal_cert_number`,`pdf_file1`,`pdf_file2`,`notes`,`status`,`created_at`,`updated_at`) VALUES ('5','6','1462060800','1464652800','31','10','Individual','CE1NN','0','C','E','1','2520','252','','','',NULL,NULL,NULL,'','','2',NULL,NULL,NULL,'','1','1460608476','1460608476');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;


--
-- Create Table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `birthday` int(11) NOT NULL,
  `member_type` varchar(20) DEFAULT NULL,
  `passport` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Data for Table `customers`
--

/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('3','1','Nguyen Van ','A','1','411350400','MEMBER_TYPE_A','8765432');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('4','1','Le Van ','B','1','885340800','MEMBER_TYPE_A','234566');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('5','2','Tran ','A','2','315532800','MBR_TYPE_A','B12345678');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('6','2','Tran ','B','1','315619200','MBR_TYPE_A','B12345679');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('7','2','Tran ','C','2','315792000','MBR_TYPE_A','B12345677');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('8','3','Tran','A','1','315532800','MEMBER_TYPE_A','N98745612');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('9','4','Tran','Tu','2','316742400','MEMBER_TYPE_A','B12345678');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('10','5','f','rf','1','-1477094400','MEMBER_TYPE_A','B12345678');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('11','5','d','d','1','-1577145600','MEMBER_TYPE_A','B12345678');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('12','5','d','e','1','-1544832000','MEMBER_TYPE_A','g');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('13','5','sw','s','2','-1544832000','MEMBER_TYPE_A','d');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('14','5','sdfsd','bsd','1','-1544832000','MEMBER_TYPE_A','dv');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('15','5','dsv','sdv','2','1458432000','MEMBER_TYPE_A','sdv');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('16','5','sdv','cxv','1','1458432000','MEMBER_TYPE_A','dg');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('17','5','df','sdfd','1','1458432000','MEMBER_TYPE_A','sdg');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('18','5','DF','DF','2','1458432000','MEMBER_TYPE_A','df');
INSERT INTO `customers` (`id`,`contract_id`,`first_name`,`last_name`,`gender`,`birthday`,`member_type`,`passport`) VALUES ('19','5','sdf','DF','1','1458432000','MEMBER_TYPE_A','df');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;


--
-- Create Table `data`
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bdl_fullname` varchar(255) CHARACTER SET utf8 NOT NULL,
  `bdl_phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `bdl_phiphauthuat` varchar(100) CHARACTER SET utf8 NOT NULL,
  `bdl_pttm` varchar(100) CHARACTER SET utf8 NOT NULL,
  `bdl_place` varchar(100) CHARACTER SET utf8 NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Data for Table `data`
--

/*!40000 ALTER TABLE `data` DISABLE KEYS */;
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('2','nguyenhoangphong','01635545058','','','','1463208184','1463208184','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('3','Nguyen Thi My Dung','0917811478','','','','1463218869','1463218869','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('5','vanlam055','01668586350lam','','','1,2,3,4','1463252446','1463252446','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('9','Hoàng thị minh hương','0914561010','','','','1463280484','1463280484','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('11','Thu','0995109108','','','4','1463300965','1463300965','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('12','Hương Nguyễn','0986557303','1,3','1,2','1','1463328756','1463328756','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('13','tăng khánh vân','0947755331','','','','1463389826','1463389826','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('14','phạm  thị phương','01682283236','','','','1463406680','1463406680','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('15','Nguyễn Thị Lệ Hằng','0909779768','1','','1','1463407769','1463407769','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('16','Đỗ Nhung','0949285845','','','','1463456566','1463456566','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('17','Đỗ Nhung','0949285845','','','','1463456841','1463456841','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('18','Hoàng Anh','01637616993','','','4','1463465246','1463465246','1');
INSERT INTO `data` (`id`,`bdl_fullname`,`bdl_phone`,`bdl_phiphauthuat`,`bdl_pttm`,`bdl_place`,`created_at`,`updated_at`,`status`) VALUES ('19','U U','2*--','','','','1463637674','1463637674','1');
/*!40000 ALTER TABLE `data` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '2',
  `is_vl` tinyint(1) NOT NULL DEFAULT '0',
  `phone` varchar(20) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `birthday` int(11) DEFAULT NULL,
  `cmnd` varchar(20) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  `tax_no` varchar(20) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`,`email`,`password`,`role`,`is_vl`,`phone`,`fullname`,`birthday`,`cmnd`,`company_name`,`company_address`,`tax_no`,`created_at`,`updated_at`,`last_login`,`address`,`status`) VALUES ('3','admin','e9ea90857363708afc42938a00719e76','1','0','0917492306','Admin',NULL,NULL,NULL,NULL,NULL,'0','0','0','','1');
INSERT INTO `users` (`id`,`email`,`password`,`role`,`is_vl`,`phone`,`fullname`,`birthday`,`cmnd`,`company_name`,`company_address`,`tax_no`,`created_at`,`updated_at`,`last_login`,`address`,`status`) VALUES ('5','hoangnh@gmail.com','e10adc3949ba59abbe56e057f20f883e','2','0','0917492306','Nguyen Van A','601171200','987654321','sf CTY A','123 dia chia CTY','6067587325','1456653447','1456653447','1456653447','1232 Ton Dan Quan 4','1');
INSERT INTO `users` (`id`,`email`,`password`,`role`,`is_vl`,`phone`,`fullname`,`birthday`,`cmnd`,`company_name`,`company_address`,`tax_no`,`created_at`,`updated_at`,`last_login`,`address`,`status`) VALUES ('6','tutran@bluecross.com.vn','','2','1','01234567890','Tran Tu','315532800','01234567890','BLUE CROSS VIETNAM','BLUE CROSS VIETNAM','01234567890','1460605795','1460605795','1460605795','Tran Tu','1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

