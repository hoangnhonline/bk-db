-- Status:24:375:MP_0:thietken_quangcaoopen:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|article|2|37504|2016-06-22 22:56:24|MyISAM
-- TABLE|blocks|4|3896|2016-09-16 09:29:46|MyISAM
-- TABLE|category|42|6760|2016-09-16 09:29:46|MyISAM
-- TABLE|donhang|9|2444|2016-06-22 22:56:24|MyISAM
-- TABLE|donhangct|9|2237|2016-06-22 22:56:24|MyISAM
-- TABLE|hinh_quangcao|0|16384||InnoDB
-- TABLE|hinh_thuc_thanh_toan|2|2188|2016-06-22 22:56:24|MyISAM
-- TABLE|hinhanh_home|5|2388|2016-09-16 09:29:46|MyISAM
-- TABLE|khachhang|22|5864|2016-06-22 22:56:24|MyISAM
-- TABLE|khachhang_tienich|153|16384||InnoDB
-- TABLE|khoanggia|4|2100|2016-06-22 22:56:24|MyISAM
-- TABLE|loai_article|2|2160|2016-06-22 22:56:24|MyISAM
-- TABLE|loai_hinh|2|16384||InnoDB
-- TABLE|loaiuser|3|2112|2016-06-22 22:56:24|MyISAM
-- TABLE|menu|4|2420|2016-06-22 22:56:24|MyISAM
-- TABLE|product|15|16504|2016-09-16 09:29:46|MyISAM
-- TABLE|quocgia|2|2116|2016-06-22 22:56:24|MyISAM
-- TABLE|tag|0|16384||InnoDB
-- TABLE|theloai|3|2180|2016-06-30 21:33:04|MyISAM
-- TABLE|thongso_sanpham|0|1024|2016-06-22 22:56:24|MyISAM
-- TABLE|thuonghieu|35|4068|2016-06-22 22:56:24|MyISAM
-- TABLE|tien_ich|50|7776|2016-06-22 22:56:24|MyISAM
-- TABLE|tinhtrang|6|2316|2016-06-22 22:56:24|MyISAM
-- TABLE|user|1|2144|2016-06-22 22:56:24|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:29

--
-- Create Table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `idLoai` int(11) NOT NULL,
  `title_cn` varchar(255) NOT NULL,
  `title_vi` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_alias` varchar(255) NOT NULL,
  `mota_cn` varchar(255) NOT NULL,
  `mota_vi` varchar(255) NOT NULL,
  `mota_en` varchar(255) NOT NULL,
  `content_cn` text NOT NULL,
  `content_vi` text NOT NULL,
  `content_en` text NOT NULL,
  `HinhDaiDien` text NOT NULL,
  `NgayDang` text NOT NULL,
  `SoLanXem` int(11) NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `article`
--

/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` (`article_id`,`idLoai`,`title_cn`,`title_vi`,`title_en`,`title_alias`,`mota_cn`,`mota_vi`,`mota_en`,`content_cn`,`content_vi`,`content_en`,`HinhDaiDien`,`NgayDang`,`SoLanXem`) VALUES ('1','2','','33 Thiết kế menu để bàn cho khách sạn','33 Thiết kế menu để bàn cho khách sạn','33-thiet-ke-menu-de-ban-cho-khach-san','','Thiết kế menu không chỉ dùng để liệt kê danh sách các món ăn, thức uống và giá cả tương ứng mà nó còn là công cụ tiếp thị quan trọng và riêng biệt của mỗi nhà hàng, quán ăn, thức ăn nhanh, quán bar, club….','Thiết kế menu không chỉ dùng để liệt kê danh sách các món ăn, thức uống và giá cả tương ứng mà nó còn là công cụ tiếp thị quan trọng và riêng biệt của mỗi nhà hàng, quán ăn, thức ăn nhanh, quán bar, club….','','<p>Thiết kế menu kh&ocirc;ng chỉ d&ugrave;ng để liệt k&ecirc; danh s&aacute;ch c&aacute;c m&oacute;n ăn, thức uống v&agrave; gi&aacute; cả tương ứng m&agrave; n&oacute; c&ograve;n l&agrave; c&ocirc;ng cụ tiếp thị quan trọng v&agrave; ri&ecirc;ng biệt của mỗi nh&agrave; h&agrave;ng, qu&aacute;n ăn, thức ăn nhanh, qu&aacute;n bar, club&hellip;.</p>\r\n\r\n<p>Tr&ecirc;n thực tế, menu ch&iacute;nh l&agrave; bảng quảng c&aacute;o được in ra để kh&aacute;ch h&agrave;ng đọc v&agrave; chọn m&oacute;n. V&igrave; thế, khi thiết kế menu, người ta thường nghĩ n&oacute; giống như l&agrave; namecard ri&ecirc;ng của mỗi nh&agrave; h&agrave;ng vậy. Menu sẽ gi&uacute;p bạn giới thiệu nh&agrave; h&agrave;ng đến kh&aacute;ch h&agrave;ng, kh&ocirc;ng chỉ thực phẩm v&agrave; đồ uống bạn cung cấp, m&agrave; c&ograve;n l&agrave; những trải nghiệm ăn uống m&agrave; kh&aacute;ch h&agrave;ng v&ocirc; c&ugrave;ng mong đợi. Giống như c&aacute;c thương hiệu kh&aacute;c, menu cũng n&ecirc;n được thiết kế đồ họa với c&aacute;c tone m&agrave;u sắc m&agrave; kh&aacute;ch h&agrave;ng c&oacute; thể nh&igrave;n thấy trong nh&agrave; h&agrave;ng của bạn. N&oacute;i c&aacute;ch kh&aacute;c, thiết kế menu cũng cần c&oacute; chủ đề, h&igrave;nh ảnh trang tr&iacute;, chất lượng thực phẩm v&agrave; gi&aacute; cả tương ứng.</p>\r\n\r\n<p><a href=\"http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang.jpg\"><img alt=\"thiet-ke-menu-nha-hang\" class=\"alignnone size-full wp-image-2539\" height=\"504\" sizes=\"(max-width: 755px) 100vw, 755px\" src=\"http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang.jpg\" srcset=\"http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-300x200.jpg 300w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-636x425.jpg 636w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-320x214.jpg 320w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-239x160.jpg 239w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang.jpg 755w\" width=\"755\" /></a></p>\r\n\r\n<p>Để minh chứng cho những g&igrave; ch&uacute;ng t&ocirc;i n&oacute;i ở tr&ecirc;n, <em><strong>D2 design &amp; print</strong></em> sẽ mang đến cho bạn một loạt những thiết kế menu s&aacute;ng tạo v&agrave; hiệu quả, chủ yếu l&agrave; từ portfolio của c&aacute;c nh&agrave; thiết kế th&ocirc;ng qua trang Behance v&agrave; Underconsideration.</p>\r\n','<p>Thiết kế menu kh&ocirc;ng chỉ d&ugrave;ng để liệt k&ecirc; danh s&aacute;ch c&aacute;c m&oacute;n ăn, thức uống v&agrave; gi&aacute; cả tương ứng m&agrave; n&oacute; c&ograve;n l&agrave; c&ocirc;ng cụ tiếp thị quan trọng v&agrave; ri&ecirc;ng biệt của mỗi nh&agrave; h&agrave;ng, qu&aacute;n ăn, thức ăn nhanh, qu&aacute;n bar, club&hellip;.</p>\r\n\r\n<p>Tr&ecirc;n thực tế, menu ch&iacute;nh l&agrave; bảng quảng c&aacute;o được in ra để kh&aacute;ch h&agrave;ng đọc v&agrave; chọn m&oacute;n. V&igrave; thế, khi thiết kế menu, người ta thường nghĩ n&oacute; giống như l&agrave; namecard ri&ecirc;ng của mỗi nh&agrave; h&agrave;ng vậy. Menu sẽ gi&uacute;p bạn giới thiệu nh&agrave; h&agrave;ng đến kh&aacute;ch h&agrave;ng, kh&ocirc;ng chỉ thực phẩm v&agrave; đồ uống bạn cung cấp, m&agrave; c&ograve;n l&agrave; những trải nghiệm ăn uống m&agrave; kh&aacute;ch h&agrave;ng v&ocirc; c&ugrave;ng mong đợi. Giống như c&aacute;c thương hiệu kh&aacute;c, menu cũng n&ecirc;n được thiết kế đồ họa với c&aacute;c tone m&agrave;u sắc m&agrave; kh&aacute;ch h&agrave;ng c&oacute; thể nh&igrave;n thấy trong nh&agrave; h&agrave;ng của bạn. N&oacute;i c&aacute;ch kh&aacute;c, thiết kế menu cũng cần c&oacute; chủ đề, h&igrave;nh ảnh trang tr&iacute;, chất lượng thực phẩm v&agrave; gi&aacute; cả tương ứng.</p>\r\n\r\n<p><a href=\"http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang.jpg\"><img alt=\"thiet-ke-menu-nha-hang\" class=\"alignnone size-full wp-image-2539\" height=\"504\" sizes=\"(max-width: 755px) 100vw, 755px\" src=\"http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang.jpg\" srcset=\"http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-300x200.jpg 300w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-636x425.jpg 636w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-320x214.jpg 320w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang-239x160.jpg 239w, http://d2design.vn/wp-content/uploads/2015/06/thiet-ke-menu-nha-hang.jpg 755w\" width=\"755\" /></a></p>\r\n\r\n<p>Để minh chứng cho những g&igrave; ch&uacute;ng t&ocirc;i n&oacute;i ở tr&ecirc;n, <em><strong>D2 design &amp; print</strong></em> sẽ mang đến cho bạn một loạt những thiết kế menu s&aacute;ng tạo v&agrave; hiệu quả, chủ yếu l&agrave; từ portfolio của c&aacute;c nh&agrave; thiết kế th&ocirc;ng qua trang Behance v&agrave; Underconsideration.</p>\r\n','upload/images/news/thiet-ke-menu-nha-hang-320x180.jpg','1466332326','0');
INSERT INTO `article` (`article_id`,`idLoai`,`title_cn`,`title_vi`,`title_en`,`title_alias`,`mota_cn`,`mota_vi`,`mota_en`,`content_cn`,`content_vi`,`content_en`,`HinhDaiDien`,`NgayDang`,`SoLanXem`) VALUES ('2','2','','Chọn màu sắc trong thiết kế logo','Chọn màu sắc trong thiết kế logo','chon-mau-sac-trong-thiet-ke-logo','','“Hiểu được tính chất tâm lý của màu sắc rất quan trọng để thiết kế một logo hiệu quả” – Martin Christie, giám đốc sáng tạo tại công ty thiết kế đồ họa Logo Design London. Với nhiều năm kinh nghiệm trong việc xây dựng thương hiệu và thiết kế, Martin thườn','“Hiểu được tính chất tâm lý của màu sắc rất quan trọng để thiết kế một logo hiệu quả” – Martin Christie, giám đốc sáng tạo tại công ty thiết kế đồ họa Logo Design London. Với nhiều năm kinh nghiệm trong việc xây dựng thương hiệu và thiết kế, Martin thườn','','<p><strong>&ldquo;Hiểu được t&iacute;nh chất t&acirc;m l&yacute; của m&agrave;u sắc r&acirc;́t quan trọng để thiết kế một logo hiệu quả&rdquo;</strong> &ndash; Martin Christie, gi&aacute;m đốc s&aacute;ng tạo tại c&ocirc;ng ty thiết kế đồ họa Logo Design London. Với nhiều năm kinh nghiệm trong việc x&acirc;y dựng thương hiệu v&agrave; thiết kế, Martin thường xuy&ecirc;n chia sẻ kinh nghiệm của m&igrave;nh với kh&aacute;ch h&agrave;ng v&agrave; những nhà thiết kế đồ họa..</p>\r\n\r\n<p>T&acirc;m tr&iacute; con người phản ứng r&acirc;́t nhanh với c&aacute;c k&iacute;ch th&iacute;ch thị gi&aacute;c, v&agrave; m&agrave;u sắc l&agrave; một trong những yếu tố quan trọng đ&ecirc;̉ xác định điều đ&oacute;. Cả v&ecirc;̀ mức độ &yacute; thức v&agrave; tiềm thức, m&agrave;u sắc chuyển tải &yacute; nghĩa kh&ocirc;ng chỉ trong thế giới tự nhi&ecirc;n m&agrave; c&ograve;n trong những thứ nh&acirc;n tạo của nền văn h&oacute;a của ch&uacute;ng ta. Thiết kế đồ họa cần phải khai th&aacute;c sức mạnh của t&acirc;m l&yacute; m&agrave;u sắc để mang lại sự cộng hưởng với thiết kế của họ- v&agrave; kh&ocirc;ng c&oacute; lĩnh vực n&agrave;o quan trọng hơn so với sự c&ocirc;̣ng hưởng đó trong thiết kế logo.</p>\r\n\r\n<p>Việc sử dụng m&agrave;u sắc c&oacute; thể mang lại nhiều lớp t&acirc;̀ng ý nghĩa, từ phản ứng nguy&ecirc;n thủy dựa tr&ecirc;n h&agrave;ng triệu năm của bản năng tiến h&oacute;a đ&ecirc;́n qu&acirc;̀n th&ecirc;̉ phức tạp ch&uacute;ng t&ocirc;i thực hiện dựa tr&ecirc;n c&aacute;c giả định học được. C&aacute;c c&ocirc;ng ty c&oacute; thể sử dụng những phản ứng đó để nhấn mạnh và làm n&ocirc;̉i b&acirc;̣t th&ocirc;ng điệp trong thương hiệu của họ. V&agrave; sự th&agrave;nh c&ocirc;ng của bạn làm cho bạn thành một nh&agrave; thiết kế logo n&ocirc;̉i ti&ecirc;́ng nếu bạn c&oacute; một sự hiểu biết thấu đ&aacute;o về t&acirc;m l&yacute; m&agrave;u sắc.</p>\r\n\r\n<h3><strong>SỰ KHÁC NHAU V&Ecirc;̀ Ý NGHĨA MÀU SẮC</strong></h3>\r\n\r\n<div class=\"wp-caption alignnone\" id=\"attachment_2401\" style=\"width: 545px\"><a href=\"http://d2design.vn/chon-mau-sac-trong-thiet-ke-logo/\"><img alt=\"mau-sac-trong-thiet-ke-logo\" class=\"wp-image-2401 size-full\" height=\"387\" sizes=\"(max-width: 535px) 100vw, 535px\" src=\"http://d2design.vn/wp-content/uploads/2014/09/logocolours.jpg\" srcset=\"http://d2design.vn/wp-content/uploads/2014/09/logocolours-300x217.jpg 300w, http://d2design.vn/wp-content/uploads/2014/09/logocolours-320x231.jpg 320w, http://d2design.vn/wp-content/uploads/2014/09/logocolours.jpg 535w\" width=\"535\" /></a>\r\n\r\n<p class=\"wp-caption-text\">Thương hiệu lớn chọn m&agrave;u sắc của họ một c&aacute;ch cẩn thận</p>\r\n</div>\r\n\r\n<p>Mỗi m&agrave;u sắc, bao gồm m&agrave;u đen v&agrave; trắng, đ&ecirc;̀u c&oacute; ảnh hưởng đến thiết kế logo. L&agrave; một nh&agrave; thiết kế bạn cần phải chọn m&agrave;u sắc của bạn một c&aacute;ch cẩn thận để tăng cường c&aacute;c yếu tố cụ thể của c&aacute;c biểu tượng v&agrave; mang sắc th&aacute;i cho th&ocirc;ng đi&ecirc;̣p tin của bạn với việc sử dụng đ&ocirc;̣ bóng v&agrave; đ&ocirc;̣ sáng t&ocirc;́i.</p>\r\n\r\n<p>N&oacute;i chung, m&agrave;u sắc tươi s&aacute;ng v&agrave; đậm nét được sự ch&uacute; &yacute; nhưng c&oacute; thể xuất hiện v&ecirc;́t loang l&ocirc;̉. C&aacute;c t&ocirc;ng m&agrave;u trầm truyền tải một h&igrave;nh ảnh tinh vi hơn, nhưng c&oacute; nguy cơ bị xem nhẹ. Cụ thể hơn, m&ocirc;̃i &yacute; nghĩa ri&ecirc;ng bi&ecirc;̣t được g&aacute;n cho những m&agrave;u sắc kh&aacute;c nhau trong x&atilde; hội &hellip;</p>\r\n\r\n<ul style=\"list-style-type: square;\">\r\n	<li><strong>Màu đỏ</strong> nghĩa là niềm đam m&ecirc;, năng lượng, nguy hiểm hoặc g&acirc;y hấn; ấm &aacute;p v&agrave; nhiệt. N&oacute; cũng đ&atilde; được chứng minh trong vi&ecirc;̣c k&iacute;ch th&iacute;ch sự th&egrave;m ăn, điều n&agrave;y giải th&iacute;ch l&yacute; do tại sao n&oacute; được sử dụng trong rất nhiều nh&agrave; h&agrave;ng v&agrave; những sản phẩm logo thực phẩm. Lựa chọn m&agrave;u đỏ cho logo của bạn c&oacute; thể l&agrave;m cho nó s&ocirc;i n&ocirc;̉i hơn.</li>\r\n	<li><strong>Màu cam</strong> thường được xem như l&agrave; m&agrave;u sắc của sự s&aacute;ng tạo v&agrave; tư duy hiện đại. N&oacute; cũng mang &yacute; nghĩa của tuổi trẻ, vui vẻ, khả năng chi trả v&agrave; khả năng ti&ecirc;́p c&acirc;̣n.<br />\r\n	Màu vàng đòi hỏi phải sử dụng thận trọng v&igrave; n&oacute; c&oacute; một số &yacute; nghĩa ti&ecirc;u cực bao gồm cả nghĩa của sự h&egrave;n nh&aacute;t v&agrave; sử dụng n&oacute; trong c&aacute;c dấu hiệu cảnh b&aacute;o. Tuy nhi&ecirc;n nó mang lại sự vui vẻ, ấm &aacute;p v&agrave; th&acirc;n thiện v&agrave; l&agrave; một m&agrave;u sắc được cho l&agrave; để k&iacute;ch th&iacute;ch sự th&egrave;m ăn.</li>\r\n	<li><strong>M&agrave;u xanh l&aacute; c&acirc;y</strong> thường được sử dụng khi một c&ocirc;ng ty muốn nhấn mạnh những ph&acirc;̉m ch&acirc;́t tự nhi&ecirc;n v&agrave; đạo đức trong sản ph&acirc;̉m của họ, đặc biệt l&agrave; với c&aacute;c sản phẩm như thực phẩm hữu cơ v&agrave; ăn chay. Những ý nghĩa kh&aacute;c của nó là sự phát tri&ecirc;̉n v&agrave; sự tươi m&aacute;t, v&agrave; n&oacute; cũng phổ biến với c&aacute;c sản phẩm t&agrave;i ch&iacute;nh.</li>\r\n	<li><strong>M&agrave;u xanh da trời</strong> l&agrave; một trong những m&agrave;u sắc được sử dụng rộng r&atilde;i nhất tr&ecirc;n logo của c&ocirc;ng ty. Điều đ&oacute; ngụ &yacute; t&iacute;nh chuy&ecirc;n nghiệp, cách nhìn nghi&ecirc;m túc, t&iacute;nh to&agrave;n vẹn, ch&acirc;n th&agrave;nh v&agrave; b&igrave;nh tĩnh. Màu xanh trời cũng được kết hợp với ch&iacute;nh quyền v&agrave; sự th&agrave;nh c&ocirc;ng, v&agrave; v&igrave; l&yacute; do n&agrave;y n&ecirc;n nó phổ biến với cả tổ chức t&agrave;i ch&iacute;nh v&agrave; c&aacute;c cơ quan ch&iacute;nh phủ.</li>\r\n</ul>\r\n\r\n<div class=\"wp-caption alignnone\" id=\"attachment_2402\" style=\"width: 510px\"><a href=\"http://d2design.vn/chon-mau-sac-trong-thiet-ke-logo/\"><img alt=\"bieu-do-mau-sac\" class=\"size-full wp-image-2402\" height=\"500\" sizes=\"(max-width: 500px) 100vw, 500px\" src=\"http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel.jpg\" srcset=\"http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-150x150.jpg 150w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-300x300.jpg 300w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-320x320.jpg 320w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-239x239.jpg 239w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-55x55.jpg 55w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel.jpg 500w\" width=\"500\" /></a>\r\n\r\n<p class=\"wp-caption-text\">Biểu đồ n&agrave;y cho thấy m&ocirc;̃i chủ đề thường k&ecirc;́t hợp với từng m&agrave;u sắc ri&ecirc;ng bi&ecirc;̣t</p>\r\n</div>\r\n\r\n<ul style=\"list-style-type: square;\">\r\n	<li><strong>Màu t&iacute;m</strong> n&oacute;i với ch&uacute;ng ta về sự quý phái v&agrave; sang trọng. N&oacute; được li&ecirc;n kết từ l&acirc;u với c&aacute;c nh&agrave; thờ, hàm ý v&ecirc;̀ sự th&ocirc;ng thái v&agrave; lòng tự trọng, v&agrave; xuy&ecirc;n suốt lịch sử nó là m&agrave;u sắc của sự gi&agrave;u c&oacute; v&agrave; phong ph&uacute;.</li>\r\n	<li><strong>Màu đen</strong> l&agrave; một m&agrave;u sắc của sự đa nh&acirc;n c&aacute;ch. M&ocirc;̣t mặt n&oacute; ngụ &yacute; v&ecirc;̀ sức mạnh v&agrave; sự tinh tế, nhưng mặt kh&aacute;c, n&oacute; c&oacute; lại li&ecirc;n quan đến sự ty tiện v&agrave; c&aacute;i chết. Càng có nhiều tính tr&acirc;̀n trục, thì hầu hết c&aacute;c biểu tượng sẽ cần một phi&ecirc;n bản m&agrave;u đen v&agrave; trắng để sử dụng trong phương tiện truyền th&ocirc;ng, trong đ&oacute; m&agrave;u sắc l&agrave; kh&ocirc;ng giá trị- v&agrave; đ&acirc;y là xu hướng hiện nay cho c&aacute;c biểu tượng đơn sắc đậm nét v&agrave; nh&atilde;n từ.</li>\r\n	<li><strong>Màu trắng</strong> thường được kết hợp với sự tinh khiết, sạch sẽ, đơn giản v&agrave; ng&acirc;y thơ. Tr&ecirc;n thực tế, một biểu tượng m&agrave;u trắng sẽ lu&ocirc;n lu&ocirc;n cần phải đứng trong một n&ecirc;̀n m&agrave;u để th&ecirc;̉ hi&ecirc;̣n nó tr&ecirc;n một nền trắng. Nhiều c&ocirc;ng ty sẽ chọn c&oacute; một phi&ecirc;n bản m&agrave;u v&agrave; một phi&ecirc;n bản m&agrave;u trắng trong các logo của họ; V&iacute; dụ, kí tự Coca-Cola dc th&ecirc;̉ hi&ecirc;̣n trong m&agrave;u trắng tr&ecirc;n lon m&agrave;u đỏ v&agrave; chai m&agrave;u n&acirc;u nhưng chữ chỉ dc sử dụng màu đỏ khi cần thiết tr&ecirc;n nền trắng.</li>\r\n	<li><strong>Màu n&acirc;u</strong> c&oacute; &yacute; nghĩa nam t&iacute;nh v&agrave; thường được sử dụng cho c&aacute;c sản phẩm gắn liền với cuộc sống n&ocirc;ng th&ocirc;n v&agrave; ngo&agrave;i trời.<br />\r\n	M&agrave;u hồng c&oacute; thể được vui vẻ v&agrave; quyến rũ, nhưng sự nữ t&iacute;nh của n&oacute; thường được tr&aacute;nh cho c&aacute;c sản phẩm kh&ocirc;ng đặc biệt nhắm mục ti&ecirc;u v&agrave;o phụ nữ.</li>\r\n</ul>\r\n\r\n<p>T&acirc;́t nhi&ecirc;n,những sự li&ecirc;n tưởng n&agrave;y kh&ocirc;ng phải l&agrave; quy tắc cứng nhắc, nhưng chúng đáng lưu giữ trong t&acirc;m tr&iacute; khi bạn lựa chọn màu sắc. H&atilde;y nhớ rằng c&aacute;c t&aacute;c động tổng thể của thiết kế logo của bạn sẽ phụ thuộc kh&ocirc;ng chỉ v&agrave;o m&agrave;u sắc mà còn dựa tr&ecirc;n sựu tương t&aacute;c với c&aacute;c h&igrave;nh dạng v&agrave; văn bản.</p>\r\n\r\n<h3>N&Ecirc;N CHỌN M&Ocirc;̣T HAY NHI&Ecirc;̀U MÀU SẮC?</h3>\r\n\r\n<div class=\"wp-caption alignnone\" id=\"attachment_2403\" style=\"width: 545px\"><a href=\"http://d2design.vn/chon-mau-sac-trong-thiet-ke-logo/\"><img alt=\"Nhiều màu sắc rất khó để tạo sức hút, nhưng có thể tác động\" class=\"size-full wp-image-2403\" height=\"214\" src=\"http://d2design.vn/wp-content/uploads/2014/09/ebay.jpg\" width=\"535\" /></a>\r\n\r\n<p class=\"wp-caption-text\">Nhiều m&agrave;u sắc rất kh&oacute; để tạo sức hút, nhưng c&oacute; thể tác đ&ocirc;̣ng</p>\r\n</div>\r\n\r\n<p>Để đạt được mức ảnh hưởng tối đa của h&ecirc;̣ th&ocirc;́ng mã hi&ecirc;̣u trong màu sắc bạn chọn, t&ocirc;i thường gắn một m&agrave;u duy nhất khi tạo ra một thiết kế logo. Điều đ&oacute; n&oacute;i l&ecirc;n rằng, c&oacute; một số biểu tượng nhiều m&agrave;u rất th&agrave;nh c&ocirc;ng &ndash; suy nghĩ v&ecirc;̀ Google, Windows hay eBay.</p>\r\n\r\n<p>H&agrave;m &yacute; của nhiều m&agrave;u sắc l&agrave; c&aacute;c c&ocirc;ng ty đang mang lại nhiều sự lựa chọn cho c&aacute;c sản phẩm v&agrave; dịch vụ. Những m&agrave;u sắc được sử dụng cho c&aacute;c v&ograve;ng tr&ograve;n Olympic thực hi&ecirc;̣n một th&ocirc;ng điệp của sự đa dạng v&agrave; inclusivity</p>\r\n\r\n<p>Một xu hướng mới nổi trong thiết kế logo l&agrave; việc sử dụng c&aacute;c m&ocirc; h&igrave;nh khảm. Những thi&ecirc;́t k&ecirc;́ logo này hi&ecirc;̉n nhi&ecirc;n đ&ograve;i hỏi nhiều m&agrave;u sắc kh&aacute;c nhau, từ tương phản ánh sáng đ&ecirc;́n nhiều sắc th&aacute;i của một m&agrave;u duy nhất.</p>\r\n\r\n<h3>HÃY SUY NGHĨ 1 CÁCH T&Ocirc;̉NG TH&Ecirc;̉</h3>\r\n\r\n<p>Nếu kh&aacute;ch h&agrave;ng của bạn l&agrave; một c&ocirc;ng ty nước ngoài, hãy c&acirc;̉n th&acirc;̣n lựa chọn m&agrave;u sắc cho thi&ecirc;́t k&ecirc;́ logo của bạn. Sự kh&aacute;c biệt v&ecirc;̀ văn h&oacute;a được giải th&iacute;ch bởi các màu sắc. V&iacute; dụ, m&agrave;u đỏ được coi l&agrave; may mắn ở Trung Quốc, trong khi m&agrave;u trắng l&agrave; m&agrave;u của c&aacute;i chết v&agrave; tang tóc ở Ấn Độ. Đ&acirc;y là sự t&acirc;̣p trung tốt v&ecirc;̀ &yacute; nghĩa văn h&oacute;a của m&agrave;u sắc kh&aacute;c nhau.</p>\r\n\r\n<p>Cuối c&ugrave;ng, đừng đặt qu&aacute; nhiều trọng t&acirc;m v&agrave;o sự lựa chọn m&agrave;u sắc. H&atilde;y tính đ&ecirc;́n vi&ecirc;̣c một trong 12 người ch&uacute;ng ta bị m&ugrave; m&agrave;u. Cộng với vi&ecirc;̣c lu&ocirc;n lu&ocirc;n c&oacute; khả năng rằng bất kỳ biểu tượng bạn sản xuất cho một kh&aacute;ch h&agrave;ng sẽ kết th&uacute;c bằng vi&ecirc;̣c phải thi&ecirc;́t k&ecirc;́ lại theo đơn sắc, hoặc thậm ch&iacute; trong c&aacute;c m&agrave;u sắc kh&aacute;c nhau, khi họ thấy ph&ugrave; hợp. V&igrave; vậy, chắc chắn rằng sự lựa chọn m&agrave;u sắc của bạn củng cố v&agrave; tăng cường sự thiết kế cho logo của bạn &ndash; nhưng đừng x&aacute;c định n&oacute;.</p>\r\n\r\n<p>L&agrave;m thế n&agrave;o để bạn chọn m&agrave;u sắc cho thiết kế logo của bạn? Chia sẻ quan điểm của bạn trong phần comment dưới đ&acirc;y.</p>\r\n','<p><strong>&ldquo;Hiểu được t&iacute;nh chất t&acirc;m l&yacute; của m&agrave;u sắc r&acirc;́t quan trọng để thiết kế một logo hiệu quả&rdquo;</strong> &ndash; Martin Christie, gi&aacute;m đốc s&aacute;ng tạo tại c&ocirc;ng ty thiết kế đồ họa Logo Design London. Với nhiều năm kinh nghiệm trong việc x&acirc;y dựng thương hiệu v&agrave; thiết kế, Martin thường xuy&ecirc;n chia sẻ kinh nghiệm của m&igrave;nh với kh&aacute;ch h&agrave;ng v&agrave; những nhà thiết kế đồ họa..</p>\r\n\r\n<p>T&acirc;m tr&iacute; con người phản ứng r&acirc;́t nhanh với c&aacute;c k&iacute;ch th&iacute;ch thị gi&aacute;c, v&agrave; m&agrave;u sắc l&agrave; một trong những yếu tố quan trọng đ&ecirc;̉ xác định điều đ&oacute;. Cả v&ecirc;̀ mức độ &yacute; thức v&agrave; tiềm thức, m&agrave;u sắc chuyển tải &yacute; nghĩa kh&ocirc;ng chỉ trong thế giới tự nhi&ecirc;n m&agrave; c&ograve;n trong những thứ nh&acirc;n tạo của nền văn h&oacute;a của ch&uacute;ng ta. Thiết kế đồ họa cần phải khai th&aacute;c sức mạnh của t&acirc;m l&yacute; m&agrave;u sắc để mang lại sự cộng hưởng với thiết kế của họ- v&agrave; kh&ocirc;ng c&oacute; lĩnh vực n&agrave;o quan trọng hơn so với sự c&ocirc;̣ng hưởng đó trong thiết kế logo.</p>\r\n\r\n<p>Việc sử dụng m&agrave;u sắc c&oacute; thể mang lại nhiều lớp t&acirc;̀ng ý nghĩa, từ phản ứng nguy&ecirc;n thủy dựa tr&ecirc;n h&agrave;ng triệu năm của bản năng tiến h&oacute;a đ&ecirc;́n qu&acirc;̀n th&ecirc;̉ phức tạp ch&uacute;ng t&ocirc;i thực hiện dựa tr&ecirc;n c&aacute;c giả định học được. C&aacute;c c&ocirc;ng ty c&oacute; thể sử dụng những phản ứng đó để nhấn mạnh và làm n&ocirc;̉i b&acirc;̣t th&ocirc;ng điệp trong thương hiệu của họ. V&agrave; sự th&agrave;nh c&ocirc;ng của bạn làm cho bạn thành một nh&agrave; thiết kế logo n&ocirc;̉i ti&ecirc;́ng nếu bạn c&oacute; một sự hiểu biết thấu đ&aacute;o về t&acirc;m l&yacute; m&agrave;u sắc.</p>\r\n\r\n<h3><strong>SỰ KHÁC NHAU V&Ecirc;̀ Ý NGHĨA MÀU SẮC</strong></h3>\r\n\r\n<div class=\"wp-caption alignnone\" id=\"attachment_2401\" style=\"width: 545px\"><a href=\"http://d2design.vn/chon-mau-sac-trong-thiet-ke-logo/\"><img alt=\"mau-sac-trong-thiet-ke-logo\" class=\"wp-image-2401 size-full\" height=\"387\" sizes=\"(max-width: 535px) 100vw, 535px\" src=\"http://d2design.vn/wp-content/uploads/2014/09/logocolours.jpg\" srcset=\"http://d2design.vn/wp-content/uploads/2014/09/logocolours-300x217.jpg 300w, http://d2design.vn/wp-content/uploads/2014/09/logocolours-320x231.jpg 320w, http://d2design.vn/wp-content/uploads/2014/09/logocolours.jpg 535w\" width=\"535\" /></a>\r\n\r\n<p class=\"wp-caption-text\">Thương hiệu lớn chọn m&agrave;u sắc của họ một c&aacute;ch cẩn thận</p>\r\n</div>\r\n\r\n<p>Mỗi m&agrave;u sắc, bao gồm m&agrave;u đen v&agrave; trắng, đ&ecirc;̀u c&oacute; ảnh hưởng đến thiết kế logo. L&agrave; một nh&agrave; thiết kế bạn cần phải chọn m&agrave;u sắc của bạn một c&aacute;ch cẩn thận để tăng cường c&aacute;c yếu tố cụ thể của c&aacute;c biểu tượng v&agrave; mang sắc th&aacute;i cho th&ocirc;ng đi&ecirc;̣p tin của bạn với việc sử dụng đ&ocirc;̣ bóng v&agrave; đ&ocirc;̣ sáng t&ocirc;́i.</p>\r\n\r\n<p>N&oacute;i chung, m&agrave;u sắc tươi s&aacute;ng v&agrave; đậm nét được sự ch&uacute; &yacute; nhưng c&oacute; thể xuất hiện v&ecirc;́t loang l&ocirc;̉. C&aacute;c t&ocirc;ng m&agrave;u trầm truyền tải một h&igrave;nh ảnh tinh vi hơn, nhưng c&oacute; nguy cơ bị xem nhẹ. Cụ thể hơn, m&ocirc;̃i &yacute; nghĩa ri&ecirc;ng bi&ecirc;̣t được g&aacute;n cho những m&agrave;u sắc kh&aacute;c nhau trong x&atilde; hội &hellip;</p>\r\n\r\n<ul style=\"list-style-type: square;\">\r\n	<li><strong>Màu đỏ</strong> nghĩa là niềm đam m&ecirc;, năng lượng, nguy hiểm hoặc g&acirc;y hấn; ấm &aacute;p v&agrave; nhiệt. N&oacute; cũng đ&atilde; được chứng minh trong vi&ecirc;̣c k&iacute;ch th&iacute;ch sự th&egrave;m ăn, điều n&agrave;y giải th&iacute;ch l&yacute; do tại sao n&oacute; được sử dụng trong rất nhiều nh&agrave; h&agrave;ng v&agrave; những sản phẩm logo thực phẩm. Lựa chọn m&agrave;u đỏ cho logo của bạn c&oacute; thể l&agrave;m cho nó s&ocirc;i n&ocirc;̉i hơn.</li>\r\n	<li><strong>Màu cam</strong> thường được xem như l&agrave; m&agrave;u sắc của sự s&aacute;ng tạo v&agrave; tư duy hiện đại. N&oacute; cũng mang &yacute; nghĩa của tuổi trẻ, vui vẻ, khả năng chi trả v&agrave; khả năng ti&ecirc;́p c&acirc;̣n.<br />\r\n	Màu vàng đòi hỏi phải sử dụng thận trọng v&igrave; n&oacute; c&oacute; một số &yacute; nghĩa ti&ecirc;u cực bao gồm cả nghĩa của sự h&egrave;n nh&aacute;t v&agrave; sử dụng n&oacute; trong c&aacute;c dấu hiệu cảnh b&aacute;o. Tuy nhi&ecirc;n nó mang lại sự vui vẻ, ấm &aacute;p v&agrave; th&acirc;n thiện v&agrave; l&agrave; một m&agrave;u sắc được cho l&agrave; để k&iacute;ch th&iacute;ch sự th&egrave;m ăn.</li>\r\n	<li><strong>M&agrave;u xanh l&aacute; c&acirc;y</strong> thường được sử dụng khi một c&ocirc;ng ty muốn nhấn mạnh những ph&acirc;̉m ch&acirc;́t tự nhi&ecirc;n v&agrave; đạo đức trong sản ph&acirc;̉m của họ, đặc biệt l&agrave; với c&aacute;c sản phẩm như thực phẩm hữu cơ v&agrave; ăn chay. Những ý nghĩa kh&aacute;c của nó là sự phát tri&ecirc;̉n v&agrave; sự tươi m&aacute;t, v&agrave; n&oacute; cũng phổ biến với c&aacute;c sản phẩm t&agrave;i ch&iacute;nh.</li>\r\n	<li><strong>M&agrave;u xanh da trời</strong> l&agrave; một trong những m&agrave;u sắc được sử dụng rộng r&atilde;i nhất tr&ecirc;n logo của c&ocirc;ng ty. Điều đ&oacute; ngụ &yacute; t&iacute;nh chuy&ecirc;n nghiệp, cách nhìn nghi&ecirc;m túc, t&iacute;nh to&agrave;n vẹn, ch&acirc;n th&agrave;nh v&agrave; b&igrave;nh tĩnh. Màu xanh trời cũng được kết hợp với ch&iacute;nh quyền v&agrave; sự th&agrave;nh c&ocirc;ng, v&agrave; v&igrave; l&yacute; do n&agrave;y n&ecirc;n nó phổ biến với cả tổ chức t&agrave;i ch&iacute;nh v&agrave; c&aacute;c cơ quan ch&iacute;nh phủ.</li>\r\n</ul>\r\n\r\n<div class=\"wp-caption alignnone\" id=\"attachment_2402\" style=\"width: 510px\"><a href=\"http://d2design.vn/chon-mau-sac-trong-thiet-ke-logo/\"><img alt=\"bieu-do-mau-sac\" class=\"size-full wp-image-2402\" height=\"500\" sizes=\"(max-width: 500px) 100vw, 500px\" src=\"http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel.jpg\" srcset=\"http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-150x150.jpg 150w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-300x300.jpg 300w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-320x320.jpg 320w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-239x239.jpg 239w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel-55x55.jpg 55w, http://d2design.vn/wp-content/uploads/2014/09/logo-color-psychology-wheel.jpg 500w\" width=\"500\" /></a>\r\n\r\n<p class=\"wp-caption-text\">Biểu đồ n&agrave;y cho thấy m&ocirc;̃i chủ đề thường k&ecirc;́t hợp với từng m&agrave;u sắc ri&ecirc;ng bi&ecirc;̣t</p>\r\n</div>\r\n\r\n<ul style=\"list-style-type: square;\">\r\n	<li><strong>Màu t&iacute;m</strong> n&oacute;i với ch&uacute;ng ta về sự quý phái v&agrave; sang trọng. N&oacute; được li&ecirc;n kết từ l&acirc;u với c&aacute;c nh&agrave; thờ, hàm ý v&ecirc;̀ sự th&ocirc;ng thái v&agrave; lòng tự trọng, v&agrave; xuy&ecirc;n suốt lịch sử nó là m&agrave;u sắc của sự gi&agrave;u c&oacute; v&agrave; phong ph&uacute;.</li>\r\n	<li><strong>Màu đen</strong> l&agrave; một m&agrave;u sắc của sự đa nh&acirc;n c&aacute;ch. M&ocirc;̣t mặt n&oacute; ngụ &yacute; v&ecirc;̀ sức mạnh v&agrave; sự tinh tế, nhưng mặt kh&aacute;c, n&oacute; c&oacute; lại li&ecirc;n quan đến sự ty tiện v&agrave; c&aacute;i chết. Càng có nhiều tính tr&acirc;̀n trục, thì hầu hết c&aacute;c biểu tượng sẽ cần một phi&ecirc;n bản m&agrave;u đen v&agrave; trắng để sử dụng trong phương tiện truyền th&ocirc;ng, trong đ&oacute; m&agrave;u sắc l&agrave; kh&ocirc;ng giá trị- v&agrave; đ&acirc;y là xu hướng hiện nay cho c&aacute;c biểu tượng đơn sắc đậm nét v&agrave; nh&atilde;n từ.</li>\r\n	<li><strong>Màu trắng</strong> thường được kết hợp với sự tinh khiết, sạch sẽ, đơn giản v&agrave; ng&acirc;y thơ. Tr&ecirc;n thực tế, một biểu tượng m&agrave;u trắng sẽ lu&ocirc;n lu&ocirc;n cần phải đứng trong một n&ecirc;̀n m&agrave;u để th&ecirc;̉ hi&ecirc;̣n nó tr&ecirc;n một nền trắng. Nhiều c&ocirc;ng ty sẽ chọn c&oacute; một phi&ecirc;n bản m&agrave;u v&agrave; một phi&ecirc;n bản m&agrave;u trắng trong các logo của họ; V&iacute; dụ, kí tự Coca-Cola dc th&ecirc;̉ hi&ecirc;̣n trong m&agrave;u trắng tr&ecirc;n lon m&agrave;u đỏ v&agrave; chai m&agrave;u n&acirc;u nhưng chữ chỉ dc sử dụng màu đỏ khi cần thiết tr&ecirc;n nền trắng.</li>\r\n	<li><strong>Màu n&acirc;u</strong> c&oacute; &yacute; nghĩa nam t&iacute;nh v&agrave; thường được sử dụng cho c&aacute;c sản phẩm gắn liền với cuộc sống n&ocirc;ng th&ocirc;n v&agrave; ngo&agrave;i trời.<br />\r\n	M&agrave;u hồng c&oacute; thể được vui vẻ v&agrave; quyến rũ, nhưng sự nữ t&iacute;nh của n&oacute; thường được tr&aacute;nh cho c&aacute;c sản phẩm kh&ocirc;ng đặc biệt nhắm mục ti&ecirc;u v&agrave;o phụ nữ.</li>\r\n</ul>\r\n\r\n<p>T&acirc;́t nhi&ecirc;n,những sự li&ecirc;n tưởng n&agrave;y kh&ocirc;ng phải l&agrave; quy tắc cứng nhắc, nhưng chúng đáng lưu giữ trong t&acirc;m tr&iacute; khi bạn lựa chọn màu sắc. H&atilde;y nhớ rằng c&aacute;c t&aacute;c động tổng thể của thiết kế logo của bạn sẽ phụ thuộc kh&ocirc;ng chỉ v&agrave;o m&agrave;u sắc mà còn dựa tr&ecirc;n sựu tương t&aacute;c với c&aacute;c h&igrave;nh dạng v&agrave; văn bản.</p>\r\n\r\n<h3>N&Ecirc;N CHỌN M&Ocirc;̣T HAY NHI&Ecirc;̀U MÀU SẮC?</h3>\r\n\r\n<div class=\"wp-caption alignnone\" id=\"attachment_2403\" style=\"width: 545px\"><a href=\"http://d2design.vn/chon-mau-sac-trong-thiet-ke-logo/\"><img alt=\"Nhiều màu sắc rất khó để tạo sức hút, nhưng có thể tác động\" class=\"size-full wp-image-2403\" height=\"214\" src=\"http://d2design.vn/wp-content/uploads/2014/09/ebay.jpg\" width=\"535\" /></a>\r\n\r\n<p class=\"wp-caption-text\">Nhiều m&agrave;u sắc rất kh&oacute; để tạo sức hút, nhưng c&oacute; thể tác đ&ocirc;̣ng</p>\r\n</div>\r\n\r\n<p>Để đạt được mức ảnh hưởng tối đa của h&ecirc;̣ th&ocirc;́ng mã hi&ecirc;̣u trong màu sắc bạn chọn, t&ocirc;i thường gắn một m&agrave;u duy nhất khi tạo ra một thiết kế logo. Điều đ&oacute; n&oacute;i l&ecirc;n rằng, c&oacute; một số biểu tượng nhiều m&agrave;u rất th&agrave;nh c&ocirc;ng &ndash; suy nghĩ v&ecirc;̀ Google, Windows hay eBay.</p>\r\n\r\n<p>H&agrave;m &yacute; của nhiều m&agrave;u sắc l&agrave; c&aacute;c c&ocirc;ng ty đang mang lại nhiều sự lựa chọn cho c&aacute;c sản phẩm v&agrave; dịch vụ. Những m&agrave;u sắc được sử dụng cho c&aacute;c v&ograve;ng tr&ograve;n Olympic thực hi&ecirc;̣n một th&ocirc;ng điệp của sự đa dạng v&agrave; inclusivity</p>\r\n\r\n<p>Một xu hướng mới nổi trong thiết kế logo l&agrave; việc sử dụng c&aacute;c m&ocirc; h&igrave;nh khảm. Những thi&ecirc;́t k&ecirc;́ logo này hi&ecirc;̉n nhi&ecirc;n đ&ograve;i hỏi nhiều m&agrave;u sắc kh&aacute;c nhau, từ tương phản ánh sáng đ&ecirc;́n nhiều sắc th&aacute;i của một m&agrave;u duy nhất.</p>\r\n\r\n<h3>HÃY SUY NGHĨ 1 CÁCH T&Ocirc;̉NG TH&Ecirc;̉</h3>\r\n\r\n<p>Nếu kh&aacute;ch h&agrave;ng của bạn l&agrave; một c&ocirc;ng ty nước ngoài, hãy c&acirc;̉n th&acirc;̣n lựa chọn m&agrave;u sắc cho thi&ecirc;́t k&ecirc;́ logo của bạn. Sự kh&aacute;c biệt v&ecirc;̀ văn h&oacute;a được giải th&iacute;ch bởi các màu sắc. V&iacute; dụ, m&agrave;u đỏ được coi l&agrave; may mắn ở Trung Quốc, trong khi m&agrave;u trắng l&agrave; m&agrave;u của c&aacute;i chết v&agrave; tang tóc ở Ấn Độ. Đ&acirc;y là sự t&acirc;̣p trung tốt v&ecirc;̀ &yacute; nghĩa văn h&oacute;a của m&agrave;u sắc kh&aacute;c nhau.</p>\r\n\r\n<p>Cuối c&ugrave;ng, đừng đặt qu&aacute; nhiều trọng t&acirc;m v&agrave;o sự lựa chọn m&agrave;u sắc. H&atilde;y tính đ&ecirc;́n vi&ecirc;̣c một trong 12 người ch&uacute;ng ta bị m&ugrave; m&agrave;u. Cộng với vi&ecirc;̣c lu&ocirc;n lu&ocirc;n c&oacute; khả năng rằng bất kỳ biểu tượng bạn sản xuất cho một kh&aacute;ch h&agrave;ng sẽ kết th&uacute;c bằng vi&ecirc;̣c phải thi&ecirc;́t k&ecirc;́ lại theo đơn sắc, hoặc thậm ch&iacute; trong c&aacute;c m&agrave;u sắc kh&aacute;c nhau, khi họ thấy ph&ugrave; hợp. V&igrave; vậy, chắc chắn rằng sự lựa chọn m&agrave;u sắc của bạn củng cố v&agrave; tăng cường sự thiết kế cho logo của bạn &ndash; nhưng đừng x&aacute;c định n&oacute;.</p>\r\n\r\n<p>L&agrave;m thế n&agrave;o để bạn chọn m&agrave;u sắc cho thiết kế logo của bạn? Chia sẻ quan điểm của bạn trong phần comment dưới đ&acirc;y.</p>\r\n','upload/images/news/logo-color-psychology-wheel-320x180.jpg','1466338244','0');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;


--
-- Create Table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE `blocks` (
  `block_id` int(11) NOT NULL AUTO_INCREMENT,
  `block_name` varchar(255) NOT NULL,
  `block_content_cn` text NOT NULL,
  `block_content_vi` text NOT NULL,
  `block_content_en` text NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`block_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Data for Table `blocks`
--

/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` (`block_id`,`block_name`,`block_content_cn`,`block_content_vi`,`block_content_en`,`update_time`) VALUES ('2','Footer','','','','1467195265');
INSERT INTO `blocks` (`block_id`,`block_name`,`block_content_cn`,`block_content_vi`,`block_content_en`,`update_time`) VALUES ('3','Giới thiệu','','','','1467195281');
INSERT INTO `blocks` (`block_id`,`block_name`,`block_content_cn`,`block_content_vi`,`block_content_en`,`update_time`) VALUES ('5','Liên hệ ','','','','1467195291');
INSERT INTO `blocks` (`block_id`,`block_name`,`block_content_cn`,`block_content_vi`,`block_content_en`,`update_time`) VALUES ('16','Giới thiệu trang chủ','','<h2 class=\"g1-h1\" style=\"text-align: center;\"><a href=\"#\">Open Advertising </a></h2>\r\n\r\n<div>&nbsp;</div>\r\n\r\n<p>Với đội ngũ c&oacute; nhiều kinh nghiệm ở tất cả c&aacute;c kh&acirc;u của qu&aacute; tr&igrave;nh từ thiết kế cho đến in ấn, thiết kế hệ thống nhận diện thương hiệu, từ việc thiết kế cho đến ph&aacute;t triển website, chụp ảnh quảng c&aacute;o để c&oacute; những h&igrave;nh ảnh đạt chất lượng tốt nhất trong việc thiết kế in ấn &ndash; cũng như h&igrave;nh ảnh d&ugrave;ng cho quảng c&aacute;o truyền th&ocirc;ng. Open Advertising lu&ocirc;n thực hiện tốt tất cả c&aacute;c y&ecirc;u cầu của bạn, bất kể y&ecirc;u cầu của bạn ra sao, ch&uacute;ng t&ocirc;i đều thực hiện tốt c&ocirc;ng việc của m&igrave;nh.</p>\r\n','<h2 class=\"g1-h1\" style=\"text-align: center;\"><a href=\"#\">Open Advertising </a></h2>\r\n\r\n<div>&nbsp;</div>\r\n\r\n<p>Với đội ngũ c&oacute; nhiều kinh nghiệm ở tất cả c&aacute;c kh&acirc;u của qu&aacute; tr&igrave;nh từ thiết kế cho đến in ấn, thiết kế hệ thống nhận diện thương hiệu, từ việc thiết kế cho đến ph&aacute;t triển website, chụp ảnh quảng c&aacute;o để c&oacute; những h&igrave;nh ảnh đạt chất lượng tốt nhất trong việc thiết kế in ấn &ndash; cũng như h&igrave;nh ảnh d&ugrave;ng cho quảng c&aacute;o truyền th&ocirc;ng. Open Advertising lu&ocirc;n thực hiện tốt tất cả c&aacute;c y&ecirc;u cầu của bạn, bất kể y&ecirc;u cầu của bạn ra sao, ch&uacute;ng t&ocirc;i đều thực hiện tốt c&ocirc;ng việc của m&igrave;nh.</p>\r\n','1467298283');
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;


--
-- Create Table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name_cn` varchar(255) NOT NULL,
  `cate_name_vi` varchar(255) NOT NULL,
  `cate_name_en` varchar(255) NOT NULL,
  `cate_alias` varchar(255) NOT NULL,
  `idTL` int(10) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

--
-- Data for Table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('54','','Bàn phím','Key board','key-board','20','Bàn phím','Bàn phím','Bàn phím','1444819101');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('40','','Bảng hiệu - hộp đèn','Tờ rơi - tờ gấp','to-roi-to-gap','18','Bảng hiệu - hộp đèn','Bảng hiệu - hộp đèn','Bảng hiệu - hộp đèn','1468161172');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('38','','Qmobile','Qmobile','qmobile','17','Qmobile','Qmobile','Qmobile','1443935220');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('39','','Lenovo','Lenovo','lenovo','17','Lenovo','Lenovo','Lenovo','1443935230');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('36','','LG','LG','lg','17','LG','LG','LG','1443935177');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('37','','Huawei','Huawei','huawei','17','Huawei','Huawei','Huawei','1443935193');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('35','','HTC','HTC','htc','17','HTC','HTC','HTC','1443935170');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('34','','Oppo','Oppo','oppo','17','Oppo','Oppo','Oppo','1443935131');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('32','','Asus','Asus','asus','17','Asus','Asus','Asus','1443935095');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('18','','Pin sạc dự phòng','Rechargeable backup','rechargeable-backup','20','Pin sạc dự phòng','Pin sạc dự phòng','Pin sạc dự phòng','1445098219');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('19','','Thẻ nhớ','Memory Stick','memory-stick','20','Thẻ nhớ','Thẻ nhớ','Thẻ nhớ','1445098295');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('20','','Miếng dàn cường lực','Stickers toughened','stickers-toughened','20','Miếng dàn cường lực','Miếng dàn cường lực','Miếng dàn cường lực','1445097874');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('21','','Iphone','Iphone','iphone','17','Iphone','Iphone','Iphone','1445094373');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('29','','Samsung','Samsung','samsung','17','','','','1443935056');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('30','','Nokia','Nokia','nokia','17','Nokia','Nokia','Nokia','1443935081');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('41','','Bảng điện tử','Brochure','brochure','18','Bảng điện tử','Bảng điện tử','Bảng điện tử','1468161213');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('49','','In nhanh kỹ thuật số','In nhanh kỹ thuật số','in-nhanh-ky-thuat-so','19','In nhanh kỹ thuật số','In nhanh kỹ thuật số','In nhanh kỹ thuật số','1465749474');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('50','','In thẻ nhựa','In thẻ nhựa','in-the-nhua','19','In thẻ nhựa','In thẻ nhựa','In thẻ nhựa','1465749484');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('31','','Sony','Sony','sony','17','Sony','Sony','Sony','1443935088');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('28','','Cáp sạc','Cables','cables','20','Cáp sạc','Cáp sạc','Cáp sạc','1445098340');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('27','','Tai nghe','Headphone','headphone','20','Tai nghe','Tai nghe','Tai nghe','1445098320');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('78','','Cung cấp các loại đèn Hào Quang','','','0','Cung cấp các loại đèn Hào Quang','Cung cấp các loại đèn Hào Quang','Cung cấp các loại đèn Hào Quang','1468161348');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('77','','Gia công các loại đèn LED','','','18','Gia công các loại đèn LED','Gia công các loại đèn LED','Gia công các loại đèn LED','1468161315');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('48','','In offset','In offset','in-offset','19','In offset','In offset','In offset','1465749461');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('55','','Phụ kiện khác','Other accessories','other-accessories','20','Phụ kiện khác','Phụ kiện khác','Phụ kiện khác','1445226157');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('61','','Hàng độc, hiếm','Is the rare, unique','is-the-rare-unique','24','Hàng độc, hiếm','Hàng độc, hiếm','Hàng độc, hiếm','1445966409');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('60','','Sản phẩm bán chạy','Selling products','selling-products','24','Sản phẩm bán chạy','Sản phẩm bán chạy','Sản phẩm bán chạy','1445966311');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('57','','Bàn phím & Chuột','Keyboard & Mouse','keyboard-mouse','23','Bàn phím & Chuột','Bàn phím & Chuột','Bàn phím & Chuột','1457708442');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('73','','Phụ kiện khác','Other accessories','other-accessories','23','Phụ kiện khác','Phụ kiện khác','Phụ kiện khác','1457864009');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('62','','HUB USB & USB','HUB USB & USB','hub-usb-usb','23','HUB USB & USB','HUB USB & USB','HUB USB & USB','1457863958');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('63','','Ổ cứng di động','Portable hard drives','portable-hard-drives','23','Ổ cứng di động','Ổ cứng di động','Ổ cứng di động','1457710039');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('64','','Sạc & Pin loptop','Laptop Charger & Battery','laptop-charger-battery','23','Sạc & Pin loptop','Sạc & Pin loptop','Sạc & Pin loptop','1457710163');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('65','','Thiết kế brochure','Thiết kế brochure','thiet-ke-brochure','26','Thiết kế brochure','Thiết kế brochure','Thiết kế brochure','1465749403');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('66','','Thiết kế catalogue','Thiết kế catalogue','thiet-ke-catalogue','26','Thiết kế catalogue','Thiết kế catalogue','Thiết kế catalogue','1465749414');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('67','','Thiết kế tờ rơi, leaflet','Thiết kế tờ rơi, leaflet','thiet-ke-to-roi-leaflet','26','Thiết kế tờ rơi, leaflet','Thiết kế tờ rơi, leaflet','Thiết kế tờ rơi, leaflet','1465749424');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('68','','Thiết kế menu cafe, nhà hàng','Thiết kế menu cafe, nhà hàng','thiet-ke-menu-cafe-nha-hang','26','Thiết kế menu cafe, nhà hàng','Thiết kế menu cafe, nhà hàng','Thiết kế menu cafe, nhà hàng','1465749436');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('69','','Thiết kế poster','Thiết kế poster','thiet-ke-poster','26','Thiết kế poster','Thiết kế poster','Thiết kế poster','1465749445');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('70','','Phụ kiện điện tử','Electronic Accessories','electronic-accessories','24','Phụ kiện điện tử','Phụ kiện điện tử','Phụ kiện điện tử','1446979459');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('71','','Máy tính','Computer','computer','23','Máy tính','Máy tính','Máy tính','1457863839');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('74','','In pp','In pp','in-pp','19','In pp','In pp','In pp','1465749495');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('76','','Bảng Hiệu','','','26','Bảng Hiệu','Bảng Hiệu','Bảng Hiệu','1467200190');
INSERT INTO `category` (`cate_id`,`cate_name_cn`,`cate_name_vi`,`cate_name_en`,`cate_alias`,`idTL`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('79','','Gia công các loại chữ Mica, Alu, Inox','','','18','Gia công các loại chữ Mica, Alu, Inox','Gia công các loại chữ Mica, Alu, Inox','Gia công các loại chữ Mica, Alu, Inox','1468161533');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Create Table `donhang`
--

DROP TABLE IF EXISTS `donhang`;
CREATE TABLE `donhang` (
  `idDH` int(20) NOT NULL AUTO_INCREMENT,
  `idKH` int(11) NOT NULL,
  `tongtiendh` text NOT NULL,
  `tongtienphaitra` text NOT NULL,
  `ChietKhau` text NOT NULL,
  `tongsp` int(11) NOT NULL,
  `ngaymua` int(11) NOT NULL,
  `idHTTT` tinyint(10) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`idDH`)
) ENGINE=MyISAM AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;

--
-- Data for Table `donhang`
--

/*!40000 ALTER TABLE `donhang` DISABLE KEYS */;
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('159','98','164.5','165,000 đ','','1','1460427880','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('140','84','150','150,000 đ','','1','1448518597','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('157','96','100','100,000 đ','','1','1460281675','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('158','97','150','150,000 đ','','1','1460358852','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('144','83','150','150,000 đ','','1','1449941259','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('145','87','320','320,000 đ','','2','1449975000','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('152','92','150','150,000 đ','','1','1456397926','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('154','94','150','150,000 đ','','1','1456678232','1','1');
INSERT INTO `donhang` (`idDH`,`idKH`,`tongtiendh`,`tongtienphaitra`,`ChietKhau`,`tongsp`,`ngaymua`,`idHTTT`,`status`) VALUES ('160','99','116','116,000 đ','','1','1461119236','1','1');
/*!40000 ALTER TABLE `donhang` ENABLE KEYS */;


--
-- Create Table `donhangct`
--

DROP TABLE IF EXISTS `donhangct`;
CREATE TABLE `donhangct` (
  `idDHCT` int(11) NOT NULL AUTO_INCREMENT,
  `idDH` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `tiensp` int(11) NOT NULL,
  PRIMARY KEY (`idDHCT`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Data for Table `donhangct`
--

/*!40000 ALTER TABLE `donhangct` DISABLE KEYS */;
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('36','157','88','1','125');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('19','140','74','1','150');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('38','159','116','1','235');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('37','158','99','1','150');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('31','152','74','1','150');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('23','144','73','1','150');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('33','154','74','1','150');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('24','145','105','2','320');
INSERT INTO `donhangct` (`idDHCT`,`idDH`,`sp_id`,`soluong`,`tiensp`) VALUES ('39','160','115','1','145');
/*!40000 ALTER TABLE `donhangct` ENABLE KEYS */;


--
-- Create Table `hinh_quangcao`
--

DROP TABLE IF EXISTS `hinh_quangcao`;
CREATE TABLE `hinh_quangcao` (
  `idHinh` int(11) NOT NULL AUTO_INCREMENT,
  `Url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Href` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idHinh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for Table `hinh_quangcao`
--

/*!40000 ALTER TABLE `hinh_quangcao` DISABLE KEYS */;
/*!40000 ALTER TABLE `hinh_quangcao` ENABLE KEYS */;


--
-- Create Table `hinh_thuc_thanh_toan`
--

DROP TABLE IF EXISTS `hinh_thuc_thanh_toan`;
CREATE TABLE `hinh_thuc_thanh_toan` (
  `idHTTT` tinyint(10) NOT NULL AUTO_INCREMENT,
  `Ten_HTTT_vi` text COLLATE utf8_unicode_ci NOT NULL,
  `Ten_HTTT_cn` text COLLATE utf8_unicode_ci NOT NULL,
  `Ten_HTTT_en` text COLLATE utf8_unicode_ci NOT NULL,
  `ten_khong_dau` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idHTTT`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `hinh_thuc_thanh_toan`
--

/*!40000 ALTER TABLE `hinh_thuc_thanh_toan` DISABLE KEYS */;
INSERT INTO `hinh_thuc_thanh_toan` (`idHTTT`,`Ten_HTTT_vi`,`Ten_HTTT_cn`,`Ten_HTTT_en`,`ten_khong_dau`) VALUES ('1','Thanh toán khi nhận hàng','貨到現金','Payment on delivery','');
INSERT INTO `hinh_thuc_thanh_toan` (`idHTTT`,`Ten_HTTT_vi`,`Ten_HTTT_cn`,`Ten_HTTT_en`,`ten_khong_dau`) VALUES ('2','Thanh toán qua ngân hàng','銀行匯款','Payment by bank','');
/*!40000 ALTER TABLE `hinh_thuc_thanh_toan` ENABLE KEYS */;


--
-- Create Table `hinhanh_home`
--

DROP TABLE IF EXISTS `hinhanh_home`;
CREATE TABLE `hinhanh_home` (
  `idHinh` int(20) NOT NULL AUTO_INCREMENT,
  `Url` text COLLATE utf8_unicode_ci NOT NULL,
  `Href` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idLoai` int(11) NOT NULL,
  PRIMARY KEY (`idHinh`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `hinhanh_home`
--

/*!40000 ALTER TABLE `hinhanh_home` DISABLE KEYS */;
INSERT INTO `hinhanh_home` (`idHinh`,`Url`,`Href`,`idLoai`) VALUES ('37','upload/images/Hinh%20anh%20slide/banghieu%20chunoi.jpg','#','1');
INSERT INTO `hinhanh_home` (`idHinh`,`Url`,`Href`,`idLoai`) VALUES ('38','upload/images/Hinh%20anh%20slide/banghieu%20hiflex.jpg','#','1');
INSERT INTO `hinhanh_home` (`idHinh`,`Url`,`Href`,`idLoai`) VALUES ('39','upload/images/Hinh%20anh%20slide/catbien.jpg','#','1');
INSERT INTO `hinhanh_home` (`idHinh`,`Url`,`Href`,`idLoai`) VALUES ('40','upload/images/Hinh%20anh%20slide/laudeanhviet.jpg','#','1');
INSERT INTO `hinhanh_home` (`idHinh`,`Url`,`Href`,`idLoai`) VALUES ('41','upload/images/Hinh%20anh%20slide/opalu_nhathuoc.jpg','#','1');
/*!40000 ALTER TABLE `hinhanh_home` ENABLE KEYS */;


--
-- Create Table `khachhang`
--

DROP TABLE IF EXISTS `khachhang`;
CREATE TABLE `khachhang` (
  `idKH` int(11) NOT NULL AUTO_INCREMENT,
  `hoten` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `dienthoai` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `ngaysinh` text NOT NULL,
  `ngaydangky` text NOT NULL,
  `tongtien` int(30) NOT NULL,
  `lanmuacuoi` int(11) NOT NULL,
  `solanmua` int(11) NOT NULL,
  PRIMARY KEY (`idKH`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

--
-- Data for Table `khachhang`
--

/*!40000 ALTER TABLE `khachhang` DISABLE KEYS */;
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('57','Nguyễn tấn phương','phuong.ltweb@gmail.com','e5c89ef4446aca1e22e3391b97353cc9','12456798233','Chuồng vịt','10/10/2010','1438314638','67570','1455594478','42');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('80','Tonys','lqdat09@gmail.com','55860f6ac46c39aa9fa2a9973fa0c980','01663833222','272 le duc tho, p6, go vap','10/10/1990','1446476395','0','1460014142','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('71','Quoc Tay','lamdatlang90@gmail.com','55860f6ac46c39aa9fa2a9973fa0c980','0903397104','272 Le Duc Tho, P6, GO Vap','05/01/1990','1446298861','0','0','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('84','Hà Trọng Phú','trongphu020@gmail.com','0114d2368b7f9051a3541568857d24fe','0965668720','tổ 25, khu Cao Đại, phường Minh Phương, thành phố Việt Trì, tỉnh Phú Thọ','','1448518597','150','1448518597','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('83','LÊ QUANG TUYẾN','quangtuyen62cntt@gmail.com','017db0b7ee650e84d45898e6b4d126b0','0909979049','538 Trường Chinh, Tp. Pleiku, Gia Lai','19/07/1986','1447557576','440','1449941259','5');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('85','Lâm văn Sang','lmvsag@gmail.com','98cf78f71da2adc2b913554ce573e86a','0909969040','4c/12a Phạm Hùng. P4. Q8. TpHCM','','1448536843','100','1448793220','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('86','Nguyễn Phú Vĩnh Thụy','vinhthuydltt@gmail.com','bb5a4367a0a6538cdeaaf4024bf84ebb','0945443588','177 Phổ Quang, P2, Q.Tân Bình, Tp.HCM','','1448938160','0','1448938160','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('87','Nghiem Michael','michaelnghiem1987@gmail.com','f10b1fa83661d327c6a5a621bfcb8a4e','0908955455','So 4 Duong so 1 KDC Song ONG Lon, Binh Hung, Huyen Binh Chanh','','1449975000','320','1449975000','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('88','tung','tung2171989@gmail.com','c6e8173d67ef51132f4214b3845164f7','01208282019','138138/5 duy tan f15 quan phu nhuan','21/07/1989','1450332286','0','1450332396','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('89','BUI MINH TAM','minhtam18051987@gmail.com','6c4f347e634781e4c376ae5f1a5e3267','0939739639','44 ngô quyền phường Hiệp Phú Quận 9 tp Hồ Chí Minh','','1454160982','0','1454160982','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('90','Lý Hoàng Đẳng','tmtien.qt13cd@gmail.com','d33c928e970a02babfa9dce865b77f33','01694266638','Tiệm Bánh Bao Thanh Long 1, Ấp 3, Xã Phước Thái, Huyện Long Thành, Tỉnh Đồng Nai','16/01/1995','1455530482','140','1455889998','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('91','Nguyễn Thành Đức','ducnt@matbao.com','5fae0f311b459fd322b26bed82166ac2','0909584530','171A Hoàng Hoa Thám, phường 13, quận Tân Bình - chung cư Carillon','','1455616556','0','1455616556','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('92','nguyen van truong','trai89chuabietyeuhd@gmail.com','323c6806f08916998c0534b9302fe2c5','01637488723','297 khu 4 phuong viet hoa tp hai duong tinh hai duong','','1456397926','150','1456397926','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('93','Nguyễn Hoàng Yến Linh','tieualinh123@yahoo.com.vn','0a752608ea50ce3b167ba6b9ca209ff4','01673741191','Ấp Long Điền , Xã Long Hoà , Huyện Dầu Tiếng , Tỉnh Bình Dương','','1456677533','0','1456677533','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('94','Lê Phương Hải','lephuonghai1982@yahoo.com.vn','318e9137eccf10414ab7bb4a07ad90ab','0982399924','39 Nguyễn Văn Trỗi, KV1, Phường 3, TP Vị Thanh - Hậu Giang','','1456678232','150','1456678232','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('95','Huỳnh tuấn anh','huynhtuananh1991@gmail.com','331661db2b8ca399226f98a9df4562fe','01217171665','14/1/16 a đường nguyễn thị định ( đường số 3) khu phố 1 phuòng thạnh mỹ lợi quận 2','','1457000860','0','1457000860','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('96','phan Nguyen','binhngoc999@gmail.com','17c342e7840e96bc66a57b6377242046','0932128012','119b/55 Nguyen thi tan p2 q8','','1460281675','100','1460281675','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('97','Lâm thanh Sang','beovannheo130991@gmail.com','83e76404eef7f9b0d71a523e0ce8c439','0914666637','28-Hùng Vương-P5-Tp. Cà mau','','1460358852','150','1460358852','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('98','võ thị thu ngân','vothithungan1997@yahoo.com','e05c11e65df060f01d37542d3d5231d4','0978182531','ấp 2,xã mỹ yên, huyện bến lức, tỉnh long an','08/06/1997','1460427834','165','1460427880','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('99','Trần Lê Dũng','mrpupa26@gmail.com','a22380e85e7677511b87e9f06d28cb31','01286131710','118/83/A3 Bạch Đằng phường 24 quận bình thạnh','','1461119236','116','1461119236','1');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('100','Hoang Minh Chien','chienpvnt2@gmail.com','8629e08d0c11a1437a149eb7330ceea9','0975070873','9/22/7/37 duong 898, phuong Phu Huu, quan 9, tp Ho Chi Minh','','1461123796','0','1461123796','0');
INSERT INTO `khachhang` (`idKH`,`hoten`,`email`,`password`,`dienthoai`,`diachi`,`ngaysinh`,`ngaydangky`,`tongtien`,`lanmuacuoi`,`solanmua`) VALUES ('101','Gia du','kelygirl123@gmail.com','96a0eca2322730fd34502fcb08d44b72','0935242033','207 đỗ ngọc thạnh q11','','1461296658','0','1461296658','0');
/*!40000 ALTER TABLE `khachhang` ENABLE KEYS */;


--
-- Create Table `khachhang_tienich`
--

DROP TABLE IF EXISTS `khachhang_tienich`;
CREATE TABLE `khachhang_tienich` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idKH` int(11) NOT NULL,
  `idTienich` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=latin1;

--
-- Data for Table `khachhang_tienich`
--

/*!40000 ALTER TABLE `khachhang_tienich` DISABLE KEYS */;
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('5','55','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('6','70','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('7','70','2');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('8','70','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('9','70','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('11','70','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('12','70','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('14','70','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('15','71','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('16','71','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('20','71','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('21','71','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('24','71','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('25','66','23');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('27','71','25');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('28','71','26');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('30','71','28');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('31','71','29');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('32','71','30');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('43','57','41');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('44','74','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('45','74','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('46','74','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('47','74','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('48','74','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('49','74','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('51','74','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('52','74','2');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('53','74','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('54','75','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('55','75','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('56','75','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('57','75','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('58','75','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('59','75','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('60','75','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('61','75','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('63','75','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('64','75','42');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('65','75','43');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('66','75','44');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('67','75','45');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('68','76','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('69','76','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('70','76','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('71','76','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('72','76','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('73','76','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('74','76','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('75','76','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('77','76','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('78','76','46');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('79','76','47');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('80','76','48');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('81','77','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('82','77','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('83','77','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('84','77','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('85','77','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('86','77','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('87','77','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('88','77','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('90','77','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('91','77','49');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('92','77','50');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('93','78','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('94','78','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('95','78','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('96','78','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('97','78','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('98','78','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('99','78','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('100','78','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('102','78','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('103','78','51');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('104','78','52');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('105','78','53');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('106','79','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('107','79','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('108','79','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('109','79','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('110','79','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('111','79','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('112','79','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('113','79','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('115','79','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('116','79','54');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('117','79','55');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('118','79','56');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('119','80','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('120','80','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('122','80','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('123','80','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('124','80','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('125','80','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('126','80','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('130','80','58');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('131','80','59');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('132','80','60');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('133','80','61');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('134','80','62');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('135','80','63');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('136','80','64');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('137','80','65');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('139','80','67');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('140','80','68');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('141','81','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('142','81','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('143','81','9');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('144','81','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('145','81','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('146','81','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('147','81','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('148','81','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('150','81','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('151','81','69');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('152','81','70');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('153','80','72');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('154','80','73');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('155','80','74');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('156','80','75');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('157','80','76');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('158','88','71');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('159','88','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('160','88','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('161','88','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('162','88','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('163','88','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('164','88','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('165','88','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('166','88','2');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('167','88','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('168','80','78');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('169','90','71');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('170','90','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('171','90','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('172','90','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('173','90','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('174','90','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('175','90','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('176','90','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('177','90','2');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('178','90','1');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('179','98','71');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('180','98','11');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('181','98','10');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('182','98','8');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('183','98','7');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('184','98','6');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('185','98','4');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('186','98','3');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('187','98','2');
INSERT INTO `khachhang_tienich` (`id`,`idKH`,`idTienich`) VALUES ('188','98','1');
/*!40000 ALTER TABLE `khachhang_tienich` ENABLE KEYS */;


--
-- Create Table `khoanggia`
--

DROP TABLE IF EXISTS `khoanggia`;
CREATE TABLE `khoanggia` (
  `kg_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `giatu` int(11) NOT NULL,
  `giaden` int(11) NOT NULL,
  `thutu` smallint(6) NOT NULL,
  PRIMARY KEY (`kg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Data for Table `khoanggia`
--

/*!40000 ALTER TABLE `khoanggia` DISABLE KEYS */;
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('1','0','1000000','1');
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('2','1000000','5000000','2');
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('3','5000000','10000000','3');
INSERT INTO `khoanggia` (`kg_id`,`giatu`,`giaden`,`thutu`) VALUES ('4','10000000','50000000','4');
/*!40000 ALTER TABLE `khoanggia` ENABLE KEYS */;


--
-- Create Table `loai_article`
--

DROP TABLE IF EXISTS `loai_article`;
CREATE TABLE `loai_article` (
  `idLoai` int(11) NOT NULL AUTO_INCREMENT,
  `Ten_vi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Ten_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idLoai`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `loai_article`
--

/*!40000 ALTER TABLE `loai_article` DISABLE KEYS */;
INSERT INTO `loai_article` (`idLoai`,`Ten_vi`,`Ten_en`,`ten_alias`) VALUES ('1','Tin công ty','Company news','tin-cong-ty');
INSERT INTO `loai_article` (`idLoai`,`Ten_vi`,`Ten_en`,`ten_alias`) VALUES ('2','Tin chuyên nghành','Technology News','tin-chuyen-nghanh');
/*!40000 ALTER TABLE `loai_article` ENABLE KEYS */;


--
-- Create Table `loai_hinh`
--

DROP TABLE IF EXISTS `loai_hinh`;
CREATE TABLE `loai_hinh` (
  `idLoai` int(11) NOT NULL AUTO_INCREMENT,
  `TenLoai` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Ten_Khong_Dau` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idLoai`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data for Table `loai_hinh`
--

/*!40000 ALTER TABLE `loai_hinh` DISABLE KEYS */;
INSERT INTO `loai_hinh` (`idLoai`,`TenLoai`,`Ten_Khong_Dau`) VALUES ('1','Hình Slide Home','hinh-slide-home');
INSERT INTO `loai_hinh` (`idLoai`,`TenLoai`,`Ten_Khong_Dau`) VALUES ('2','Hình quảng cáo Left','hinh-quang-cao-left');
/*!40000 ALTER TABLE `loai_hinh` ENABLE KEYS */;


--
-- Create Table `loaiuser`
--

DROP TABLE IF EXISTS `loaiuser`;
CREATE TABLE `loaiuser` (
  `idLoai` tinyint(10) NOT NULL AUTO_INCREMENT,
  `TenLoaiUser` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idLoai`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `loaiuser`
--

/*!40000 ALTER TABLE `loaiuser` DISABLE KEYS */;
INSERT INTO `loaiuser` (`idLoai`,`TenLoaiUser`) VALUES ('1','Administrator\r\n');
INSERT INTO `loaiuser` (`idLoai`,`TenLoaiUser`) VALUES ('2','Admin');
INSERT INTO `loaiuser` (`idLoai`,`TenLoaiUser`) VALUES ('3','Nhân viên');
/*!40000 ALTER TABLE `loaiuser` ENABLE KEYS */;


--
-- Create Table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(255) NOT NULL,
  `menu_alias` varchar(255) NOT NULL,
  `article_id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `update_time` int(11) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Data for Table `menu`
--

/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('2','Giới thiệu','gioi-thieu','1','1','1378853240','Giới thiệu','Giới thiệu','Giới thiệu');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('3','Dịch vụ','dich-vu','2','1','1378853295','Dịch vụ','Dịch vụ','Dịch vụ');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('4','Khuyến mãi','khuyen-mai','3','1','1378853277','Khuyến mãi','Khuyến mãi','Khuyến mãi');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('5','Hỗ trợ - tư vấn','ho-tro-tu-van','4','1','1378853290','Hỗ trợ - tư vấn','Hỗ trợ - tư vấn','Hỗ trợ - tư vấn');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;


--
-- Create Table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name_vi` varchar(255) NOT NULL,
  `product_name_en` varchar(255) NOT NULL,
  `product_alias` varchar(255) NOT NULL,
  `price` varchar(20) NOT NULL,
  `HinhDaiDien` text NOT NULL,
  `url_images` varchar(255) NOT NULL,
  `mota_en` text NOT NULL,
  `mota_vi` text NOT NULL,
  `content_vi` text NOT NULL,
  `content_en` text NOT NULL,
  `category_id` varchar(255) NOT NULL,
  `idTL` int(50) NOT NULL,
  `kg_id` tinyint(11) NOT NULL,
  `khuyenmai_id` tinyint(11) NOT NULL,
  `idThuongHieu` tinyint(11) NOT NULL,
  `idTinhTrang` int(11) NOT NULL,
  `NgayDang` int(11) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Data for Table `product`
--

/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('3','Bang điện tử 1 màu P10','','bang-dien-tu-1-mau-p10','','upload/images/IMAG0197.jpg','','','','<p>Bang điện tử 1 m&agrave;u</p>\r\n','','41','18','0','0','0','0','1472380964');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('4','Bảng hiệu Hiflex','','bang-hieu-hiflex','','upload/images/Hinh%20san%20pham/IMAG0067.jpg','','','','<p>Bảng hiệu Hiflex</p>\r\n','','40','18','0','0','0','0','1472381162');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('5','Bang hiệu Hiflex','','bang-hieu-hiflex','','upload/images/Hinh%20san%20pham/IMAG0079.jpg','','','bang3 hiệu Hiflex dày 3.2mm, khung sắt v20 mạ kẽm ','<p>Bảng hiệu hiflex</p>\r\n','','40','18','0','0','0','0','1472381296');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('6','Bảng hiệu Hiflex','','bang-hieu-hiflex','','upload/images/Hinh%20san%20pham/IMAG0078.jpg','','','','<p>Bảng hiệu hiflex&nbsp;</p>\r\n','','40','18','0','0','0','0','1472381434');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('7','Hộp đèn Hiflex','','hop-den-hiflex','','upload/images/Hinh%20san%20pham/IMAG0097.jpg','','','','<p><strong>Ứng dụng Hiflex</strong></p>\r\n\r\n<p>Hộp đ&egrave;n Hiflex quảng c&aacute;o l&agrave; một sự lựa chọn kh&ocirc;ng c&ograve;n lạ trong thiết kế bảng hiệu. Bởi t&iacute;nh nổi bật của n&oacute; m&agrave; được nhiều chủ doanh nghiệp lựa chọn đặc biệt trong c&aacute;c dịch vụ kinh doanh kh&aacute;ch sạn, nh&agrave; h&agrave;ng, qu&aacute;n ăn...</p>\r\n\r\n<p>Ng&agrave;y nay c&oacute; nhiều chất liệu mới xuất hiện v&agrave; biển quảng c&aacute;o hộp đ&egrave;n cũng c&oacute; nhiều mẫu m&atilde; mới. Nhưng biển quảng c&aacute;o hộp đ&egrave;n đơn giản nhất, v&agrave; cũng c&oacute; thể n&oacute;i l&agrave; phổ biến nhất, l&agrave; loại biển được l&agrave;m bằng kết cấu khung xương sắt hộp cộng với bạt Hiflex xuy&ecirc;n s&aacute;ng.</p>\r\n\r\n<p>V&agrave;o thời điểm ban ng&agrave;y, biển quảng c&aacute;o hộp đ&egrave;n Hiflex cũng đ&oacute;ng vai tr&ograve; giống như biển pano Hiflex b&igrave;nh thường. Khi trời tối, chỉ cần cắm điện l&agrave; biển hộp đ&egrave;n sẽ tỏa s&aacute;ng, đem lại những ấn tượng quảng c&aacute;o mạnh mẽ, gi&uacute;p cho những cửa h&agrave;ng, cửa hiệu th&ecirc;m lung linh v&agrave; nhiều sắc m&agrave;u về đ&ecirc;m.</p>\r\n\r\n<p>Ưu điểm lớn nhất của h&igrave;nh thức d&ugrave;ng chất liệu Hiflex xuy&ecirc;n s&aacute;ng l&agrave;m bảng hiệu hộp đ&egrave;n l&agrave;: Chi ph&iacute; kh&ocirc;ng qu&aacute; lớn v&agrave;o dạng rẻ nhất trong c&aacute;c chất liệu chuy&ecirc;n d&ugrave;ng l&agrave;m biển quảng c&aacute;o. Mặt kh&aacute;c độ bền cao v&agrave; m&agrave;u sắc n&eacute;t.</p>\r\n','','40','18','0','0','0','0','1472381758');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('8','Hộp đèn mica dán decal','','hop-den-mica-dan-decal','','upload/images/Hinh%20san%20pham/IMAG0248.jpg','','','','<p><em>Bảng hiệu mica,&nbsp;<a href=\"http://dangquangad.com/huong-dan-cach-lam-hop-den-mica-dan-decal/\" target=\"_blank\">hộp đ&egrave;n mica hay hộp đ&egrave;n mica d&aacute;n decal</a></em>hiện nay được sử dụng kh&aacute; rộng r&atilde;i trong lĩnh vực&nbsp;<em>kinh doanh c&ocirc;ng ty, qu&aacute;n cafe, shop thời trang.</em></p>\r\n','','40','18','0','0','0','0','1472382081');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('9','Hộp đèn LED','','hop-den-led','','upload/images/Hinh%20san%20pham/IMAG0239.jpg','','','','<h2><strong>L&agrave;m bảng hiệu</strong>&nbsp;đ&egrave;n Led</h2>\r\n\r\n<p><strong>L&agrave;m bảng hiệu</strong>&nbsp;đ&egrave;n led cho hiệu quả quảng c&aacute;o nhanh, thuận tiện, g&acirc;y ch&uacute; &yacute; cao đối với c&aacute;c kh&aacute;ch h&agrave;ng l&agrave; người đi đường.<strong>L&agrave;m bảng hiệu</strong>&nbsp;đ&egrave;n led cho hiệu quả sữ dụng cả ban ng&agrave;y v&agrave; ban đ&ecirc;m, với độ s&aacute;ng l&ecirc;n tới h&agrave;ng ng&agrave;n K v&agrave; c&oacute; thể điều chỉnh mọi hiệu ứng chớp tắt, chuyển m&agrave;u.</p>\r\n\r\n<p><strong>L&agrave;m bảng hiệu</strong>&nbsp;đ&egrave;n led thường l&agrave; những bảng hiệu nhỏ, bảng hiệu c&aacute;nh g&agrave;. C&aacute;c hiệu ứng chạy, chớp tắt, s&aacute;ng mờ, s&aacute;ng rực sẽ c&oacute; hiệu quả ngay với những kh&aacute;ch h&agrave;ng nh&igrave;n từ xa.</p>\r\n','','40','18','0','0','0','0','1472382306');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('10','Hộp đèn LED','','hop-den-led','','upload/images/Hinh%20san%20pham/IMAG0205.jpg','','','','<p>Gia c&ocirc;ng c&aacute;c loại đ&egrave;n LED, h&agrave;o qu&agrave;ng, bảng hiệu gi&aacute; rẻ</p>\r\n','','77','18','0','0','0','0','1472382438');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('11','Bảng hiệu decal dán tôn, chữ nổi có đèn','','bang-hieu-decal-dan-ton-chu-noi-co-den','','upload/images/Hinh%20san%20pham/IMAG0179.jpg','','','','<p><strong>Decal là gì?</strong>&nbsp;<strong>Decal</strong>&nbsp;là m&ocirc;̣t loại nhãn có tráng sẳn lớp keo thường dùng đ&ecirc;̉ in vì có đ&ocirc;̣ bám mực cực t&ocirc;́t khi sử dụng ta chỉ c&acirc;̀n l&ocirc;̣t lớp gi&acirc;́y ra có mặt keo và dán vào sản ph&acirc;̉m là được.<br />\r\n<strong>Bảng tole dán deca</strong>l: sử dụng tole d&acirc;̀y 0.4 &ndash; 0.8mm căng tr&ecirc;n khung sắt vu&ocirc;ng 20 &ndash; 30 , sơn ch&ocirc;́ng rỉ , vi&ecirc;̀n V thanh nh&ocirc;m , dán n&ocirc;̣i dung bằng&nbsp;<strong>decal ngoài trời</strong>.</p>\r\n','','40','18','0','0','0','0','1472382667');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('12','Chữ nổi mica','','chu-noi-mica','','upload/images/Hinh%20san%20pham/IMAG0180.jpg','','','','<p><strong>Chữ nổi mica l&agrave; g&igrave;?</strong><br />\r\nĐ&acirc;y l&agrave; vật liệu phổ biến nhất trong&nbsp;<strong>chữ nổi</strong>, do c&oacute; nhiều m&agrave;u sắc, dễ gia c&ocirc;ng, gi&aacute; th&agrave;nh thấp. Thường được d&ugrave;ng tr&ecirc;n c&aacute;c biển Alu ngo&agrave;i trời</p>\r\n\r\n<p><strong>Chữ nổi</strong>&nbsp;hay c&ograve;n gọi l&agrave;&nbsp;<strong>chữ 3D</strong>, chất liệu mica, đồng, inox&hellip;được cắt bằng c&ocirc;ng nghệ CNC v&agrave; laser, thường gắn liền với h&igrave;nh thức&nbsp;<a href=\"http://www.thanhthinhphat.com/dich-vu-hcm/lam-bang-hieu-gia-re-hcm/bang-hieu-quang-cao-gia-re\"><strong>bảng quảng c&aacute;o gi&aacute; rẻ</strong></a>&nbsp;ốp Alu hoặc Hiflet.</p>\r\n\r\n<p>Đ&acirc;y l&agrave; h&igrave;nh thức&nbsp;biển quảng c&aacute;o&nbsp;th&ocirc;ng dụng, thường được kết hợp với biển ốp Alu hoặc l&agrave;m logo, slogan&hellip;.</p>\r\n\r\n<p>Chất liệu chủ yếu l&agrave; mica, inox, đồng, foamex, gỗ&hellip;, c&oacute; thể kết hợp với c&ocirc;ng nghệ đ&egrave;n led, neonsign tạo sự nổi bật khi trời tối.</p>\r\n\r\n<p>Thanh Thịnh Ph&aacute;t 2 sử dụng c&ocirc;ng nghệ laser, cnc trong việc gia c&ocirc;ng chữ, tạo độ ch&iacute;nh x&aacute;c cao, sắc n&eacute;t.&nbsp;</p>\r\n\r\n<p><strong>Đặc đi&ecirc;̉m của chữ nổi mica:</strong><br />\r\nĐộ cứng cao, &iacute;t ảnh hưởng bởi thay nhiệt độ m&ocirc;i trường n&ecirc;n t&ocirc;n v&agrave; alumi thường được sử dụng cho c&aacute;c bộ chữ nổi c&oacute; k&iacute;ch thước lớn (cao tr&ecirc;n 100cm) đặt tr&ecirc;n c&aacute;c đỉnh t&ograve;a nh&agrave; cao tầng.</p>\r\n\r\n<p>Do thường lắp đặt vị tr&iacute; cao n&ecirc;n chữ thường được kết hợp với đ&egrave;n neonsign tạo hiệu quả chiếu s&aacute;ng khi trời tối</p>\r\n\r\n<p><strong>Chữ Nổi, Chữ hộp, Logo, Trang tr&iacute; kh&aacute;c:&nbsp;</strong><br />\r\nChất liệu Mica, d&agrave;y 2-5 (mm), Cắt th&agrave;nh h&igrave;nh chữ, logo&hellip;.&nbsp;<br />\r\nUốn ch&acirc;n chữ cao từ 10-200 (mm).&nbsp;</p>\r\n','','79','18','0','0','0','0','1472382873');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('13','Brochure thẩm mỹ','','brochure-tham-my','','upload/images/Hinh%20san%20pham/mylinh.jpg','','','','<p><b>Brochure</b>&nbsp;l&agrave; một dạng ấn phẩm&nbsp;<a href=\"https://vi.wikipedia.org/wiki/Qu%E1%BA%A3ng_c%C3%A1o\" title=\"Quảng cáo\">quảng c&aacute;o</a>&nbsp;(c&oacute; thể hiểu n&ocirc;m na l&agrave; một quyển s&aacute;ch nhỏ v&agrave; mỏng hay một tập s&aacute;ch) chứa đựng v&agrave; bao gồm những&nbsp;<a href=\"https://vi.wikipedia.org/wiki/Th%C3%B4ng_tin\" title=\"Thông tin\">th&ocirc;ng tin</a>&nbsp;giới thiệu chung về sản phẩm n&agrave;o đấy, về c&aacute;c sự kiện, những địa điểm&nbsp;<a href=\"https://vi.wikipedia.org/wiki/Du_l%E1%BB%8Bch\" title=\"Du lịch\">du lịch</a>&nbsp;nổi tiếng, h&igrave;nh ảnh&hellip; m&agrave; nh&agrave;<a href=\"https://vi.wikipedia.org/wiki/Thi%E1%BA%BFt_k%E1%BA%BF\" title=\"Thiết kế\">thiết kế</a>&nbsp;/ cung cấp Brochure muốn gửi gắm đến những người được xem l&agrave;&nbsp;<a href=\"https://vi.wikipedia.org/wiki/Kh%C3%A1ch_h%C3%A0ng\" title=\"Khách hàng\">kh&aacute;ch h&agrave;ng</a>&nbsp;mục ti&ecirc;u của họ. Brochure được gọi một c&aacute;ch việt h&oacute;a l&agrave;&nbsp;<b>tờ gấp quảng c&aacute;o</b></p>\r\n','','65','26','0','0','0','0','1472383080');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('14','Poster nước đá Pha Lê','','poster-nuoc-da-pha-le','','upload/images/Hinh%20san%20pham/phalesas.jpg','','','','<h2>Poster l&agrave; g&igrave;?</h2>\r\n\r\n<p><br />\r\nC&acirc;u hỏi<strong>&nbsp;Poster&nbsp;l&agrave; g&igrave;&nbsp;</strong>c&oacute; lẽ kh&ocirc;ng kh&oacute; trả lời.&nbsp;Poster l&agrave; một t&aacute;c phẩm nghệ thuật, được thiết kế th&ocirc;ng qua c&aacute;c thủ ph&aacute;p tạo h&igrave;nh mang t&iacute;nh thẩm mỹ cao nhằm mục đ&iacute;ch truyền đạt đến người xem qua k&ecirc;nh thị gi&aacute;c những th&ocirc;ng tin về một sản phẩm, một sự kiện hay một vấn đề g&igrave; đ&oacute;. H&agrave;ng ng&agrave;y ch&uacute;ng ta c&oacute; thể bắt gặp rất nhiều&nbsp;<strong>P</strong><strong>oster</strong>&nbsp;kh&aacute;c nhau nhưng nh&igrave;n chung<strong>&nbsp;Poster&nbsp;</strong>được chia l&agrave;m 3 loại:</p>\r\n\r\n<p>-&nbsp;<strong>Poster</strong>&nbsp;nhằm mục đ&iacute;ch quảng c&aacute;o: c&aacute;c&nbsp;<strong>poster</strong>&nbsp;quảng c&aacute;o lớn tại c&aacute;c nơi c&ocirc;ng cộng, poster đ&iacute;nh k&egrave;m sản phẩm&hellip;</p>\r\n\r\n<p>&nbsp;<strong>Poster&nbsp;</strong>nghệ thuật: chủ yếu thể hiện &yacute; tưởng của nh&agrave; thiết kế đồ họa.</p>\r\n\r\n<p>-&nbsp;<strong>Poster</strong>&nbsp;th&ocirc;ng tin cộng đồng: poster sự kiện,<strong>&nbsp;poste</strong>r phim, poster người nổi tiếng,&nbsp;<strong>poster</strong>&nbsp;tuy&ecirc;n truyền, cổ động...</p>\r\n\r\n<p><strong>Thiết kế poster&nbsp;</strong>l&agrave; một lĩnh vực s&aacute;ng tạo nghệ thuật thị gi&aacute;c n&ecirc;n đ&ograve;i hỏi người thiết kế phải thể hiện được tư duy, &yacute; tưởng s&aacute;ng tạo của m&igrave;nh th&ocirc;ng qua c&aacute;c thủ ph&aacute;p thể hiện nhưng vẫn đảm bảo c&aacute;c gi&aacute; trị th&ocirc;ng tin v&agrave; hiệu quả truyền đạt.</p>\r\n\r\n<p>Vị tr&iacute; tr&igrave;nh b&agrave;y của<strong>&nbsp;Poster</strong>&nbsp;thường l&agrave; những nơi c&ocirc;ng cộng v&agrave; đối tượng thưởng thức l&agrave; c&ocirc;ng ch&uacute;ng mọi tầng lớp trong x&atilde; hội n&ecirc;n th&ocirc;ng tin của Poster d&ugrave; được phản &aacute;nh trực tiếp hay gi&aacute;n tiếp đều phải s&uacute;c t&iacute;ch, đơn giản, dễ d&agrave;ng nhận biết ghi nhớ v&agrave; mang t&iacute;nh đại ch&uacute;ng cao nhất.</p>\r\n\r\n<h2>C&ocirc;ng việc thiết kế poster quảng c&aacute;o</h2>\r\n\r\n<p>Ng&agrave;y nay, nền kinh tế h&agrave;ng h&oacute;a ph&aacute;t triển th&igrave; nhu cầu th&ocirc;ng tin, quảng c&aacute;o sự kiện, sản phẩm đến với x&atilde; hội, với người ti&ecirc;u d&ugrave;ng ng&agrave;y c&agrave;ng nhiều n&ecirc;n việc&nbsp;thiết kế&nbsp;v&agrave; tr&igrave;nh b&agrave;y&nbsp;<strong>Poster</strong>&nbsp;cho c&aacute;c ng&agrave;nh c&ocirc;ng thương nghiệp c&agrave;ng ph&aacute;t triển v&agrave; cụm từ<strong>&nbsp;Poster quảng c&aacute;o</strong>&nbsp;đ&atilde; trở n&ecirc;n quen thuộc v&agrave; th&ocirc;ng dụng đối với người thiết kế v&agrave; c&ocirc;ng ch&uacute;ng.</p>\r\n\r\n<p><strong>Poster quảng c&aacute;o</strong>&nbsp;thường được in với diện t&iacute;ch lớn, được thiết kế đa dạng về m&agrave;u sắc, ng&ocirc;n ngữ tạo h&igrave;nh, phong ph&uacute; về h&igrave;nh thức bố cục, t&ugrave;y theo &yacute; tưởng của nh&agrave; thiết kế v&agrave;o từng loại sản phẩm hay sự kiện.</p>\r\n\r\n<p>Chức năng ch&iacute;nh của&nbsp;<strong>Poster&nbsp;</strong>l&agrave; th&ocirc;ng qua diện t&iacute;ch thiết kế phải truyền đạt đến người xem th&ocirc;ng điệp mang &yacute; nghĩa li&ecirc;n quan đến nội dung sản phẩm qua h&igrave;nh ảnh, nội dung c&acirc;u chữ bi&ecirc;n tập, m&agrave;u sắc hay qua c&aacute;c &yacute; nghĩa ẩn dụ b&ecirc;n trong.</p>\r\n\r\n<p>Ng&ocirc;n ngữ đồ hoạ tr&ecirc;n&nbsp;<strong>Poster&nbsp;</strong>phải c&oacute; hiệu quả thị gi&aacute;c mạnh:&nbsp; sử dụng c&aacute;c gam m&agrave;u tương phản, bố cục, với c&aacute;c h&igrave;nh thể đối lập, sử dụng h&igrave;nh ảnh ấn tượng, dễ tiếp cận.&nbsp;<strong>Thiết kế poster&nbsp;</strong>cần nhiều sự s&aacute;ng tạo trong c&aacute;ch thể hiện, t&iacute;nh thẩm mỹ trong sắp xếp h&igrave;nh ảnh, nghệ thuật font chữ, bố cục h&igrave;nh nền, c&aacute;c mảng ch&iacute;nh, phụ&hellip;</p>\r\n\r\n<p>T&oacute;m lại, để c&oacute; thể cho ra đời những&nbsp;<strong>poster</strong>&nbsp;ấn tượng, đặc biệt l&agrave; poster quảng c&aacute;o, nh&agrave; thiết kế đồ họa kh&ocirc;ng phải chỉ đầu tư chuy&ecirc;n m&ocirc;n m&agrave; c&ograve;n cả sự s&aacute;ng tạo rất lớn nhằm chuyển tải th&ocirc;ng điệp đến người xem một c&aacute;ch thu h&uacute;t nhất. Trong bối cảnh hiện nay, khi sự cạnh tranh trong kinh doanh lu&ocirc;n l&agrave; yếu tố được ch&uacute; trọng, c&ocirc;ng việc thiết kế<strong>poster quảng c&aacute;o</strong>&nbsp;sẽ hứa hẹn l&agrave; một lĩnh vực &ldquo;m&agrave;u mỡ&rdquo; cho c&aacute;c nh&agrave; thiết kế trẻ.&nbsp;</p>\r\n','','69','26','0','0','0','0','1472383719');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('15','Hộp đèn LED','','hop-den-led','','upload/images/Hinh%20san%20pham/IMAG0239.jpg','','','','','','77','18','0','0','0','0','1472384067');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('16','Chữ nổi mica','','chu-noi-mica','','upload/images/Hinh%20san%20pham/IMAG0203.jpg','','','','','','79','18','0','0','0','0','1472384126');
INSERT INTO `product` (`product_id`,`product_name_vi`,`product_name_en`,`product_alias`,`price`,`HinhDaiDien`,`url_images`,`mota_en`,`mota_vi`,`content_vi`,`content_en`,`category_id`,`idTL`,`kg_id`,`khuyenmai_id`,`idThuongHieu`,`idTinhTrang`,`NgayDang`) VALUES ('17','Chữ nổi mica','','chu-noi-mica','','upload/images/Hinh%20san%20pham/IMAG0189.jpg','','','','','','79','18','0','0','0','0','1472384201');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;


--
-- Create Table `quocgia`
--

DROP TABLE IF EXISTS `quocgia`;
CREATE TABLE `quocgia` (
  `idQuocGia` tinyint(20) NOT NULL AUTO_INCREMENT,
  `TenQuocGia_cn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenQuocGia_vi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenQuocGia_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idQuocGia`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `quocgia`
--

/*!40000 ALTER TABLE `quocgia` DISABLE KEYS */;
INSERT INTO `quocgia` (`idQuocGia`,`TenQuocGia_cn`,`TenQuocGia_vi`,`TenQuocGia_en`) VALUES ('1','菲律賓','Philippin','Philippin');
INSERT INTO `quocgia` (`idQuocGia`,`TenQuocGia_cn`,`TenQuocGia_vi`,`TenQuocGia_en`) VALUES ('2','越南','Việt Nam','Viet Nam');
/*!40000 ALTER TABLE `quocgia` ENABLE KEYS */;


--
-- Create Table `tag`
--

DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `Ten_vi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Ten_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Level` int(11) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `tag`
--

/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;


--
-- Create Table `theloai`
--

DROP TABLE IF EXISTS `theloai`;
CREATE TABLE `theloai` (
  `idTL` int(10) NOT NULL AUTO_INCREMENT,
  `TenTL_cn` text COLLATE utf8_unicode_ci NOT NULL,
  `TenTL_vi` text COLLATE utf8_unicode_ci NOT NULL,
  `TenTL_en` text COLLATE utf8_unicode_ci NOT NULL,
  `TenTL_KhongDau` text COLLATE utf8_unicode_ci NOT NULL,
  `ThuTu` int(11) NOT NULL,
  PRIMARY KEY (`idTL`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `theloai`
--

/*!40000 ALTER TABLE `theloai` DISABLE KEYS */;
INSERT INTO `theloai` (`idTL`,`TenTL_cn`,`TenTL_vi`,`TenTL_en`,`TenTL_KhongDau`,`ThuTu`) VALUES ('18','','Quảng cáo','Advertiser','quang-cao','1');
INSERT INTO `theloai` (`idTL`,`TenTL_cn`,`TenTL_vi`,`TenTL_en`,`TenTL_KhongDau`,`ThuTu`) VALUES ('19','','In ấn','Print','in-an','3');
INSERT INTO `theloai` (`idTL`,`TenTL_cn`,`TenTL_vi`,`TenTL_en`,`TenTL_KhongDau`,`ThuTu`) VALUES ('26','','Thiết kế','Design','thiet-ke','2');
/*!40000 ALTER TABLE `theloai` ENABLE KEYS */;


--
-- Create Table `thongso_sanpham`
--

DROP TABLE IF EXISTS `thongso_sanpham`;
CREATE TABLE `thongso_sanpham` (
  `idThongSo` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `kich_thuoc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `do_phan_giai` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `he_dieu_hanh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chip_xu_ly` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `may_anh_chinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bo_nho_trong` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dung_luong_pin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idThongSo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `thongso_sanpham`
--

/*!40000 ALTER TABLE `thongso_sanpham` DISABLE KEYS */;
/*!40000 ALTER TABLE `thongso_sanpham` ENABLE KEYS */;


--
-- Create Table `thuonghieu`
--

DROP TABLE IF EXISTS `thuonghieu`;
CREATE TABLE `thuonghieu` (
  `idThuongHieu` int(11) NOT NULL AUTO_INCREMENT,
  `Ten_vi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Ten_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `HinhDaiDien` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idThuongHieu`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `thuonghieu`
--

/*!40000 ALTER TABLE `thuonghieu` DISABLE KEYS */;
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('1','Apple','Apple','upload/images/thuonghieu/logo-apple.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('2','Samsung','Samsung','upload/images/thuonghieu/logo-samsung.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('3','Nokia','Nokia','upload/images/thuonghieu/logo-nokia.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('4','Sony','Sony','upload/images/thuonghieu/logo-sony.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('5','Lenovo','Lenovo','upload/images/thuonghieu/logo-lenovo.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('6','LG','LG','upload/images/thuonghieu/logo-LG.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('7','Viettel','Viettel','upload/images/thuonghieu/logo-viettel.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('8','HTC','HTC','upload/images/thuonghieu/logo-htc.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('9','Oppo','Oppo','upload/images/thuonghieu/logo-oppo.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('10','HP','HP','upload/images/thuonghieu/logo-hp.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('11','FPT','FPT','upload/images/thuonghieu/logo-fpt.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('12','Asus','Asus','upload/images/thuonghieu/logo-asus.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('14','Trung Quốc','China','upload/images/thuonghieu/logo-oppo.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('15','Viet Nam','VietNam','');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('16','Đài Loan','Taiwan','upload/images/thuonghieu/logo-oppo.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('17','Hồng Kong','Hong Kong','upload/images/thuonghieu/logo-asus.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('18','Totoro','Totoro','upload/images/thuonghieu/logo-sky.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('19','Hello Kitty','Hello Kitty','upload/images/thuonghieu/kitty.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('20','Pisen','Pisen','upload/images/thuonghieu/pisen.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('21','Úc','Australia','upload/images/thuonghieu/logo_nho_uc.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('22','Romoss','Romoss','upload/images/thuonghieu/logo_romoss.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('23','Power banks','Power banks','upload/images/thuonghieu/logo_power_bank.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('24','Xiaomi','Xiaomi','upload/images/thuonghieu/logo_xiaomi.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('25','J-Tech Hong Kong','J-Tech','upload/images/thuonghieu/logo_j-tach.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('26','Tempered glass','Tempered glass','upload/images/thuonghieu/logo-oppo.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('27','Cầu kè','Cau ke','upload/images/thuonghieu/logo_cauke.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('28','9H','9H','');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('29','KONO','KONO','');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('30','Logitech','Logitech','');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('31','Genies','Genies','');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('32','Dell','Dell','');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('33','Sandisk','Sandisk','upload/images/thuonghieu/sandisk-logo.png');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('34','Suni / Libni','Suni / Libni','upload/images/thuonghieu/suni_logo.gif');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('35','Solar zoom camping lamp','Solar zoom camping lamp','upload/images/thuonghieu/Bee.jpg');
INSERT INTO `thuonghieu` (`idThuongHieu`,`Ten_vi`,`Ten_en`,`HinhDaiDien`) VALUES ('36','Solar','Solar Zoom','');
/*!40000 ALTER TABLE `thuonghieu` ENABLE KEYS */;


--
-- Create Table `tien_ich`
--

DROP TABLE IF EXISTS `tien_ich`;
CREATE TABLE `tien_ich` (
  `idTienich` int(11) NOT NULL AUTO_INCREMENT,
  `Ten_vi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Ten_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `HinhDaiDien` text COLLATE utf8_unicode_ci NOT NULL,
  `Website` text COLLATE utf8_unicode_ci NOT NULL,
  `idLoai` int(11) NOT NULL,
  PRIMARY KEY (`idTienich`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `tien_ich`
--

/*!40000 ALTER TABLE `tien_ich` DISABLE KEYS */;
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('1','Đăng tin Alogap','Alogap','alogap','upload/images/thuonghieu/tienich_user/logo_dangtin_mien-phi.jpg','http://alogap.com/','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('2','Coc Coc','Coc Coc','coc-coc','upload/images/thuonghieu/tienich_user/coc-coc.png','http://coccoc.com/search#!','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('3','Nhạc vui','Music','music','upload/images/thuonghieu/tienich_user/nhac-vui-ve.jpg','http://nhac.vui.vn/','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('4','Fix Danh Bạ','Fix address book','fix-address-book','upload/images/thuonghieu/tienich_user/danh-ba-iphone.jpg','http://www.queenbeeec.com/tintuc/fix-loi-danh-ba-iphone-5-5c-5s-6-6plus-6s-6splus-ios-902-46.html','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('23','Vatgia','','vatgia','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','http://www.vatgia.com/home/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('6','Fix Lỗi iPhone','Fix iPhone','fix-iphone','upload/images/thuonghieu/tienich_user/maxresdefault.jpg','http://www.queenbeeec.com/tintuc/huong-dan-fix-loi-ios-80-902-iphone-lock-co-anh-minh-hoa-40.html','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('7','Zing tin tức','Zing news','zing-news','upload/images/thuonghieu/Zing-news-logo.jpg','http://news.zing.vn/','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('8','Zing nghe nhạc trực tuyến','Zing mp3','zing-mp3','upload/images/thuonghieu/logo-zing-mp3.jpg','http://mp3.zing.vn/','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('78','Kenhsinhvien','','kenhsinhvien','upload/images/thuonghieu/tienich_user/Bee.jpg','http://kenhsinhvien.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('10','Nhattao','','','upload/images/logo-nhattao.png','https://nhattao.com','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('11','5giay','','','upload/images/logo-5giay.png','https://www.5giay.vn/','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('25','RongBay','','rongbay','upload/images/thuonghieu/tienich_user/logo_rongbay.png','http://rongbay.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('26','Raovat3mien','','raovat3mien','upload/images/thuonghieu/tienich_user/logo_raovat3mien.png','http://raovat3mien.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('28','Tinh te','','tinh-te','upload/images/thuonghieu/tienich_user/logo_kinhte.jpg','https://tinhte.vn','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('29','Kenh14','','kenh14','upload/images/thuonghieu/tienich_user/logo_kẽnh.jpg','kenh14.vn','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('30','Google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','https://www.google.com.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('43','Vatgia','','vatgia','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','http://vatgia.com/home/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('42','Google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','https://www.google.com','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('41','test','','test','upload/images/thuonghieu/tienich_user/Bee.png','http://www.foody.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('44','5giay','','5giay','upload/images/thuonghieu/tienich_user/logo_raovat3mien.png','https://www.5giay.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('45','5giay','','5giay','upload/images/thuonghieu/tienich_user/logo-tab.png','https://www.5giay.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('46','Google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','google.com','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('47','AAAAA','','aaaaa','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','http://vatgia.com/home/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('48','ADSS','','adss','upload/images/thuonghieu/tienich_user/logo-tab.png','http://google.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('49','Google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','https://www.google.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('50','Vatgia','','vatgia','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','vatgia.com','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('51','Google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','https://www.google.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('52','Vatgia','','vatgia','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','http://vatgia.com/home/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('53','Raovat3mien','','raovat3mien','upload/images/thuonghieu/tienich_user/logo_raovat3mien.png','http://raovat3mien.com/index.php','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('54','google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','https://www.google.com.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('55','raovat3mien','','raovat3mien','upload/images/thuonghieu/tienich_user/logo_raovat3mien.png','http://raovat3mien.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('56','Vatgia','','vatgia','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','http://www.vatgia.com/home/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('58','Vatgia','','vatgia','upload/images/thuonghieu/tienich_user/logo_vat-gia.png','http://www.vatgia.com/home/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('59','raovat3mien','','raovat3mien','upload/images/thuonghieu/tienich_user/logo_raovat3mien.png','http://raovat3mien.com/3mienact=reg-1','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('60','Kenh14','','kenh14','upload/images/thuonghieu/tienich_user/logo_kẽnh.jpg','http://kenh14.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('61','Kphim','','kphim','upload/images/thuonghieu/tienich_user/icon_kphim.png','http://kphim.tv/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('62','Twitter','','twitter','upload/images/thuonghieu/tienich_user/icon_twitter.jpg','https://twitter.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('63','Tinhte','','tinhte','upload/images/thuonghieu/tienich_user/icon_tinhte.jpg','https://tinhte.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('64','Chotot','','chotot','upload/images/thuonghieu/tienich_user/icon_chotot.jpg','http://www.chotot.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('65','Rao vat VnExpress','','rao-vat-vnexpress','upload/images/thuonghieu/tienich_user/icon_VnExpress.png','http://raovat.vnexpress.net/service/raovat/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('68','Rongbay','','rongbay','upload/images/thuonghieu/tienich_user/logo_rongbay.png','http://rongbay.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('67','Canbannhanh','','canbannhanh','upload/images/thuonghieu/tienich_user/logo_canbannhanh.png','http://canbannhanh.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('69','Google','','google','upload/images/thuonghieu/tienich_user/logo_google.png','https://www.google.com.vn/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('70','Rongbay','','rongbay','upload/images/thuonghieu/tienich_user/logo_rongbay.png','http://rongbay.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('71','Hướng dẫn TIỆN ÍCH','Guide utilities','guide-utilities','upload/images/thuonghieu/tienich_user/Bee.jpg','http://www.queenbeeec.com/tintuc/huong-dan-su-dung-tien-ich-35.html','1');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('72','Phu Kien Si Q.4','','phu-kien-si-q4','upload/images/thuonghieu/tienich_user/Bee.jpg','http://www.linhkienphucsi.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('73','Mua bán nhanh','','mua-ban-nhanh','upload/images/thuonghieu/tienich_user/logo_tienich_web.jpg','https://muabannhanh.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('74','Đăng tin Alogap','','dang-tin-alogap','upload/images/thuonghieu/tienich_user/logo_dangtin_mien-phi.jpg','http://alogap.com/','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('75','Quản lý Store 365','','quan-ly-store-365','upload/images/thuonghieu/tienich_user/logo_365store.png','https://page365.net/datapple/storefront/742149','0');
INSERT INTO `tien_ich` (`idTienich`,`Ten_vi`,`Ten_en`,`ten_alias`,`HinhDaiDien`,`Website`,`idLoai`) VALUES ('76','Đăng Tin 5S','','dang-tin-5s','upload/images/thuonghieu/tienich_user/Bee.jpg','http://dangtin5s.com/','0');
/*!40000 ALTER TABLE `tien_ich` ENABLE KEYS */;


--
-- Create Table `tinhtrang`
--

DROP TABLE IF EXISTS `tinhtrang`;
CREATE TABLE `tinhtrang` (
  `idTinhTrang` int(11) NOT NULL AUTO_INCREMENT,
  `Ten_vi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Ten_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenKhongDau` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idTinhTrang`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `tinhtrang`
--

/*!40000 ALTER TABLE `tinhtrang` DISABLE KEYS */;
INSERT INTO `tinhtrang` (`idTinhTrang`,`Ten_vi`,`Ten_en`,`TenKhongDau`) VALUES ('1','Mới','New machines','moi');
INSERT INTO `tinhtrang` (`idTinhTrang`,`Ten_vi`,`Ten_en`,`TenKhongDau`) VALUES ('2','Máy like new','Like new','may-like-new');
INSERT INTO `tinhtrang` (`idTinhTrang`,`Ten_vi`,`Ten_en`,`TenKhongDau`) VALUES ('3','Đã qua sử dụng','Second hand','da-qua-su-dung');
INSERT INTO `tinhtrang` (`idTinhTrang`,`Ten_vi`,`Ten_en`,`TenKhongDau`) VALUES ('4','Mới nhập về','New','moi-nhap-ve');
INSERT INTO `tinhtrang` (`idTinhTrang`,`Ten_vi`,`Ten_en`,`TenKhongDau`) VALUES ('7','Máy mới','New machines','may-moi');
INSERT INTO `tinhtrang` (`idTinhTrang`,`Ten_vi`,`Ten_en`,`TenKhongDau`) VALUES ('8','Còn hàng','In stock','con-hang');
/*!40000 ALTER TABLE `tinhtrang` ENABLE KEYS */;


--
-- Create Table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Pass` text COLLATE utf8_unicode_ci NOT NULL,
  `User` text COLLATE utf8_unicode_ci NOT NULL,
  `HoTen` text COLLATE utf8_unicode_ci NOT NULL,
  `HinhDaiDien` text COLLATE utf8_unicode_ci NOT NULL,
  `idLoai` tinyint(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`,`Pass`,`User`,`HoTen`,`HinhDaiDien`,`idLoai`) VALUES ('1','0192023a7bbd73250516f069df18b500','admin','Tonys','upload/images/user/user2-160x160.jpg','1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

