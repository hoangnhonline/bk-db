-- Status:5:63:MP_0:thietken_banvai:php:1.24.4::5.5.50-cll:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|article|5|8672|2015-01-22 21:21:22|MyISAM
-- TABLE|blocks|1|3968|2015-01-22 21:21:22|MyISAM
-- TABLE|category|7|3324|2015-01-22 21:21:22|MyISAM
-- TABLE|menu|5|2448|2015-01-22 21:21:22|MyISAM
-- TABLE|product|45|10920|2015-01-22 21:21:22|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-09-16 02:26

--
-- Create Table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `title_alias` varchar(255) NOT NULL,
  `url_images` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Data for Table `article`
--

/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` (`article_id`,`title`,`title_alias`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`status`,`is_hot`,`update_time`) VALUES ('2','Dịch vụ','dich-vu','','','Nội dung trang dịch vụ ','Dịch vụ','Dịch vụ','Dịch vụ','2','1','0','1383192397');
INSERT INTO `article` (`article_id`,`title`,`title_alias`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`status`,`is_hot`,`update_time`) VALUES ('3','Khuyến mãi','khuyen-mai','','','Nội dung trang khuyến m&atilde;i','Khuyến mãi','Khuyến mãi','Khuyến mãi','1','1','0','1378831098');
INSERT INTO `article` (`article_id`,`title`,`title_alias`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`status`,`is_hot`,`update_time`) VALUES ('4','Hỗ trợ - tư vấn','ho-tro-tu-van','','','Nội dung Hỗ trợ - tư vấn đang được cập nhật.','Hỗ trợ - tư vấn','Hỗ trợ - tư vấn','Hỗ trợ - tư vấn','1','1','0','1378831146');
INSERT INTO `article` (`article_id`,`title`,`title_alias`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`status`,`is_hot`,`update_time`) VALUES ('16','Giới thiệu','gioi-thieu','../upload/images/G(1).jpg','cửa hàng Hoa Mai chúng tôi là đơn vị chuyên cung cấp các mặt hàng Sỉ Và Lẻ vải may túi xách balô như: Vải mộc cotton, vải lót,(210D,1680DPU/PVC,600D,EVA V.V..,) vải lưới may nói bảo hiểm, (Vải lưới 3 lớp V.V..,)','<p>\r\n	<span style=\"font-size: medium\"><b>cửa h&agrave;ng Hoa Mai&nbsp;</b>ch&uacute;ng t&ocirc;i l&agrave; đơn vị chuy&ecirc;n cung cấp c&aacute;c mặt h&agrave;ng Sỉ V&agrave; Lẻ vải may t&uacute;i x&aacute;ch bal&ocirc; như: </span><em><strong><span style=\"font-size: medium\">Vải mộc cotton, vải l&oacute;t,(210D,1680DPU/PVC,600D,EVA V.V..,) vải lưới may n&oacute;i bảo hiểm, (Vải lưới 3 lớp V.V..,)&nbsp;</span></strong></em></p>\r\n<p>\r\n	<span style=\"font-size: medium\">Ch&uacute;ng t&ocirc;i tin tưởng rằng sẽ đem tới cho c&aacute;c bạn những nguy&ecirc;n liệu tuyệt vời để l&agrave;m ra những sản phẩm thời trang c&oacute; chất lượng ho&agrave;n hảo</span></p>\r\n<p>\r\n	<span style=\"font-size: medium\">B&ecirc;n cạnh đ&oacute;, như một lời tri &acirc;n đến kh&aacute;ch h&agrave;ng,</span><b style=\"font-size: medium\">Hoa Mai</b><span style=\"font-size: medium\">&nbsp;&aacute;p dụng ch&iacute;nh s&aacute;ch gi&aacute; cực tốt đối với c&aacute;c đơn h&agrave;ng với số lượng lớn. </span></p>\r\n<p>\r\n	<span style=\"font-size: medium\">Ch&uacute;ng t&ocirc;i nhận thức s&acirc;u sắc rằng &ldquo;Kh&aacute;ch h&agrave;ng tạo n&ecirc;n c&ocirc;ng ty&rdquo;, v&igrave; thế sự t&iacute;n nhiệm của kh&aacute;ch h&agrave;ng v&agrave; c&aacute;c đối t&aacute;c trong thời gian qua l&agrave; những g&igrave; lớn nhất m&agrave; ch&uacute;ng t&ocirc;i đ&atilde; c&oacute;! </span></p>\r\n<p>\r\n	<span style=\"font-size: medium\">C&ugrave;ng với năng lực v&agrave; uy t&iacute;n của m&igrave;nh,&nbsp;</span><b style=\"font-size: medium\">Hoa Mai</b><span style=\"font-size: medium\">&nbsp;đ&atilde; v&agrave; sẽ lu&ocirc;n nỗ lực kh&ocirc;ng ngừng để cung cấp cho Q&uacute;y kh&aacute;ch h&agrave;ng những sản phẩm tốt nhất với chi ph&iacute; hợp l&yacute; nhất!</span></p>\r\n<p>\r\n	<span style=\"font-size: medium\">H&atilde;y li&ecirc;n hệ với ch&uacute;ng t&ocirc;i hoặc gửi cho ch&uacute;ng t&ocirc;i nhu cầu của bạn, đ&oacute; l&agrave; những cơ hội v&agrave; niềm vinh dự m&agrave; ch&uacute;ng t&ocirc;i tr&acirc;n trọng h&agrave;ng ng&agrave;y!</span></p>\r\n','Giới thiệu','Giới thiệu','Giới thiệu','1','1','0','1408618276');
INSERT INTO `article` (`article_id`,`title`,`title_alias`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`status`,`is_hot`,`update_time`) VALUES ('20','Liên hệ','lien-he','','','<table align=\"center\" cellpadding=\"2\" cellspacing=\"2\" width=\"98%\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n				<div class=\"Normal\" id=\"dnn_ctr13840_HtmlModule_HtmlModule_lblContent\">\r\n					<p style=\"text-align: justify\">\r\n						<span class=\"DNNAlignleft\" id=\"dnn_ctr13840_ContentPane\"><span style=\"font-size: medium\"><strong><span style=\"color: rgb(0,0,0)\"><span style=\"font-family: Tahoma\">CỬA H&Agrave;NG HOA MAI</span></span></strong></span><br />\r\n						<span style=\"color: rgb(0,0,0)\"><span style=\"font-size: small\"><span style=\"font-family: Tahoma\">Địa chỉ: 134 B&atilde;i Sậy, Phường 4, Quận 6, TpHCM.<br />\r\n						Điện thoại: 0129 337 0000 Ms.Mai 0129 364 3333</span></span></span><br />\r\n						<span style=\"color: rgb(0,0,0)\"><span style=\"font-size: small\"><span style=\"font-family: Tahoma\">Website: <a href=\"http://www.banvai.vn\">www.banvai.vn</a></span></span></span><span style=\"color: rgb(0,0,0)\"><span style=\"font-size: small\"><span style=\"font-family: Tahoma\"> * Email: <a href=\"http://mailto:thucmai2003@yahoo.com/\">thucmai2003@yahoo.com</a></span></span></span></span></p>\r\n				</div>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n				<div style=\"margin-left: 20px;margin-top: 20px\">\r\n					<iframe frameborder=\"0\" height=\"450\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\" src=\"https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=vi&amp;geocode=&amp;q=134+B%C3%A3i+S%E1%BA%ADy,+ph%C6%B0%E1%BB%9Dng+4,+Qu%E1%BA%ADn+6,+H%E1%BB%93+Ch%C3%AD+Minh,+Vi%E1%BB%87t+Nam&amp;aq=0&amp;oq=134+B%C3%A3i+S%E1%BA%ADy,pH%C6%AF%E1%BB%9CNG+4,qU%E1%BA%ACN+6&amp;sll=37.0625,-95.677068&amp;sspn=37.735377,86.572266&amp;ie=UTF8&amp;hq=&amp;hnear=134+B%C3%A3i+S%E1%BA%ADy,+Phuong+4,+H%E1%BB%93+Ch%C3%AD+Minh,+Vi%E1%BB%87t+Nam&amp;ll=10.750553,106.64772&amp;spn=0.022894,0.042272&amp;t=m&amp;z=14&amp;output=embed\" width=\"680\"></iframe></div>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n				<div class=\"Normal\" id=\"dnn_ctr13840_HtmlModule_HtmlModule_lblContent\">\r\n					<p style=\"text-align: justify\">\r\n						<br />\r\n						<span class=\"DNNAlignleft\" id=\"dnn_ctr13840_ContentPane\"><span style=\"font-size: medium\"><strong><span style=\"color: rgb(0,0,0)\"><span style=\"font-family: Tahoma\">CHI NH&Aacute;NH CỬA H&Agrave;NG HOA MAI</span></span></strong></span><br />\r\n						<span style=\"color: rgb(0,0,0)\"><span style=\"font-size: small\"><span style=\"font-family: Tahoma\">Địa chỉ: 23 Trần Qu&iacute;, Phường 6, Quận 11, TpHCM.<br />\r\n						Điện thoại: 0129 337 0000 Ms.Mai 0129 364 3333</span></span></span><br />\r\n						<span style=\"color: rgb(0,0,0)\"><span style=\"font-size: small\"><span style=\"font-family: Tahoma\">Website: <a href=\"http://www.banvai.vn\">www.banvai.vn</a></span></span></span><span style=\"color: rgb(0,0,0)\"><span style=\"font-size: small\"><span style=\"font-family: Tahoma\"> * Email: <a href=\"http://mailto:thucmai2003@yahoo.com/\">thucmai2003@yahoo.com</a></span></span></span></span></p>\r\n				</div>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n				<div style=\"margin-left: 20px;margin-top: 20px\">\r\n					<iframe frameborder=\"0\" height=\"450\" src=\"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1959.8371514753017!2d106.65813259999999!3d10.759565099999987!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752eede4ebaac3%3A0x46ddd1868dda6787!2zMjMgVHLhuqduIFF1w70sIDQsIFF14bqtbiAxMSwgSOG7kyBDaMOtIE1pbmgsIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1409794047984\" style=\"border:0\" width=\"680\"></iframe></div>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n','Liên hệ','Liên hệ','Liên hệ','1','1','0','1409797303');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;


--
-- Create Table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE `blocks` (
  `block_id` int(11) NOT NULL AUTO_INCREMENT,
  `block_name` varchar(255) NOT NULL,
  `block_content` text NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`block_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `blocks`
--

/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` (`block_id`,`block_name`,`block_content`,`update_time`) VALUES ('2','Footer','<div style=\"width:400px; float:left;\">\r\n	<p style=\"text-align: center\">\r\n		<span style=\"color: #ff0000\"><span style=\"font-size: medium\"><strong><span style=\"font-family: Tahoma\">CỬA H&Agrave;NG HOA MAI </span></strong></span></span></p>\r\n	<p style=\"text-align: center\">\r\n		<strong><span style=\"font-size: small\"><span style=\"color: rgb(118, 201, 154)\"><span style=\"font-family: Tahoma\">Địa chỉ: 134 B&atilde;i Sậy, Phường 4, Quận 6, TP Hồ Ch&iacute; Minh<br />\r\n		Điện thoại: <font face=\"Tahoma\" size=\"2\">0129 364 3333</font>, 0129.337 0000 Ms.Mai</span></span><span style=\"color: #e4dfdf; font-family: Tahoma\">&nbsp; </span><br />\r\n		<span style=\"color: #006400\"><span style=\"font-family: Tahoma\">Website: </span></span><span style=\"font-family: Tahoma\"><a href=\"http://www.banvai.vn\"><span style=\"color: #006400\">www.banvai.vn</span></a><span style=\"color: #006400\">, </span></span></span></strong></p>\r\n</div>\r\n<div style=\"width:400px; float:left;\">\r\n	<p style=\"text-align: center\">\r\n		<span style=\"color: #ff0000\"><span style=\"font-size: medium\"><strong><span style=\"font-family: Tahoma\">CHI NH&Aacute;NH CỬA H&Agrave;NG HOA MAI </span></strong></span></span></p>\r\n	<p style=\"text-align: center\">\r\n		<strong><span style=\"font-size: small\"><span style=\"color: rgb(118, 201, 154)\"><span style=\"font-family: Tahoma\">Địa chỉ: 23, Trần Qu&yacute;, Phường 6, Quận 11, TP Hồ Ch&iacute; Minh<br />\r\n		Điện thoại: <font face=\"Tahoma\" size=\"2\">0129 364 3333</font>, 0129.337 0000 Ms.Mai</span></span><span style=\"color: #e4dfdf; font-family: Tahoma\">&nbsp; </span><br />\r\n		<span style=\"color: #006400\"><span style=\"font-family: Tahoma\">Website: </span></span><span style=\"font-family: Tahoma\"><a href=\"http://www.banvai.vn\"><span style=\"color: #006400\">www.banvai.vn</span></a><span style=\"color: #006400\">, </span></span></span></strong></p>\r\n</div>\r\n<br />\r\n','1409795506');
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;


--
-- Create Table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(255) NOT NULL,
  `cate_alias` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Data for Table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('1','Vải may ba lô - túi xách','vai-may-balo-tui-xach','0','Vải may ba lô - túi xách','Vải may ba lô - túi xách','Vải may ba lô - túi xách','1384240402');
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('44','Vải May Nón Bảo Hiểm Và Túi Xách  ( Lưới Ba Lớp )','vai-may-non-bao-hiem-va-tui-xach--luoi-ba-lop-','0','Vải May Nón Bảo Hiểm Và Túi Xách  ( Lưới Ba Lớp )','Vải May Nón Bảo Hiểm Và Túi Xách  ( Lưới Ba Lớp )','Vải May Nón Bảo Hiểm Và Túi Xách  ( Lưới Ba Lớp )','1380784920');
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('55','Mũ Bảo Hiểm 103 (Size S, M)','mu-bao-hiem-103-size-s-m','51','Mũ Bảo Hiểm 103 (Size S, M)','Mũ Bảo Hiểm 103 (Size S, M)','Mũ Bảo Hiểm 103 (Size S, M)','1384499993');
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('56','Mũ Bảo Hiểm 103KS ( Size S)','mu-bao-hiem-103ks--size-s','51','Mũ Bảo Hiểm 103KS ( Size S)','Mũ Bảo Hiểm 103KS ( Size S)','Mũ Bảo Hiểm 103KS ( Size S)','1384500009');
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('54','Mũ Bảo Hiểm 102 (Size M)','mu-bao-hiem-102-size-m','51','Mũ Bảo Hiểm 102 (Size M)','Mũ Bảo Hiểm 102 (Size M)','Mũ Bảo Hiểm 102 (Size M)','1384499977');
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('53','Mũ Bảo Hiểm 101 (Size S, M, L)','mu-bao-hiem-101-size-s-m-l','51','Mũ Bảo Hiểm 101 (Size S, M, L)','Mũ Bảo Hiểm 101 (Size S, M, L)','Mũ Bảo Hiểm 101 (Size S, M, L)','1384499967');
INSERT INTO `category` (`cate_id`,`cate_name`,`cate_alias`,`parent_id`,`seo_title`,`seo_description`,`seo_keyword`,`update_time`) VALUES ('51','Nón Bảo Hiểm','non-bao-hiem','0','Nón Bảo Hiểm','Nón Bảo Hiểm','Nón Bảo Hiểm','1380789690');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Create Table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(255) NOT NULL,
  `menu_alias` varchar(255) NOT NULL,
  `article_id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `update_time` int(11) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Data for Table `menu`
--

/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('2','Giới thiệu','gioi-thieu','16','0','1384243119','Giới thiệu','Giới thiệu','Giới thiệu');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('3','Dịch vụ','dich-vu','2','1','1378853295','Dịch vụ','Dịch vụ','Dịch vụ');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('4','Khuyến mãi','khuyen-mai','3','1','1378853277','Khuyến mãi','Khuyến mãi','Khuyến mãi');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('5','Hỗ trợ - tư vấn','ho-tro-tu-van','4','1','1378853290','Hỗ trợ - tư vấn','Hỗ trợ - tư vấn','Hỗ trợ - tư vấn');
INSERT INTO `menu` (`menu_id`,`menu`,`menu_alias`,`article_id`,`type`,`update_time`,`seo_title`,`seo_description`,`seo_keyword`) VALUES ('17','q','q','19','1','1409731827','q','q','q');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;


--
-- Create Table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `product_alias` varchar(255) NOT NULL,
  `price` varchar(20) NOT NULL,
  `url_images` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `category_id` varchar(255) NOT NULL,
  `full_parent` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_hot` tinyint(4) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

--
-- Data for Table `product`
--

/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('2','210D đen dày','210d-den-day','0','../upload/images/210D_en.jpg','sad','sad ','210D đen dày','210D đen dày','210D đen dày','1','1','1','0','1384155664');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('3','210D đen mỏng','210d-den-mong','0','../upload/images/210D_en.jpg','asdasd','asdfasas ','210D đen mỏng','210D đen mỏng','210D đen mỏng','1','1','1','1','1384156378');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('4','210D xám dày','210d-xam-day','0','../upload/images/210D.jpg','asdasd','asdasd ','210D xám dày','210D xám dày','210D xám dày','1','1','1','1','1384158655');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('5','210D hồng dày','210d-hong-day','200000','../upload/images/210D%20h_ng.jpg','sad','sad ','210D hồng dày','210D hồng dày','210D hồng dày','1','1','1','1','1384500842');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('7','210D đỏ dày 1','210d-do-day-1','200000','../upload/images/210D__123.jpg','sd','asf ','210D đỏ dày 1','210D đỏ dày 1','210D đỏ dày 1','1','1','1','1','1384500822');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('8','210D đỏ dày 2','210d-do-day-2','200000','../upload/images/210D__123.jpg','sad','asf ','210D đỏ dày 2','210D đỏ dày 2','210D đỏ dày 2','1','1','1','1','1384159196');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('9','210D đỏ dày 3','210d-do-day-3','200000','../upload/images/210D__123.jpg','asd','sad ','210D đỏ dày 3','210D đỏ dày 3','210D đỏ dày 3','1','1','1','1','1384159288');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('11','1680PVC giả hồng','1680pvc-gia-hong','200000','../upload/images/VC%20gi_%20h_ng.jpg','sadf','asdfas ','1680PVC giả hồng','1680PVC giả hồng','1680PVC giả hồng','1','1','1','1','1384162970');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('37','lưới 3 lớp dày màu đen','luoi-3-lop-day-mau-den','1','../upload/images/100818_dookadlc_107dabe3e64fdec60d4a56510501aa90.jpg','1','1 ','lưới 3 lớp dày màu đen','lưới 3 lớp dày màu đen','lưới 3 lớp dày màu đen','44','44','1','0','1384248840');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('38','lưới 3 lớp mỏng  nhiều màu sắc','luoi-3-lop-mong-nhieu-mau-sac','1','../upload/images/vai/1.jpg','1','1 ','lưới 3 lớp mỏng  nhiều màu sắc','lưới 3 lớp mỏng  nhiều màu sắc','lưới 3 lớp mỏng  nhiều màu sắc','44','44','1','0','1408617526');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('42','Vải tổng hợp','vai-tong-hop','','../upload/images/vai_tong_hop.jpg','','asd ','Vải tổng hợp','Vải tổng hợp','Vải tổng hợp','1','1','1','1','1384500854');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('41','Lưới màu đen loại dày','luoi-mau-den-loai-day','','../upload/images/luoi-mau-den-loai-day.jpg','','as','Lưới màu đen loại dày','Lưới màu đen loại dày','Lưới màu đen loại dày','44','44','1','0','1384485620');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('43','Vải tổng hợp 2','vai-tong-hop-2','','../upload/images/vai_tong_hop_2.jpg','','a','Vải tổng hợp 2','Vải tổng hợp 2','Vải tổng hợp 2','1','1','1','0','1384485852');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('44','Vải lót 210D đen','vai-lot-210d-den','','../upload/images/210D_mau_den.jpg','','aa ','Vải lót 210D đen','Vải lót 210D đen','Vải lót 210D đen','1','1','1','0','1384508128');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('45','1680PVC GIẢ NHIỀU MÀU SẮC','1680pvc-gia-nhieu-mau-sac','','../upload/images/1680pvc_gia.jpg','','a ','1680PVC GIẢ NHIỀU MÀU SẮC','1680PVC GIẢ NHIỀU MÀU SẮC','1680PVC GIẢ NHIỀU MÀU SẮC','1','1','1','1','1384500862');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('46','1680PVC Thiệt xám','1680pvc-thiet-xam','','../upload/images/1680PVC_thiet.jpg','','a','1680PVC Thiệt xám','1680PVC Thiệt xám','1680PVC Thiệt xám','1','1','1','0','1384486134');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('47','1680 Giả màu xanh','1680-gia-mau-xanh','','../upload/images/160_gia_mau_xanh.jpg','','a','1680 Giả màu xanh','1680 Giả màu xanh','1680 Giả màu xanh','1','1','1','0','1384486194');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('48','600 nhiều màu sắc','600-nhieu-mau-sac','','../upload/images/600_nhieu_mau_sac.png','','a ','600 nhiều màu sắc','600 nhiều màu sắc','600 nhiều màu sắc','1','1','1','1','1384500879');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('49','600D màu đỏ','600d-mau-do','','../upload/images/do.jpg','','a','600D màu đỏ','600D màu đỏ','600D màu đỏ','1','1','1','0','1384486276');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('50','210D nhiều màu sắc','210d-nhieu-mau-sac','','../upload/images/210D_mau_sac.jpg','','a','210D nhiều màu sắc','210D nhiều màu sắc','210D nhiều màu sắc','1','1','1','0','1384486317');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('51','Mũ bảo hiểm 101 (Size S)','mu-bao-hiem-101-size-s','','../upload/images/nonbh/gif_0110143755.jpg','','a','Mũ bảo hiểm 101 (Size S)','Mũ bảo hiểm 101 (Size S)','Mũ bảo hiểm 101 (Size S)','53','51','1','0','1384500106');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('52','Mũ bảo hiểm DongABank','mu-bao-hiem-dongabank','','../upload/images/nonbh/pro_20130110_144355.jpg','','a','Mũ bảo hiểm DongABank','Mũ bảo hiểm DongABank','Mũ bảo hiểm DongABank','53','51','1','0','1384500165');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('53','Mũ bảo hiểm QTD B\'lao','mu-bao-hiem-qtd-blao','','http://nonbaohiem.asia/uploads/sanpham/pro_20130110_145832.jpg','','a','Mũ bảo hiểm QTD B\'lao','Mũ bảo hiểm QTD B\'lao','Mũ bảo hiểm QTD B\'lao','53','51','1','0','1384500310');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('54','Mũ bảo hiểm Lenovo','mu-bao-hiem-lenovo','','http://nonbaohiem.asia/uploads/sanpham/pro_0111092926.jpg','','a','Mũ bảo hiểm Lenovo','Mũ bảo hiểm Lenovo','Mũ bảo hiểm Lenovo','53','51','1','0','1384500339');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('55','Mũ bảo hiểm màu trắng','mu-bao-hiem-mau-trang','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_135548.png','','a','Mũ bảo hiểm màu trắng','Mũ bảo hiểm màu trắng','Mũ bảo hiểm màu trắng','53','51','1','0','1384500369');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('56','Mũ bảo hiểm EVN','mu-bao-hiem-evn','','http://nonbaohiem.asia/uploads/sanpham/pro_0110144756.jpg','','a','Mũ bảo hiểm EVN','Mũ bảo hiểm EVN','Mũ bảo hiểm EVN','53','51','1','1','1384500394');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('57','Mũ bảo hiểm màu cam','mu-bao-hiem-mau-cam','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_134647.png','','a','Mũ bảo hiểm màu cam','Mũ bảo hiểm màu cam','Mũ bảo hiểm màu cam','53','51','1','1','1384500418');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('58','Mũ bảo hiểm 102  (Size M)','mu-bao-hiem-102-size-m','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_145803.jpg','','a','Mũ bảo hiểm 102  (Size M)','Mũ bảo hiểm 102  (Size M)','Mũ bảo hiểm 102  (Size M)','54','51','1','1','1384501260');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('59','Mũ bảo hiểm màu vàng','mu-bao-hiem-mau-vang','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_151219.jpg','','a','Mũ bảo hiểm màu vàng','Mũ bảo hiểm màu vàng','Mũ bảo hiểm màu vàng','54','51','1','1','1384501282');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('60','Mũ bảo hiểm màu đỏ','mu-bao-hiem-mau-do','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_151322.jpg','','a','Mũ bảo hiểm màu đỏ','Mũ bảo hiểm màu đỏ','Mũ bảo hiểm màu đỏ','54','51','1','0','1384501306');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('61','Mũ bảo hiểm màu đen','mu-bao-hiem-mau-den','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_150240.jpg','','a','Mũ bảo hiểm màu đen','Mũ bảo hiểm màu đen','Mũ bảo hiểm màu đen','54','51','1','0','1384501324');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('62','Mũ bảo hiểm màu hồng','mu-bao-hiem-mau-hong','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_150554.jpg','','a','Mũ bảo hiểm màu hồng','Mũ bảo hiểm màu hồng','Mũ bảo hiểm màu hồng','54','51','1','0','1384501346');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('63','mũ bảo hiểm màu xanh Ngọc','mu-bao-hiem-mau-xanh-ngoc','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_151434.jpg','','a','mũ bảo hiểm màu xanh Ngọc','mũ bảo hiểm màu xanh Ngọc','mũ bảo hiểm màu xanh Ngọc','54','51','1','0','1384501365');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('64','Mũ bảo hiểm hồng','mu-bao-hiem-hong','','http://nonbaohiem.asia/uploads/sanpham/pro_20121206_173722.jpg','','a','Mũ bảo hiểm hồng','Mũ bảo hiểm hồng','Mũ bảo hiểm hồng','55','51','1','0','1384501448');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('65','Mũ bảo hiểm Asia - màu xanh','mu-bao-hiem-asia-mau-xanh','','http://nonbaohiem.asia/uploads/sanpham/pro_20130112_171554.jpg','','a','Mũ bảo hiểm Asia - màu xanh','Mũ bảo hiểm Asia - màu xanh','Mũ bảo hiểm Asia - màu xanh','55','51','1','0','1384501468');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('66','Mũ bảo hiểm màu tim','mu-bao-hiem-mau-tim','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_154729.jpg','','a','Mũ bảo hiểm màu tim','Mũ bảo hiểm màu tim','Mũ bảo hiểm màu tim','55','51','1','0','1384501487');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('67','Mũ bảo hiểm màu bạc','mu-bao-hiem-mau-bac','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_160336.jpg','','a','Mũ bảo hiểm màu bạc','Mũ bảo hiểm màu bạc','Mũ bảo hiểm màu bạc','55','51','1','0','1384501502');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('68','Mũ bảo hiểm trắng bông hồng','mu-bao-hiem-trang-bong-hong','','http://nonbaohiem.asia/uploads/sanpham/pro_20121222_160908.jpg','','a','Mũ bảo hiểm trắng bông hồng','Mũ bảo hiểm trắng bông hồng','Mũ bảo hiểm trắng bông hồng','55','51','1','0','1384501522');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('69','Mũ bảo hiểm Asia - màu vàng','mu-bao-hiem-asia-mau-vang','','http://nonbaohiem.asia/uploads/sanpham/pro_20130112_171734.jpg','','a','Mũ bảo hiểm Asia - màu vàng','Mũ bảo hiểm Asia - màu vàng','Mũ bảo hiểm Asia - màu vàng','55','51','1','0','1384501544');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('70','Mũ bảo hiểm màu xanh','mu-bao-hiem-mau-xanh','','http://nonbaohiem.asia/uploads/sanpham/pro_20121225_140622.jpg','','a','Mũ bảo hiểm màu xanh','Mũ bảo hiểm màu xanh','Mũ bảo hiểm màu xanh','56','51','1','0','1384501611');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('71','Mũ bảo hiểm bạc đỏ','mu-bao-hiem-bac-do','','http://nonbaohiem.asia/uploads/sanpham/pro_0110152216.jpg','','a','Mũ bảo hiểm bạc đỏ','Mũ bảo hiểm bạc đỏ','Mũ bảo hiểm bạc đỏ','56','51','1','0','1384501631');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('72','Mũ bảo hiểm màu cam','mu-bao-hiem-mau-cam','','http://nonbaohiem.asia/uploads/sanpham/pro_20121225_141849.jpg','','a','Mũ bảo hiểm màu cam','Mũ bảo hiểm màu cam','Mũ bảo hiểm màu cam','56','51','1','0','1384501649');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('73','Mũ bảo hiểm xanh','mu-bao-hiem-xanh','','http://nonbaohiem.asia/uploads/sanpham/pro_0110153432.jpg','','a','Mũ bảo hiểm xanh','Mũ bảo hiểm xanh','Mũ bảo hiểm xanh','56','51','1','0','1384501664');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('74','Mũ bảo hiểm màu đỏ','mu-bao-hiem-mau-do','','http://nonbaohiem.asia/uploads/sanpham/pro_20121225_141924.png','','a','Mũ bảo hiểm màu đỏ','Mũ bảo hiểm màu đỏ','Mũ bảo hiểm màu đỏ','56','51','1','0','1384501687');
INSERT INTO `product` (`product_id`,`product_name`,`product_alias`,`price`,`url_images`,`description`,`content`,`seo_title`,`seo_description`,`seo_keyword`,`category_id`,`full_parent`,`status`,`is_hot`,`update_time`) VALUES ('75','Vai cao','vai-cao','50000','../upload/images/vai/4.jpg','hfhaklkla','1','Vai cao','Vai cao','Vai cao','44','44','1','0','1408617945');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

